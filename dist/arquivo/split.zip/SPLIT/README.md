# SPLIT — ONE MORE CUT

Jogo arcade roguelike 2D para Windows, feito em GDScript/Godot 4. A revisão visual de 30/10/2026 segue a referência fornecida: arena aberta, fundo roxo escuro, polígonos grandes de cor sólida, pentágonos azuis pequenos, HUD compacto e scanlines CRT.

## Jogar

Na pasta `SPLIT-Windows`, abra **SPLIT.exe**. O executável contém os recursos e não exige a instalação da Godot. Se estiver usando o ZIP, extraia a pasta antes de executar.

Para editar, importe este `project.godot` na Godot 4.7.2 e pressione **F6/F5**. O código usa APIs Godot 4; outras versões 4.x não foram verificadas nesta entrega.

| Controle | Ação |
|---|---|
| Botão esquerdo + arrastar + soltar | Executar um corte; curvas usam a entrada e a saída em cada forma |
| Esc | Pausar / continuar / voltar das configurações |
| 1 / 2 / 3 | Escolher uma carta de melhoria |
| R | Reiniciar imediatamente a partida |
| F11 | Alternar tela cheia |

Comece com 3 cortes. Atingir 3 alvos diretamente recupera 1 corte. Uma reação com 8 ativações recupera outro. O máximo é 6 cortes disponíveis e 2 devolvidos por gesto. Gestos menores que 25 px são ignorados; arrastos maiores que errem os alvos consomem um corte.

Ao atingir a meta, a reação termina antes da escolha de uma melhoria. As metas são **por rodada**; o total da partida aparece na pausa e no resultado. Sem cortes nem reação pendente, a partida termina. Cada melhoria dura até o reinício. Recorde e configurações ficam em `user://profile.cfg`; não há retomada de uma partida fechada.

## Implementado

- Divisão real de polígonos convexos; rejeição de tangências e fragmentos degenerados; cada fragmento possui colisão e movimento próprios.
- Corte curvo amostrado, cortes diagonais, entrada/saída verificadas no segmento finito e suporte a gestos rápidos.
- Fragmentos com velocidade herdada, impulso de separação e rotação. Até 80 fragmentos físicos e 650 partículas, com remoção automática.
- Seis tipos: multiplicação azul/ciano, explosão vermelha, condução verde, pontos amarelos, fragmentação rosa e atração roxa. Verde entra na rodada 2; roxo, na 3.
- Doze melhorias funcionais, cinco raridades, escolha ponderada sem repetição e indicação de sinergias.
- Combos, bônus de precisão, cortes extras, rodadas, game over, reinício, pausa, manual, configurações e recorde local.
- Ruptura com bordas luminosas, fragmentos mais rápidos, partículas direcionais, som sintetizado em camadas, pausa de impacto de até 45 ms e breve câmera lenta em combos grandes.
- CRT opcional, qualidade de efeitos, volumes independentes, intensidade de tremor e tela cheia.
- Música e efeitos originais gerados por síntese, sem arquivos externos ou conexão à internet.

## Regras e limites

Cada alvo só pode ser agendado uma vez na mesma reação. Filhos azuis não se multiplicam e não reentram na reação que os criou. Fragmentos não dão pontos e não são novos alvos de corte; **Efeito Dominó** permite que cada fragmento rápido ative um alvo por colisão, durante a janela de 4 segundos. Reações têm teto de 64 ativações e duração máxima de 7 segundos.

O corte curvo é reduzido à corda entre duas interseções consecutivas com cada polígono; não escava uma curva côncava dentro da peça. Fragmentos abaixo da área mínima são evitados pelo corte. A aparência de círculo roxo usa um polígono de 24 lados.

Todas as melhorias são únicas; após adquirir o arsenal completo, rodadas concedem até 3 cortes iniciais extras. O alcance de explosões e a multiplicação têm limites explícitos. As barras luminosas laterais são decorativas: o jogo continua sendo de cortes com mouse.

## Organização

- `scripts/cutting`: interseção, clipping convexo e entrada do mouse.
- `scripts/physics`: corpos rígidos, paredes, fragmentos e campos de atração.
- `scripts/core`: ciclo da partida, fila de reações, áudio e configurações.
- `scripts/scoring`: pontuação e limiares de combo.
- `scripts/upgrades` e `resources/upgrades`: catálogo e 12 recursos editáveis.
- `scripts/ui`: menus, HUD e fonte bitmap original.
- `scripts/effects` e `shaders`: partículas, rachaduras, trilhas, impacto e CRT.
- `resources/balancing/default.tres`: limites e metas configuráveis.
- `tests`: verificações de geometria, integração, captura e medição de renderização.

## Testar e exportar

Com o executável da Godot disponível como `godot`:

```powershell
godot --headless --path . --editor --import --quit
godot --headless --path . --fixed-fps 60 --script res://tests/run_all.gd -- --test
godot --headless --path . --export-release "Windows Desktop" "../SPLIT-Windows/SPLIT.exe"
```

Para exportar, instale os export templates correspondentes à versão da Godot. O preset Windows x86_64 inclui os recursos no próprio EXE. A opção `--test` impede a leitura e a alteração do perfil do jogador.

Resultado e cobertura estão em **TESTES.md**. A interface mantém a proporção 16:9 com faixas quando necessário, para preservar enquadramento e precisão do mouse.

## Próximos ajustes recomendados

O ciclo principal está implementado. O principal trabalho futuro é balancear metas de rodadas altas e combinações muito fortes com sessões mais longas de jogadores. A música é um loop sintetizado curto; pode ganhar variações por rodada. A verificação de desempenho cobre este computador, não uma matriz de GPUs. Partidas gravadas, suporte a controle e polígonos côncavos não fazem parte desta versão.

## Créditos

Código, geometria, HUD bitmap, ícone e áudio foram criados para este projeto. A imagem enviada foi usada como direção visual; não foi incorporada ao jogo como fundo. Godot e bibliotecas incluídas: **GODOT-LICENSES.txt**. Fonte padrão de interface fornecida pela engine. Referências técnicas: [RigidBody2D](https://docs.godotengine.org/en/4.5/classes/class_rigidbody2d.html) e [Geometry2D](https://docs.godotengine.org/en/stable/classes/class_geometry2d.html).
