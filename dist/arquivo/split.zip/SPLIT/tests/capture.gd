extends SceneTree
var game: SplitGame
func _initialize() -> void:
	call_deferred("run")
func frames(count:int) -> void:
	for i in count:
		await process_frame
func capture(name:String) -> void:
	await RenderingServer.frame_post_draw
	var folder := "res://../" if name in ["SPLIT-gameplay","SPLIT-cut"] else "res://../../work/"
	var path := ProjectSettings.globalize_path(folder+name+".png")
	root.get_texture().get_image().save_png(path)
	print("CAPTURE ",path)
func run() -> void:
	seed(20261030)
	game = load("res://scenes/main/main.tscn").instantiate()
	root.add_child(game)
	await frames(10)
	await capture("SPLIT-menu")
	game.start_run()
	game.hud.hint_left=0
	await frames(8)
	await capture("SPLIT-gameplay")
	game.perform_cut(PackedVector2Array([Vector2(580,590),Vector2(1470,865)]))
	await frames(11)
	await capture("SPLIT-cut")
	for i in 500:
		await process_frame
		if game.state=="upgrades":
			break
	await capture("SPLIT-upgrades")
	game.screens.show_settings("pause")
	await frames(3)
	await capture("SPLIT-settings")
	game.screens.show_guide()
	await frames(3)
	await capture("SPLIT-guide")
	paused=false
	game.queue_free()
	await frames(3)
	quit()
