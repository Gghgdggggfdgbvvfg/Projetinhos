extends SceneTree

var checks := 0
var failures: Array[String] = []
var game: SplitGame

func _initialize() -> void:
	call_deferred("_run")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)
		push_error("FAIL: " + message)

func _frames(count: int) -> void:
	for i in count:
		await process_frame

func _settle() -> void:
	for i in 700:
		await process_frame
		if not game.reactions.active:
			return
	check(false, "Reaction must settle within bounded time")

func _fixture(owned: Array = []) -> void:
	game.start_run()
	game.arena.clear()
	game.target = 99999999
	for id in owned:
		game.upgrades[id] = 1

func _spawn(kind: int, point: Vector2, radius: float = 40) -> ShapeBody:
	var body := game.arena.spawn(kind, point, radius, Vector2.ZERO)
	body.rotation = 0
	body.freeze = true
	return body

func _cut(a: Vector2, b: Vector2) -> void:
	game.perform_cut(PackedVector2Array([a, b]))
	await _settle()

func _geometry() -> void:
	var square := PackedVector2Array([Vector2(-50,-50),Vector2(50,-50),Vector2(50,50),Vector2(-50,50)])
	check(PolygonCutter.split(square, Vector2(-100,0), Vector2(100,0)).size() == 2, "Horizontal split")
	check(PolygonCutter.split(square, Vector2(0,-100), Vector2(0,100)).size() == 2, "Vertical split")
	check(PolygonCutter.split(square, Vector2(-100,-100), Vector2(100,100)).size() == 2, "Vertex diagonal split")
	check(PolygonCutter.split(square, Vector2(-100,-50), Vector2(100,-50)).is_empty(), "Tangent edge rejected")
	check(PolygonCutter.split(square, Vector2.ZERO, Vector2.ZERO).is_empty(), "Zero stroke rejected")
	check(PolygonCutter.split(square, Vector2(70,0), Vector2(100,0)).is_empty(), "Infinite extension must not cut")
	check(PolygonCutter.split(square, Vector2(-100,49.99), Vector2(100,49.99), 65).is_empty(), "Tiny sliver rejected")
	var curved := PackedVector2Array([Vector2(-80,0), Vector2(-40,-10),Vector2(0,10),Vector2(40,5),Vector2(80,0)])
	check(not PolygonCutter.stroke(square, curved).is_empty(), "Polyline chord follows entry and exit")
	var around := PackedVector2Array([Vector2(-80,0),Vector2(-80,-80),Vector2(80,-80),Vector2(80,0)])
	check(PolygonCutter.stroke(square, around).is_empty(), "Curved stroke around target must miss")
	for i in 1200:
		var sides := randi_range(3, 24)
		var poly := PolygonCutter.regular(sides, randf_range(15, 110))
		var dir := Vector2.from_angle(randf() * TAU)
		var shift := dir.orthogonal() * randf_range(-4, 4)
		var halves := PolygonCutter.split(poly, shift - dir * 300, shift + dir * 300)
		check(halves.size() == 2, "Random convex split %d" % i)
		if halves.size() == 2:
			check(absf(PolygonCutter.area(halves[0]) + PolygonCutter.area(halves[1]) - PolygonCutter.area(poly)) < 0.1, "Conserved area %d" % i)
			for half in halves:
				check(PolygonCutter.centroid(half).is_finite() and half.size() >= 3, "Valid child polygon %d" % i)

func _run() -> void:
	seed(1337)
	_geometry()
	game = load("res://scenes/main/main.tscn").instantiate()
	root.add_child(game)
	await _frames(3)
	check(game.state == "menu", "Menu boot")
	check(game.settings.ephemeral, "Tests must not overwrite user profile")
	_fixture()
	_spawn(4, Vector2(600,500))
	# Fast mouse events can arrive in one frame: use each event's position,
	# never the final polled pointer position, for the blade trajectory.
	var press := InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.pressed = true
	press.position = Vector2(500,500)
	root.push_input(press, true)
	var motion := InputEventMouseMotion.new()
	motion.position = Vector2(700,500)
	root.push_input(motion, true)
	var release := InputEventMouseButton.new()
	release.button_index = MOUSE_BUTTON_LEFT
	release.position = Vector2(700,500)
	root.push_input(release, true)
	await _settle()
	check(game.score.objects_cut == 1 and game.cuts == 2, "Mouse press/drag/release uses event positions")
	for kind in 6:
		_fixture()
		_spawn(kind, Vector2(600, 500))
		var before := game.arena.fragment_counter
		game.perform_cut(PackedVector2Array([Vector2(500,500),Vector2(700,500)]))
		await _frames(10)
		check(game.arena.fragment_counter > before, "Real collision fragments for kind %d" % kind)
		if kind == 0:
			check(game.arena.targets().size() == 2, "Blue creates two children")
		if kind == 4:
			check(game.arena.fragment_counter - before == 4, "Pink splits into four actual polygons")
		if kind == 5:
			check(game.arena.wells.size() == 1, "Gravity well exists")
		await _settle()
		check(game.score.objects_cut == 1, "No fragment duplicate score")
		check(game.cuts == 2, "A single cut spends exactly one charge")
	_fixture()
	_spawn(1, Vector2(600,500))
	_spawn(3, Vector2(740,540))
	await _cut(Vector2(550,500),Vector2(650,500))
	check(game.score.objects_cut == 2, "Red explosion activates neighbor")
	_fixture()
	_spawn(2, Vector2(600,500))
	for point in [Vector2(740,520),Vector2(760,640),Vector2(500,680)]:
		_spawn(4, point)
	await _cut(Vector2(550,500),Vector2(650,500))
	check(game.score.objects_cut == 4, "Conductor activates three neighbors")
	_fixture()
	for i in 3:
		_spawn(4, Vector2(500+i*200,500))
	await _cut(Vector2(400,500),Vector2(1000,500))
	check(game.cuts == 3 and game.reactions.direct_hits == 3, "Three direct targets refund one charge")
	_fixture()
	for i in 8:
		_spawn(4, Vector2(240+i*200,500),30)
	await _cut(Vector2(100,500),Vector2(1770,500))
	check(game.cuts == 4, "Eight activations plus direct bonus refund at most two")
	check(game.score.activations == 8 and game.score.multiplier() == 3, "Combo tiers")
	_fixture(["ghost", "double"])
	for y in [452,500,542]:
		_spawn(3, Vector2(600,y),17)
	await _cut(Vector2(500,500),Vector2(700,500))
	check(game.score.objects_cut == 3, "Both parallel blade upgrades affect geometry")
	_fixture(["explosive","growing"])
	_spawn(4, Vector2(600,500))
	_spawn(4, Vector2(690,540),25)
	await _cut(Vector2(550,500),Vector2(650,500))
	check(game.score.objects_cut == 2, "Explosive upgrade triggers neighbors")
	_fixture(["electric"])
	for i in 6:
		_spawn(4, Vector2(500+i*180,500),30)
	await _cut(Vector2(440,500),Vector2(550,500))
	check(game.score.objects_cut == 6, "Electric chain propagates and deduplicates")
	_fixture(["recycle"])
	for i in 5:
		_spawn(4, Vector2(500+i*200,500),30)
	await _cut(Vector2(400,500),Vector2(1400,500))
	check(game.cuts == 4, "Recycle refunds at five activations")
	_fixture(["chaos"])
	_spawn(3, Vector2(600,500))
	var before := game.arena.fragment_counter
	await _cut(Vector2(500,500),Vector2(700,500))
	check(game.arena.fragment_counter - before == 4, "Chaos physically subdivides regular target")
	_fixture(["precision"])
	_spawn(4, Vector2(600,500))
	await _cut(Vector2(500,500),Vector2(700,500))
	check(game.score.total == int(90*1.75), "Precision center bonus")
	_fixture(["freeze"])
	_spawn(4, Vector2(600,500))
	var neighbor := _spawn(4, Vector2(730,580))
	game.perform_cut(PackedVector2Array([Vector2(500,500),Vector2(650,500)]))
	await _frames(10)
	check(neighbor.slow_left > 0, "Freeze modifies nearby body speed cap")
	await _settle()
	_fixture(["gravity"])
	game.gravity_timer = 0
	await _frames(3)
	check(game.arena.wells.size() == 1, "Unstable gravity periodically creates a real force field")
	_fixture(["chance"])
	game.cuts = 1
	for i in 2:
		_spawn(4,Vector2(500+i*200,500))
	await _cut(Vector2(400,500),Vector2(800,500))
	check(game.cuts == 1 and game.chance_used and game.state == "playing", "Last chance saves once")
	await _cut(Vector2(100,250),Vector2(200,250))
	check(game.state == "game_over", "Last chance cannot loop")
	_fixture(["domino"])
	_spawn(4,Vector2(600,500))
	_spawn(3,Vector2(600,700),70)
	game.perform_cut(PackedVector2Array([Vector2(500,500),Vector2(700,500)]))
	await _frames(3)
	var pieces := game.arena.fragments()
	check(not pieces.is_empty(), "Domino has physical fragments")
	await _settle()
	check(game.score.objects_cut >= 2,"Real moving fragment collision triggers Domino")
	_fixture()
	_spawn(4,Vector2(600,500))
	game.perform_cut(PackedVector2Array([Vector2(500,500),Vector2(700,500)]))
	game.toggle_pause()
	var queued := game.reactions.queue.size()
	await _frames(30)
	check(game.reactions.queue.size() == queued and game.state == "paused", "Pause preserves pending reaction")
	game.toggle_pause()
	await _settle()
	check(game.score.objects_cut == 1, "Resume completes same reaction")
	_fixture()
	game.target = 500
	_spawn(3, Vector2(500,500))
	_spawn(3, Vector2(700,500))
	await _cut(Vector2(400,500),Vector2(800,500))
	check(game.state == "upgrades" and game.screens.offers.size() == 3, "Round goal opens three cards")
	var chosen := game.screens.offers[0].id
	game.screens.choose(0)
	check(game.round_number == 2 and game.upgrades.has(chosen) and game.cuts == 3, "Choosing persists upgrade and advances round")
	_fixture()
	for i in 3:
		await _cut(Vector2(100,250),Vector2(200,250))
	check(game.state == "game_over", "Three misses produce game over")
	game.start_run()
	check(game.state == "playing" and game.score.total == 0 and game.upgrades.is_empty(), "Instant clean restart")
	# Stress a dense, fully upgraded reaction; inspect hard caps continuously.
	_fixture(UpgradeCatalog.IDS)
	for i in 36:
		_spawn(i%6,Vector2(300+(i%9)*150,330+(i/9)*130),30)
	game.perform_cut(PackedVector2Array([Vector2(100,330),Vector2(1800,330)]))
	for i in 700:
		await process_frame
		check(game.arena.fragments().size() <= game.balance.max_fragments, "Physical fragment cap")
		check(game.reactions.scheduled.size() <= game.balance.max_activations, "Activation cap")
		if not game.reactions.active:
			break
	check(not game.reactions.active, "Dense synergistic reaction terminates")
	game.show_menu()
	game.screens.show_guide()
	game.screens.show_settings("menu")
	game.screens.close_settings()
	check(game.screens.screen_name == "menu", "Settings and guide construct and return")
	print("SPLIT_TEST_RESULT checks=%d failures=%d" % [checks, failures.size()])
	for failure in failures:
		print("FAILED: " + failure)
	paused = false
	game.queue_free()
	await _frames(3)
	quit(0 if failures.is_empty() else 1)
