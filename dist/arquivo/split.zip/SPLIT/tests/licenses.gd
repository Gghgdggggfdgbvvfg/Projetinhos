extends SceneTree
func _initialize() -> void:
	var file:=FileAccess.open("res://GODOT-LICENSES.txt",FileAccess.WRITE)
	file.store_string(Engine.get_license_text()+"\n\n")
	var copyrights:=Engine.get_copyright_info()
	for entry in copyrights:
		file.store_string(str(entry)+"\n")
	var licenses:=Engine.get_license_info()
	for name in licenses:
		file.store_string("\n\n"+name+"\n"+licenses[name])
	file.close()
	quit()
