extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var game: SplitGame = load("res://scenes/main/main.tscn").instantiate()
	root.add_child(game)
	game.start_run()
	game.target=99999999
	for id in UpgradeCatalog.IDS:
		game.upgrades[id]=1
	var elapsed := 0.0
	var values: Array[float] = []
	var next_cut := 1.0
	var max_fragments := 0
	var max_particles := 0
	var last := Time.get_ticks_usec()
	while elapsed<10.0:
		await process_frame
		var now := Time.get_ticks_usec()
		var dt := (now-last)/1000000.0
		last=now
		elapsed+=dt
		if elapsed>2.0:
			values.append(dt*1000)
		max_fragments=maxi(max_fragments,game.arena.fragments().size())
		max_particles=maxi(max_particles,game.fx.particles.size())
		if elapsed>next_cut and not game.reactions.active:
			next_cut=elapsed+2.0
			game.cuts=6
			game.perform_cut(PackedVector2Array([Vector2(100,600),Vector2(1800,800)]))
	values.sort()
	var sum:=0.0
	for value in values:
		sum+=value
	var report := "SPLIT_RENDER_BENCHMARK mean_ms=%.2f p95_ms=%.2f samples=%d peak_fragments=%d peak_particles=%d\n" % [sum/values.size(),values[int(values.size()*0.95)],values.size(),max_fragments,max_particles]
	print(report)
	var file:=FileAccess.open(ProjectSettings.globalize_path("res://../../work/benchmark.txt"),FileAccess.WRITE)
	file.store_string(report)
	file.close()
	paused=false
	game.queue_free()
	for i in 10:
		await process_frame
	quit()
