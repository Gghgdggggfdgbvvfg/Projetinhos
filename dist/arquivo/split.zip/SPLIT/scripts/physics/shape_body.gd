class_name ShapeBody
extends RigidBody2D

signal fragment_contact(fragment: ShapeBody, target: ShapeBody)

var polygon := PackedVector2Array()
var kind: int = 0
var tint := Color.CYAN
var fragment := false
var activated := false
var generation := 0
var born_chain := -1
var chain_id := -1
var age := 0.0
var lifetime := 4.0
var domino_used := false
var radius := 50.0
var slow_left := 0.0
var cut_edges: Array[PackedVector2Array] = []
var rupture_flash := 0.0

func setup(points: PackedVector2Array, type: int, is_fragment: bool = false) -> void:
	polygon = points
	kind = type
	tint = ObjectCatalog.COLORS[kind]
	fragment = is_fragment
	mass = maxf(0.08, PolygonCutter.area(polygon) / 4500.0)
	gravity_scale = 0.0
	linear_damp = 0.04 if fragment else 0.0
	angular_damp = 0.04
	can_sleep = false
	continuous_cd = RigidBody2D.CCD_MODE_CAST_SHAPE
	collision_layer = 2 if fragment else 1
	collision_mask = 7
	var material := PhysicsMaterial.new()
	material.bounce = 0.92
	material.friction = 0.03
	physics_material_override = material
	var collision := CollisionPolygon2D.new()
	collision.polygon = polygon
	add_child(collision)
	radius = 0.0
	for p in polygon:
		radius = maxf(radius, p.length())
	if fragment:
		contact_monitor = true
		max_contacts_reported = 3
		body_entered.connect(_contact)
	queue_redraw()

func _contact(other: Node) -> void:
	if other is ShapeBody and not other.fragment and not domino_used and age > 0.12:
		if linear_velocity.length() > 220.0:
			fragment_contact.emit(self, other)

func _physics_process(delta: float) -> void:
	age += delta
	rupture_flash = maxf(0.0, rupture_flash - delta)
	if fragment:
		modulate.a = clampf((lifetime - age) / 0.65, 0.0, 1.0)
		if age >= lifetime:
			queue_free()
	slow_left = maxf(0.0, slow_left - delta)
	if fragment:
		queue_redraw()

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
	var velocity := state.linear_velocity
	var cap := 800.0 if fragment else 210.0
	if slow_left > 0.0:
		cap = 48.0
	if velocity.length() > cap:
		state.linear_velocity = velocity.limit_length(cap)
	elif not fragment and slow_left <= 0.0 and velocity.length() < 40.0:
		state.linear_velocity = velocity.normalized() * 40.0 if velocity.length() > 1.0 else Vector2(35, 28)

func world_polygon() -> PackedVector2Array:
	return global_transform * polygon

func _draw() -> void:
	if polygon.size() < 3:
		return
	var outline := polygon.duplicate()
	outline.append(polygon[0])
	# Solid uninterrupted silhouettes, like the supplied arcade reference.
	for width in [14.0, 7.0, 3.0]:
		draw_polyline(outline, Color(tint, 0.025 if width > 7 else 0.055), width, true)
	draw_colored_polygon(polygon, tint)
	if fragment:
		var hot := clampf(rupture_flash / 0.18, 0.0, 1.0)
		if hot > 0:
			draw_colored_polygon(polygon, Color(1, 0.97, 1, hot * 0.4))
		var edge_alpha := clampf(1.0 - age / 0.9, 0.0, 1.0)
		for edge in cut_edges:
			draw_polyline(edge, Color(tint, edge_alpha * 0.18), 16, true)
			draw_polyline(edge, Color(1, 0.95, 1, edge_alpha), 2.4, true)
