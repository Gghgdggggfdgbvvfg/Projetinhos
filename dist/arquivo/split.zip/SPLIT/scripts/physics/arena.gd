class_name SplitArena
extends Node2D

signal domino_hit(fragment: ShapeBody, target: ShapeBody)
var bounds := Rect2(56, 105, 1808, 940)
var balance: SplitBalance
var wells: Array[Dictionary] = []
var fragment_counter := 0

func _ready() -> void:
	for rect in [Rect2(31, 80, 1858, 25), Rect2(31, 1045, 1858, 25), Rect2(31, 105, 25, 940), Rect2(1864, 105, 25, 940)]:
		var wall := StaticBody2D.new()
		wall.collision_layer = 4
		wall.collision_mask = 3
		var collision := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = rect.size
		collision.shape = shape
		wall.position = rect.get_center()
		wall.add_child(collision)
		add_child(wall)

func targets() -> Array[ShapeBody]:
	var result: Array[ShapeBody] = []
	for node in get_children():
		if node is ShapeBody and not node.fragment and not node.activated and not node.is_queued_for_deletion():
			result.append(node)
	return result

func fragments() -> Array[ShapeBody]:
	var result: Array[ShapeBody] = []
	for node in get_children():
		if node is ShapeBody and node.fragment and not node.is_queued_for_deletion():
			result.append(node)
	return result

func clear() -> void:
	wells.clear()
	for node in get_children():
		if node is ShapeBody:
			remove_child(node)
			node.queue_free()

func spawn(kind: int, point: Vector2, radius: float, velocity: Vector2, generation: int = 0, born_chain: int = -1) -> ShapeBody:
	if targets().size() >= balance.max_objects:
		return null
	var body := ShapeBody.new()
	var sides: int = 4 if kind==0 and radius>=65 else ObjectCatalog.SIDES[kind]
	body.setup(PolygonCutter.regular(sides, radius), kind)
	if kind == 0 and radius < 50:
		body.tint = Color("008fd6") if generation == 0 else Color("00dfff")
	body.position = point.clamp(bounds.position + Vector2.ONE * radius, bounds.end - Vector2.ONE * radius)
	body.linear_velocity = velocity
	body.angular_velocity = randf_range(-0.6, 0.6)
	body.rotation = randf_range(-PI, PI)
	body.generation = generation
	body.born_chain = born_chain
	add_child(body)
	return body

func populate(round_number: int, menu: bool = false) -> void:
	clear()
	# Loose composition: large warm shapes, small blue pentagons, open dark space.
	var large := [Vector3(665,170,1),Vector3(905,165,4),Vector3(1432,288,1),Vector3(1165,395,0),Vector3(778,562,4),Vector3(675,725,4),Vector3(890,780,3),Vector3(1000,743,4),Vector3(1235,660,3),Vector3(1340,592,1),Vector3(1248,790,3),Vector3(1290,928,4),Vector3(963,947,1),Vector3(1070,887,1)]
	for i in large.size():
		var spec: Vector3 = large[i]
		var kind := int(spec.z)
		if i == 5 and round_number >= 2:
			kind = 2
		if i == 7 and round_number >= 3:
			kind = 5
		var radius := randf_range(76, 94)
		var point := Vector2(spec.x,spec.y) + Vector2(randf_range(-24,24),randf_range(-18,18))
		spawn(kind, point, radius, Vector2.from_angle(randf()*TAU)*randf_range(28,50+round_number*2))
	var small := [Vector2(1070,135),Vector2(1130,235),Vector2(1440,147),Vector2(1722,225),Vector2(852,307),Vector2(1003,494),Vector2(1212,518),Vector2(1778,520),Vector2(1590,570),Vector2(1046,685),Vector2(886,690),Vector2(584,610),Vector2(444,746),Vector2(730,830)]
	for i in small.size():
		spawn(0,small[i],randf_range(31,37),Vector2.from_angle(randf()*TAU)*randf_range(35,65))
	for i in mini(round_number - 1, 5):
		spawn([0,1,3,4].pick_random(),Vector2(randf_range(250,1700),randf_range(220,950)),randf_range(44,70),Vector2.from_angle(randf()*TAU)*75)

func fracture(body: ShapeBody, pieces: Array, a: Vector2, b: Vector2, chain: int, extra: bool = false) -> void:
	var final_pieces: Array = []
	for poly in pieces:
		if extra:
			var center := PolygonCutter.centroid(poly)
			var direction := (b - a).normalized().orthogonal()
			var halves := PolygonCutter.split(poly, center - direction * 500, center + direction * 500, balance.minimum_fragment_area)
			if not halves.is_empty():
				final_pieces.append_array(halves)
				continue
		final_pieces.append(poly)
	var normal := (b - a).normalized().orthogonal()
	var old_center := body.global_position
	var old_velocity := body.linear_velocity
	var spin := body.angular_velocity
	var source_kind := body.kind
	var source_tint := body.tint
	body.activated = true
	body.collision_layer = 0
	body.collision_mask = 0
	body.hide()
	body.queue_free()
	var existing := fragments()
	while existing.size() + final_pieces.size() > balance.max_fragments and not existing.is_empty():
		var oldest: ShapeBody = existing.pop_front()
		remove_child(oldest)
		oldest.queue_free()
	for poly in final_pieces:
		if PolygonCutter.area(poly) < balance.minimum_fragment_area:
			continue
		var center := PolygonCutter.centroid(poly)
		var local := PackedVector2Array()
		for point in poly:
			local.append(point - center)
		var piece := ShapeBody.new()
		piece.setup(local, source_kind, true)
		piece.tint = source_tint
		piece.rupture_flash = 0.18
		# Highlight only the newly exposed seam; the outer silhouette stays flat.
		for j in poly.size():
			var p: Vector2 = poly[j]
			var q: Vector2 = poly[(j + 1) % poly.size()]
			if absf((b-a).normalized().cross(p-a)) < 0.1 and absf((b-a).normalized().cross(q-a)) < 0.1:
				piece.cut_edges.append(PackedVector2Array([p-center,q-center]))
		var side := signf((b - a).cross(center - a))
		piece.position = center + normal * side * 5.0
		piece.linear_velocity = old_velocity + (center - old_center).orthogonal() * spin + normal * side * 285.0
		piece.angular_velocity = spin + side * randf_range(1.2, 2.5)
		piece.chain_id = chain
		piece.lifetime = balance.fragment_lifetime
		piece.fragment_contact.connect(func(f: ShapeBody, t: ShapeBody): domino_hit.emit(f, t))
		add_child(piece)
		fragment_counter += 1

func blast(point: Vector2, radius: float, strength: float) -> void:
	for child in get_children():
		if child is ShapeBody and not child.activated:
			var offset: Vector2 = child.position - point
			if offset.length() < radius:
				child.apply_central_impulse(offset.normalized() * strength * (1.0 - offset.length() / radius) * child.mass)

func _physics_process(delta: float) -> void:
	for i in range(wells.size() - 1, -1, -1):
		wells[i].time -= delta
		if wells[i].time <= 0:
			wells.remove_at(i)
			continue
		for body in targets():
			var offset: Vector2 = wells[i].point - body.position
			if offset.length() < 360.0:
				body.apply_central_force(offset.normalized() * 210.0 * body.mass)
