class_name SplitAudio
extends Node

var settings: SplitSettings
var voices: Array[AudioStreamPlayer] = []
var music_player: AudioStreamPlayer
var clips: Dictionary = {}
var next_voice := 0
var intensity := 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for name in ["slice", "impact", "explosion", "combo", "ui", "win", "lose"]:
		clips[name] = load("res://assets/audio/" + name + ".wav")
	for i in 10:
		var voice := AudioStreamPlayer.new()
		add_child(voice)
		voices.append(voice)
	music_player = AudioStreamPlayer.new()
	var stream := load("res://assets/audio/music.wav") as AudioStreamWAV
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = stream.data.size() / 2
	music_player.stream = stream
	add_child(music_player)
	if DisplayServer.get_name() != "headless":
		music_player.play()

func play(cue: String, pitch: float = 1.0) -> void:
	if DisplayServer.get_name()=="headless" or not clips.has(cue) or voices.is_empty():
		return
	var voice := voices[next_voice]
	next_voice = (next_voice + 1) % voices.size()
	voice.stream = clips[cue]
	voice.pitch_scale = pitch
	voice.volume_db = linear_to_db(maxf(0.0001, settings.master * settings.sfx * 0.65))
	voice.play()

func _exit_tree() -> void:
	for voice in voices:
		voice.stop()
		voice.stream = null
	if music_player:
		music_player.stop()
		music_player.stream = null
	clips.clear()

func _process(delta: float) -> void:
	intensity = move_toward(intensity, 0, delta * 0.3)
	if music_player:
		music_player.volume_db = linear_to_db(maxf(0.0001, settings.master * settings.music * (0.45 + intensity * 0.1)))
