class_name SplitReactions
extends Node

signal activated(point: Vector2, kind: int, points: int, count: int)
signal lightning(a: Vector2, b: Vector2, color: Color)
signal explosion(point: Vector2, radius: float, color: Color)
signal completed(direct_hits: int, activations: int)
signal fractured(a: Vector2, b: Vector2, color: Color, count: int)

var arena: SplitArena
var score: ScoreState
var balance: SplitBalance
var upgrades: Dictionary = {}
var round_number := 1
var active := false
var chain_id := 0
var direct_hits := 0
var queue: Array[Dictionary] = []
var scheduled: Dictionary = {}
var timer := 0.0
var idle := 0.0
var elapsed := 0.0

func reset() -> void:
	active = false
	queue.clear()
	scheduled.clear()
	chain_id += 1

func begin(path: PackedVector2Array) -> bool:
	if active:
		return false
	chain_id += 1
	score.begin_chain()
	queue.clear()
	scheduled.clear()
	direct_hits = 0
	idle = 0.0
	elapsed = 0.0
	timer = 0.0
	var paths: Array[PackedVector2Array] = [path]
	if upgrades.has("ghost"):
		paths.append(_offset_path(path, 42.0))
	if upgrades.has("double"):
		paths.append(_offset_path(path, -48.0))
	for stroke in paths:
		for body in arena.targets():
			if scheduled.has(body.get_instance_id()):
				continue
			var hit := PolygonCutter.stroke(body.world_polygon(), stroke, balance.minimum_fragment_area)
			if not hit.is_empty():
				_schedule(body, hit.a, hit.b, true)
				direct_hits += 1
	active = true # An intentional missed stroke still spends a cut.
	return true

func _offset_path(path: PackedVector2Array, offset: float) -> PackedVector2Array:
	var result := PackedVector2Array()
	var normal := (path[-1] - path[0]).normalized().orthogonal() * offset
	for p in path:
		result.append(p + normal)
	lightning.emit(result[0], result[-1], Color("a889ff"))
	return result

func _schedule(body: ShapeBody, a: Vector2, b: Vector2, direct: bool = false) -> void:
	if not is_instance_valid(body) or body.activated or body.born_chain == chain_id:
		return
	if scheduled.size() >= balance.max_activations or scheduled.has(body.get_instance_id()):
		return
	scheduled[body.get_instance_id()] = true
	# Store the plane in local coordinates so queued rotating targets are cut correctly.
	queue.append({"body": body, "a": body.to_local(a), "b": body.to_local(b), "direct": direct})
	idle = 0.0

func _trigger(body: ShapeBody, origin: Vector2, tint: Color) -> void:
	var direction := (body.position - origin).normalized().orthogonal()
	if direction.length_squared() < 0.1:
		direction = Vector2.RIGHT
	_schedule(body, body.position - direction * 200, body.position + direction * 200)
	lightning.emit(origin, body.position, tint)

func on_domino(fragment: ShapeBody, target: ShapeBody) -> void:
	if active and upgrades.has("domino") and fragment.chain_id == chain_id and elapsed < 4.0:
		fragment.domino_used = true
		# Called from physics contact; only enqueue here, mutate bodies in _process.
		_trigger(target, fragment.position, fragment.tint)

func _process(delta: float) -> void:
	if not active:
		return
	elapsed += delta
	timer -= delta
	if not queue.is_empty() and timer <= 0.0:
		var event: Dictionary = queue.pop_front()
		_activate(event)
		timer = balance.reaction_interval
		idle = 0.0
	elif queue.is_empty():
		idle += delta
		var settle := balance.settle_time if upgrades.has("domino") else 0.95
		var live_domino := false
		if upgrades.has("domino") and elapsed < 4.0:
			for fragment in arena.fragments():
				if fragment.chain_id == chain_id and not fragment.domino_used:
					live_domino = true
		if (idle > settle and not live_domino) or elapsed > 7.0:
			active = false
			completed.emit(direct_hits, score.activations)

func _activate(event: Dictionary) -> void:
	var body = event.body
	if not is_instance_valid(body) or body.activated:
		return
	var a: Vector2 = body.to_global(event.a)
	var b: Vector2 = body.to_global(event.b)
	var poly: PackedVector2Array = body.world_polygon()
	var pieces := PolygonCutter.split(poly, a, b, balance.minimum_fragment_area)
	if pieces.is_empty():
		return
	var point: Vector2 = body.position
	var kind: int = body.kind
	var generation: int = body.generation
	var radius: float = body.radius
	var precision := upgrades.has("precision") and Geometry2D.get_closest_point_to_segment(point, a, b).distance_to(point) < radius * 0.22
	var points := score.activate(kind, round_number, precision)
	var crossings: Array[Vector2] = []
	for i in poly.size():
		var hit = Geometry2D.segment_intersects_segment(a,b,poly[i],poly[(i+1)%poly.size()])
		if hit != null:
			crossings.append(hit)
	if crossings.size()>=2:
		fractured.emit(crossings[0],crossings[-1],body.tint,score.activations)
	arena.fracture(body, pieces, a, b, chain_id, kind == 4 or upgrades.has("chaos"))
	activated.emit(point, kind, points, score.activations)
	var neighbors := arena.targets()
	neighbors.sort_custom(func(x: ShapeBody, y: ShapeBody): return point.distance_squared_to(x.position) < point.distance_squared_to(y.position))
	if kind == 0 and generation == 0:
		for side in [-1, 1]:
			arena.spawn(0, point + Vector2(side * 32, 0), radius * 0.55, Vector2(side * 135, randf_range(-75, 75)), 1, chain_id)
	if kind == 1 or upgrades.has("explosive"):
		var reach := 205.0 if kind == 1 else 112.0
		if upgrades.has("growing"):
			reach += minf(125, score.activations * 6)
		arena.blast(point, reach, 330)
		explosion.emit(point, reach, ObjectCatalog.COLORS[kind])
		for target in neighbors:
			if target.position.distance_to(point) < reach:
				_trigger(target, point, Color("ff453a"))
	if kind == 2 or upgrades.has("electric"):
		var remaining := 3 if kind == 2 else 1
		for target in neighbors:
			if remaining > 0 and target.position.distance_to(point) < 280 and not scheduled.has(target.get_instance_id()):
				_trigger(target, point, Color("68ffac") if kind == 2 else Color("00d9ff"))
				remaining -= 1
	if kind == 5:
		arena.wells.append({"point": point, "time": 2.0})
		explosion.emit(point, 300, Color("a889ff"))
	if upgrades.has("freeze"):
		for target in neighbors:
			if target.position.distance_to(point) < 220:
				target.slow_left = 2.2
