class_name SplitGame
extends Node2D

var balance: SplitBalance = preload("res://resources/balancing/default.tres")
var settings := SplitSettings.new()
var score := ScoreState.new()
var upgrades: Dictionary = {}
var arena: SplitArena
var reactions: SplitReactions
var blade: SplitBlade
var fx: SplitEffects
var audio: SplitAudio
var hud: SplitHUD
var screens: SplitScreens
var background: SplitBackground
var camera: Camera2D
var crt_material: ShaderMaterial
var state := "menu"
var cuts := 3
var round_number := 1
var target := 500
var chance_used := false
var gravity_timer := 5.0
var paused_scale := 1.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	settings.load_profile()
	background = SplitBackground.new()
	background.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(background)
	arena = SplitArena.new()
	arena.balance = balance
	arena.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(arena)
	fx = SplitEffects.new()
	fx.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(fx)
	blade = SplitBlade.new()
	blade.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(blade)
	blade.released.connect(perform_cut)
	reactions = SplitReactions.new()
	reactions.arena = arena
	reactions.balance = balance
	reactions.score = score
	reactions.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(reactions)
	arena.domino_hit.connect(reactions.on_domino)
	reactions.activated.connect(_on_activation)
	reactions.fractured.connect(func(a:Vector2,b:Vector2,c:Color,count:int): fx.crack(a,b,c,count))
	reactions.explosion.connect(func(p: Vector2, r: float, c: Color):
		fx.ring(p, r, c)
		audio.play("explosion", randf_range(0.9, 1.1)))
	reactions.lightning.connect(func(a: Vector2, b: Vector2, c: Color): fx.line(a, b, c))
	reactions.completed.connect(_on_chain_complete)
	camera = Camera2D.new()
	camera.position = Vector2(960, 540)
	camera.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(camera)
	audio = SplitAudio.new()
	audio.settings = settings
	add_child(audio)
	var gui := CanvasLayer.new()
	gui.layer = 10
	add_child(gui)
	hud = SplitHUD.new()
	hud.game = self
	hud.process_mode = Node.PROCESS_MODE_PAUSABLE
	gui.add_child(hud)
	screens = SplitScreens.new()
	screens.game = self
	gui.add_child(screens)
	var post := CanvasLayer.new()
	post.layer = 20
	add_child(post)
	var rect := ColorRect.new()
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	crt_material = ShaderMaterial.new()
	crt_material.shader = preload("res://shaders/crt.gdshader")
	rect.material = crt_material
	post.add_child(rect)
	apply_settings()
	show_menu()

func apply_settings() -> void:
	crt_material.set_shader_parameter("enabled", settings.crt)
	fx.high_quality = settings.high_fx
	if DisplayServer.get_name() != "headless":
		var mode := DisplayServer.WINDOW_MODE_FULLSCREEN if settings.fullscreen else DisplayServer.WINDOW_MODE_WINDOWED
		if DisplayServer.window_get_mode() != mode:
			DisplayServer.window_set_mode(mode)

func show_menu() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	state = "menu"
	reactions.reset()
	blade.enabled = false
	blade.cancel()
	fx.clear()
	hud.hide()
	arena.clear()
	arena.populate(1,true)
	screens.show_menu()

func start_run() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	score = ScoreState.new()
	upgrades.clear()
	round_number = 1
	reactions.score = score
	reactions.upgrades = upgrades
	_start_round()

func _start_round() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	reactions.reset()
	reactions.round_number = round_number
	state = "playing"
	score.round_score = 0
	score.begin_chain()
	target = balance.target_for_round(round_number)
	cuts = mini(balance.max_cuts, balance.starting_cuts + int(upgrades.get("mastery", 0)))
	chance_used = false
	gravity_timer = 5.0
	fx.clear()
	arena.populate(round_number)
	blade.cancel()
	blade.enabled = true
	screens.clear()
	screens.screen_name = ""
	hud.show()
	hud.displayed_score = 0
	hud.displayed_progress = 0
	hud.hint_left = 7.0
	hud.announce("RODADA %02d  /  FAÇA CADA CORTE VALER" % round_number)

func perform_cut(path: PackedVector2Array) -> void:
	if state != "playing" or reactions.active or cuts <= 0 or path.size() < 2:
		return
	var length := 0.0
	for i in range(1, path.size()):
		length += path[i].distance_to(path[i - 1])
	if length < 25:
		return
	if reactions.begin(path):
		cuts -= 1
		blade.enabled = false
		fx.slash(path)
		audio.play("slice", randf_range(0.95, 1.08))

func _on_activation(point: Vector2, kind: int, points: int, count: int) -> void:
	fx.burst(point,ObjectCatalog.COLORS[kind],12)
	fx.popup(point, "+%d" % points, ObjectCatalog.COLORS[kind])
	audio.play("impact",minf(1.65,0.9+count*0.045))
	if count in [3, 6, 12, 25]:
		audio.play("combo", minf(1.5, 1.0 + count * 0.01))
		fx.popup(point + Vector2(-35, -45), "COMBO ×%d" % score.multiplier(), SplitDesign.WHITE)
		fx.shake_amount = minf(14,5+count)
	if count == 12 or count == 25:
		fx.slow_remaining = 0.32
	audio.intensity = minf(1, count / 15.0)

func _on_chain_complete(direct: int, activations: int) -> void:
	if state != "playing":
		return
	var refunds := 0
	if direct >= balance.direct_refund:
		refunds += 1
	var threshold := 5 if upgrades.has("recycle") else balance.combo_refund
	if activations >= threshold:
		refunds += 1
	refunds = mini(refunds, balance.max_refunds_per_chain)
	cuts = mini(balance.max_cuts, cuts + refunds)
	if cuts == 0 and upgrades.has("chance") and not chance_used and activations >= 2:
		cuts = 1
		chance_used = true
		hud.announce("ÚLTIMA CHANCE  /  +1 CORTE")
	elif refunds > 0:
		hud.announce("REAÇÃO PERFEITA  /  +%d CORTE%s" % [refunds, "S" if refunds > 1 else ""])
	elif activations == 0:
		hud.announce("ATRAVESSE AS FORMAS COM A LÂMINA")
	if score.round_score >= target:
		_finish_round()
	elif cuts <= 0:
		_game_over()
	else:
		# Keep opportunities available, without multiplying reaction descendants infinitely.
		var count := arena.targets().size()
		for i in maxi(0, 15 - count):
			var available := [0, 1, 3, 4] if round_number < 2 else [0, 1, 2, 3, 4]
			if round_number >= 3:
				available.append(5)
			arena.spawn(available.pick_random(), Vector2(randf_range(160, 1760), randf_range(300, 800)), randf_range(35, 55), Vector2.from_angle(randf() * TAU) * 70)
		blade.enabled = true

func _record() -> void:
	settings.best_score = maxi(settings.best_score, score.total)
	settings.best_round = maxi(settings.best_round, round_number)
	settings.save_profile()

func _finish_round() -> void:
	state = "upgrades"
	blade.enabled = false
	blade.cancel()
	Engine.time_scale = 1.0
	_record()
	get_tree().paused = true
	audio.play("win")
	screens.show_upgrades()

func take_upgrade(id: String) -> void:
	if state != "upgrades":
		return
	upgrades[id] = mini(3, int(upgrades.get(id, 0)) + 1)
	round_number += 1
	_start_round()

func _game_over() -> void:
	state = "game_over"
	blade.enabled = false
	blade.cancel()
	Engine.time_scale = 1.0
	_record()
	get_tree().paused = true
	audio.play("lose")
	screens.show_game_over()

func toggle_pause() -> void:
	if state == "playing":
		state = "paused"
		blade.cancel()
		paused_scale = Engine.time_scale
		get_tree().paused = true
		screens.show_pause()
	elif state == "paused":
		state = "playing"
		get_tree().paused = false
		Engine.time_scale = paused_scale
		screens.clear()
		screens.screen_name = ""

func _unhandled_key_input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	match event.keycode:
		KEY_ESCAPE:
			if screens.screen_name == "settings":
				screens.close_settings()
			elif screens.screen_name == "guide":
				screens.show_menu()
			else:
				toggle_pause()
		KEY_R:
			if state in ["playing", "paused", "game_over"]:
				start_run()
		KEY_F11:
			settings.fullscreen = not settings.fullscreen
			apply_settings()
			settings.save_profile()
		KEY_1, KEY_2, KEY_3:
			if state == "upgrades":
				screens.choose(event.keycode - KEY_1)

func _process(delta: float) -> void:
	if not is_instance_valid(arena):
		return
	var pointer_mode := Input.MOUSE_MODE_HIDDEN if state=="playing" and arena.bounds.has_point(get_global_mouse_position()) else Input.MOUSE_MODE_VISIBLE
	if Input.mouse_mode != pointer_mode:
		Input.mouse_mode = pointer_mode
	if not get_tree().paused:
		camera.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * fx.shake_amount * settings.shake
	if state == "playing" and not get_tree().paused:
		gravity_timer -= delta
		if upgrades.has("gravity") and gravity_timer <= 0:
			gravity_timer = 5.0
			arena.wells.append({"point": Vector2(960, 545), "time": 1.5})
			fx.ring(Vector2(960, 545), 360, Color("a889ff"))
