class_name SplitSettings
extends RefCounted

var master := 0.8
var music := 0.5
var sfx := 0.8
var shake := 0.5
var crt := true
var high_fx := true
var fullscreen := false
var best_score := 0
var best_round := 1
var ephemeral := false

func load_profile() -> void:
	ephemeral = "--test" in OS.get_cmdline_user_args()
	if ephemeral:
		return
	var config := ConfigFile.new()
	if config.load("user://profile.cfg") != OK:
		return
	for key in ["master", "music", "sfx", "shake", "crt", "high_fx", "fullscreen", "best_score", "best_round"]:
		set(key, config.get_value("split", key, get(key)))
	master = clampf(master, 0, 1)
	music = clampf(music, 0, 1)
	sfx = clampf(sfx, 0, 1)
	shake = clampf(shake, 0, 1)

func save_profile() -> void:
	if ephemeral:
		return
	var config := ConfigFile.new()
	for key in ["master", "music", "sfx", "shake", "crt", "high_fx", "fullscreen", "best_score", "best_round"]:
		config.set_value("split", key, get(key))
	config.save("user://profile.cfg")
