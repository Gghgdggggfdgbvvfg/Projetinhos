class_name SplitBalance
extends Resource

@export var starting_cuts: int = 3
@export var max_cuts: int = 6
@export var direct_refund: int = 3
@export var combo_refund: int = 8
@export var max_refunds_per_chain: int = 2
@export var max_activations: int = 64
@export var max_objects: int = 36
@export var max_fragments: int = 80
@export var fragment_lifetime: float = 4.0
@export var minimum_fragment_area: float = 65.0
@export var reaction_interval: float = 0.075
@export var settle_time: float = 1.2
@export var first_targets: PackedInt32Array = PackedInt32Array([500, 1200, 2500, 4500, 7500])

func target_for_round(round_number: int) -> int:
	if round_number <= first_targets.size():
		return first_targets[round_number - 1]
	return int(7500.0 * pow(1.38, round_number - 5))
