class_name ObjectCatalog
extends RefCounted

const COLORS := [Color("00dfff"), Color("ff2108"), Color("52ff8a"), Color("ffe000"), Color("f008ce"), Color("9b55ff")]
const NAMES := ["MULTIPLICADOR", "EXPLOSIVO", "CONDUTOR", "OURO", "FRAGMENTADOR", "GRAVITACIONAL"]
const SIDES := [5, 4, 3, 6, 5, 24]
const POINTS := [70, 90, 80, 180, 90, 110]
const GLYPHS := ["+", "!", "Y", "$", "/", "O"]
const DESCRIPTIONS := ["Cria dois alvos menores. Filhos não se multiplicam.", "Explode e ativa alvos próximos.", "Conecta até três alvos vizinhos.", "Mais pontos e bônus nesta reação.", "Divide em quatro fragmentos físicos.", "Atrai os objetos ao redor por 2 segundos."]
