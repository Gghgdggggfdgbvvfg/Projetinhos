class_name UpgradeCatalog
extends RefCounted

const RARITIES := ["COMUM", "INCOMUM", "RARA", "ÉPICA", "LENDÁRIA"]
const COLORS := [Color("b8c1df"), Color("68ffac"), Color("00d9ff"), Color("c183ff"), Color("ffe338")]
const IDS := ["ghost", "explosive", "recycle", "domino", "electric", "double", "chaos", "gravity", "precision", "growing", "freeze", "chance"]

static func all() -> Array[UpgradeData]:
	var result: Array[UpgradeData] = []
	for id in IDS:
		result.append(load("res://resources/upgrades/" + id + ".tres") as UpgradeData)
	return result

static func choices(owned: Dictionary) -> Array[UpgradeData]:
	var pool: Array[UpgradeData] = []
	for item in all():
		if not owned.has(item.id):
			pool.append(item)
	var result: Array[UpgradeData] = []
	while result.size() < 3 and not pool.is_empty():
		# Rarity-weighted sampling without replacement.
		var total_weight := 0.0
		for item in pool:
			total_weight += [5.0, 4.0, 3.0, 2.0, 1.0][item.rarity]
		var roll := randf() * total_weight
		for i in pool.size():
			roll -= [5.0, 4.0, 3.0, 2.0, 1.0][pool[i].rarity]
			if roll <= 0.0:
				result.append(pool[i])
				pool.remove_at(i)
				break
	return result
