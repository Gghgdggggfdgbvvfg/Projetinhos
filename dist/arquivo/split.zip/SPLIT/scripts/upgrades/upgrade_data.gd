class_name UpgradeData
extends Resource

@export var id: String = ""
@export var title: String = ""
@export var description: String = ""
@export var rarity: int = 0
@export var icon: String = ""
@export var synergy: String = ""
@export var synergy_text: String = ""
