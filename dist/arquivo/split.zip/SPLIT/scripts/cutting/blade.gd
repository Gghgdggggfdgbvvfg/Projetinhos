class_name SplitBlade
extends Node2D

signal released(path: PackedVector2Array)
var enabled := false
var dragging := false
var path := PackedVector2Array()
var arena := Rect2(56, 105, 1808, 940)
var cursor := Vector2.ZERO
var cursor_tail: Array[Vector2] = []

func _process(_delta: float) -> void:
	if enabled and arena.has_point(cursor):
		cursor_tail.append(cursor)
		if cursor_tail.size() > 13:
			cursor_tail.pop_front()
	else:
		cursor_tail.clear()
	queue_redraw()

func cancel() -> void:
	dragging = false
	path.clear()
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if not enabled:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		cursor = get_global_transform_with_canvas().affine_inverse() * event.position
		if event.pressed and arena.has_point(cursor):
			dragging = true
			path = PackedVector2Array([cursor])
		elif not event.pressed and dragging:
			dragging = false
			path.append(cursor.clamp(arena.position, arena.end))
			if path.size() > 1:
				released.emit(path.duplicate())
			path.clear()
	elif event is InputEventMouseMotion:
		cursor = get_global_transform_with_canvas().affine_inverse() * event.position
		if dragging:
			var point := cursor.clamp(arena.position, arena.end)
			if point.distance_to(path[-1]) > 9.0 and path.size() < 160:
				path.append(point)
	queue_redraw()

func _draw() -> void:
	if not enabled:
		return
	if arena.has_point(cursor):
		for i in range(1,cursor_tail.size()):
			var fraction := float(i)/cursor_tail.size()
			draw_line(cursor_tail[i-1],cursor_tail[i],Color(0.67,0.28,1,fraction*0.8),fraction*11.0,true)
		draw_circle(cursor, 20, Color(0.8,0.6,1,0.045))
		draw_circle(cursor, 10, Color(1,0.96,1,0.22))
		draw_circle(cursor, 7, Color.WHITE)
	if path.size() < 2:
		return
	draw_polyline(path, Color(0.7, 0.2, 1, 0.08), 24, true)
	draw_polyline(path, Color(0.3, 0.8, 1, 0.3), 9, true)
	draw_polyline(path, Color("f5f7ff"), 2.5, true)
	draw_circle(path[0], 5, Color("00d9ff"))
