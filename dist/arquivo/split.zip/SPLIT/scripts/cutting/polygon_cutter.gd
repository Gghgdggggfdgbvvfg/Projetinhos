class_name PolygonCutter
extends RefCounted
## Finite stroke intersection followed by convex half-plane clipping.
## Tangencies, zero length strokes and near-zero area pieces are rejected.
const EPS := 0.001

static func area(poly: PackedVector2Array) -> float:
	var sum := 0.0
	for i in poly.size():
		sum += poly[i].cross(poly[(i + 1) % poly.size()])
	return absf(sum) * 0.5

static func centroid(poly: PackedVector2Array) -> Vector2:
	var sum := Vector2.ZERO
	var weight := 0.0
	for i in poly.size():
		var a := poly[i]
		var b := poly[(i + 1) % poly.size()]
		var cross := a.cross(b)
		sum += (a + b) * cross
		weight += cross
	return sum / (3.0 * weight) if absf(weight) > EPS else poly[0]

static func regular(sides: int, radius: float) -> PackedVector2Array:
	var points := PackedVector2Array()
	for i in sides:
		points.append(Vector2.from_angle(TAU * i / sides - PI * 0.5) * radius)
	return points

static func half_plane(poly: PackedVector2Array, a: Vector2, b: Vector2, side: float) -> PackedVector2Array:
	var result := PackedVector2Array()
	var direction := (b - a).normalized()
	for i in poly.size():
		var p := poly[i]
		var q := poly[(i + 1) % poly.size()]
		var dp := direction.cross(p - a) * side
		var dq := direction.cross(q - a) * side
		if dp >= -EPS:
			_append_unique(result, p)
		if (dp > EPS and dq < -EPS) or (dp < -EPS and dq > EPS):
			_append_unique(result, p.lerp(q, dp / (dp - dq)))
	if result.size() > 1 and result[0].distance_squared_to(result[-1]) < EPS * EPS:
		result.remove_at(result.size() - 1)
	return result

static func _append_unique(poly: PackedVector2Array, point: Vector2) -> void:
	if poly.is_empty() or poly[-1].distance_squared_to(point) > EPS * EPS:
		poly.append(point)

static func stroke(poly: PackedVector2Array, path: PackedVector2Array, min_area: float = 1.0) -> Dictionary:
	var hits: Array[Vector2] = []
	for i in range(1, path.size()):
		var segment_hits: Array[Vector2] = []
		for j in poly.size():
			var hit = Geometry2D.segment_intersects_segment(path[i - 1], path[i], poly[j], poly[(j + 1) % poly.size()])
			if hit != null:
				segment_hits.append(hit)
		segment_hits.sort_custom(func(a: Vector2, b: Vector2): return a.distance_squared_to(path[i - 1]) < b.distance_squared_to(path[i - 1]))
		for hit in segment_hits:
			if hits.is_empty() or hits[-1].distance_squared_to(hit) > 0.01:
				hits.append(hit)
		if hits.size() >= 2:
			var direction := (hits[1] - hits[0]).normalized()
			var a := hits[0] - direction * 2.0
			var b := hits[1] + direction * 2.0
			var pieces := split(poly, a, b, min_area)
			if not pieces.is_empty():
				return {"pieces": pieces, "a": a, "b": b}
	return {}

static func split(poly: PackedVector2Array, a: Vector2, b: Vector2, min_area: float = 1.0) -> Array[PackedVector2Array]:
	var empty: Array[PackedVector2Array] = []
	if poly.size() < 3 or a.distance_squared_to(b) < 1.0:
		return empty
	# Both crossings must lie on the actual stroke, not its infinite extension.
	var crossings: Array[Vector2] = []
	for i in poly.size():
		var hit = Geometry2D.segment_intersects_segment(a, b, poly[i], poly[(i + 1) % poly.size()])
		if hit != null:
			var unique := true
			for p in crossings:
				if p.distance_squared_to(hit) < 0.01:
					unique = false
			if unique:
				crossings.append(hit)
	if crossings.size() < 2:
		return empty
	var first := half_plane(poly, a, b, 1.0)
	var second := half_plane(poly, a, b, -1.0)
	if first.size() < 3 or second.size() < 3:
		return empty
	if area(first) < min_area or area(second) < min_area:
		return empty
	return [first, second]
