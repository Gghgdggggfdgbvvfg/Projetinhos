class_name SplitBackground
extends Node2D

var time := 0.0
var menu := true
var haze: GradientTexture2D

func _ready() -> void:
	haze = GradientTexture2D.new()
	haze.width = 512
	haze.height = 512
	haze.fill = GradientTexture2D.FILL_RADIAL
	haze.fill_from = Vector2(0.52,0.59)
	haze.fill_to = Vector2(1.0,1.0)
	var gradient := Gradient.new()
	gradient.set_color(0,Color("291443"))
	gradient.set_color(1,Color("080513"))
	haze.gradient = gradient

func _process(delta: float) -> void:
	time += delta
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(0,0,1920,1080),Color("100a25"))
	if haze:
		draw_texture_rect(haze,Rect2(0,0,1920,1080),false)
	for bar in [Rect2(76,590,13,150),Rect2(1829,395,13,150)]:
		for spread in [17.0,9.0,4.0]:
			draw_rect(bar.grow(spread),Color(1,0.3,0.8,0.012 if spread>10 else 0.035))
		draw_style_box(SplitDesign.box(Color("ffdeff"),Color("ff9ed8"),4),bar)
	for i in 18:
		var point := Vector2(fposmod(i*317.1+time*2,1920),fposmod(i*191.7-time*4,1080))
		draw_circle(point,0.7,Color(0.5,0.65,1,0.12))
