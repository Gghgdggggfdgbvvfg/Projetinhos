class_name SplitEffects
extends Node2D

var particles: Array[Dictionary] = []
var rings: Array[Dictionary] = []
var lines: Array[Dictionary] = []
var labels: Array[Dictionary] = []
var high_quality := true
var shake_amount := 0.0
var slow_remaining := 0.0
var hit_stop_remaining := 0.0

func crack(a: Vector2, b: Vector2, color: Color, combo: int) -> void:
	var direction := (b-a).normalized()
	var normal := direction.orthogonal()
	lines.append({"path":PackedVector2Array([a-direction*12,b+direction*12]),"c":Color.WHITE,"life":0.32})
	for i in (32 if high_quality else 16):
		if particles.size() >= (650 if high_quality else 250):
			break
		var side := -1 if i%2==0 else 1
		particles.append({"p":a.lerp(b,randf()),"v":normal*side*randf_range(150,580)+direction*randf_range(-160,160),"life":randf_range(0.25,0.65),"max":0.7,"c":Color.WHITE if i%4==0 else color,"s":randf_range(2,6),"shard":i%3==0})
	rings.append({"p":(a+b)*0.5,"radius":95.0,"c":color,"life":0.32})
	if combo==1:
		hit_stop_remaining = 0.045
	elif combo%6==0:
		hit_stop_remaining = 0.025
	shake_amount = minf(14,4+combo*0.4)

func burst(point: Vector2, color: Color, count: int = 22) -> void:
	var amount := count if high_quality else count / 2
	for i in amount:
		if particles.size() >= (650 if high_quality else 250):
			break
		particles.append({"p": point, "v": Vector2.from_angle(randf() * TAU) * randf_range(60, 360), "life": randf_range(0.3, 0.8), "max": 0.8, "c": color, "s": randf_range(1.5, 4.5)})
	shake_amount = minf(shake_amount + 2, 13)

func ring(point: Vector2, radius: float, color: Color) -> void:
	if rings.size() < 32:
		rings.append({"p": point, "radius": radius, "c": color, "life": 0.5})

func line(a: Vector2, b: Vector2, color: Color) -> void:
	var points := PackedVector2Array([a])
	for i in range(1, 6):
		points.append(a.lerp(b, i / 6.0) + Vector2(randf_range(-12, 12), randf_range(-12, 12)))
	points.append(b)
	if lines.size() < 40:
		lines.append({"path": points, "c": color, "life": 0.25})

func slash(path: PackedVector2Array) -> void:
	lines.append({"path": path, "c": Color.WHITE, "life": 0.4})

func popup(point: Vector2, caption: String, color: Color) -> void:
	if labels.size() < 32:
		labels.append({"p": point, "text": caption, "c": color, "life": 1.1})

func clear() -> void:
	particles.clear()
	rings.clear()
	lines.clear()
	labels.clear()
	shake_amount = 0
	slow_remaining = 0
	hit_stop_remaining = 0
	Engine.time_scale = 1.0

func _process(delta: float) -> void:
	var real_delta := delta / maxf(0.1, Engine.time_scale)
	slow_remaining = maxf(0,slow_remaining-real_delta)
	hit_stop_remaining = maxf(0,hit_stop_remaining-real_delta)
	Engine.time_scale = 0.08 if hit_stop_remaining>0 else (0.62 if slow_remaining>0 else 1.0)
	shake_amount = move_toward(shake_amount, 0, real_delta * 20)
	for i in range(particles.size() - 1, -1, -1):
		var particle := particles[i]
		particle.life -= delta
		particle.p += particle.v * delta
		particle.v *= exp(-delta * 2.8)
		if particle.life <= 0:
			particles.remove_at(i)
	for collection in [rings, lines, labels]:
		for i in range(collection.size() - 1, -1, -1):
			collection[i].life -= delta
			if collection == labels:
				collection[i].p.y -= delta * 32
			if collection[i].life <= 0:
				collection.remove_at(i)
	queue_redraw()

func _draw() -> void:
	for p in particles:
		var color: Color = p.c
		color.a = clampf(p.life / 0.35, 0, 1)
		if high_quality:
			draw_circle(p.p, p.s * 2.5, Color(color, color.a * 0.07))
		if p.get("shard",false):
			var axis: Vector2 = p.v.normalized()
			var side: Vector2 = axis.orthogonal()
			draw_colored_polygon(PackedVector2Array([p.p+axis*p.s*2.5,p.p-axis*p.s+side*p.s,p.p-axis*p.s-side*p.s]),color)
		else:
			draw_line(p.p,p.p-p.v.normalized()*p.s*3.0,color,p.s,true)
	for ring_data in rings:
		var progress: float = 1.0 - ring_data.life / 0.5
		draw_arc(ring_data.p, ring_data.radius * progress, 0, TAU, 80, Color(ring_data.c, (1.0 - progress) * 0.75), 2, true)
	for l in lines:
		if l.path.size() < 2:
			continue
		var alpha: float = minf(1, l.life / 0.25)
		draw_polyline(l.path, Color(l.c, alpha * 0.08), 25, true)
		draw_polyline(l.path, Color(l.c, alpha * 0.35), 8, true)
		draw_polyline(l.path, Color(l.c, alpha), 2, true)
	for label_data in labels:
		var point: Vector2 = label_data.p
		var alpha: float = minf(1, label_data.life / 0.4)
		PixelText.draw(self,label_data.text.replace("×","X"),point,2.4,Color(label_data.c,alpha),true)
