class_name SplitDesign
extends RefCounted

const INK := Color("100a25")
const CYAN := Color("00d9ff")
const PINK := Color("ff36c7")
const WHITE := Color("f5f7ff")
const MUTED := Color("9690b0")

static func box(fill: Color, border: Color = Color.TRANSPARENT, radius: int = 8) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 22
	style.content_margin_right = 22
	return style

static func label(parent: Node, text: String, point: Vector2, size: int, color: Color = WHITE, width: float = 900) -> Label:
	var node := Label.new()
	node.text = text
	node.position = point
	node.size = Vector2(width, size * 1.6)
	node.add_theme_font_size_override("font_size", size)
	node.add_theme_color_override("font_color", color)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(node)
	return node

static func paragraph(parent: Node, text: String, rect: Rect2, size: int = 22, color: Color = MUTED) -> Label:
	var node := Label.new()
	node.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	node.text = text
	node.position = rect.position
	node.size = rect.size
	node.add_theme_font_size_override("font_size", size)
	node.add_theme_color_override("font_color", color)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(node)
	return node

static func button(parent: Node, text: String, rect: Rect2, action: Callable, primary: bool = false, accent: Color = CYAN) -> Button:
	var node := Button.new()
	node.text = text
	node.position = rect.position
	node.size = rect.size
	node.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	node.add_theme_font_size_override("font_size", 24)
	node.add_theme_color_override("font_color", INK if primary else WHITE)
	node.add_theme_color_override("font_hover_color", INK if primary else accent)
	node.add_theme_color_override("font_pressed_color", INK if primary else WHITE)
	node.add_theme_color_override("font_focus_color", INK if primary else WHITE)
	node.add_theme_stylebox_override("normal", box(accent if primary else Color("1a1231"), accent if primary else Color("3a2d56")))
	node.add_theme_stylebox_override("hover", box(accent.lightened(0.2) if primary else Color("241b3a"), accent))
	node.add_theme_stylebox_override("pressed", box(accent.darkened(0.15) if primary else Color("30214b"), accent))
	node.add_theme_stylebox_override("focus", box(Color.TRANSPARENT, WHITE))
	node.pressed.connect(action)
	parent.add_child(node)
	return node

static func panel(parent: Node, rect: Rect2, color: Color = Color("151025"), border: Color = Color("3a2d56")) -> Panel:
	var node := Panel.new()
	node.position = rect.position
	node.size = rect.size
	node.add_theme_stylebox_override("panel", box(color, border, 12))
	parent.add_child(node)
	return node
