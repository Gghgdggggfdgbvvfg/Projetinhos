class_name SplitHUD
extends Control

var game: Node
var displayed_score := 0.0
var displayed_progress := 0.0
var notice := ""
var notice_time := 0.0
var tick := 0.0
var hint_left := 7.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var pause := SplitDesign.button(self,"II",Rect2(1868,42,35,36),func(): game.toggle_pause())
	pause.add_theme_font_size_override("font_size",16)
	pause.add_theme_stylebox_override("normal",SplitDesign.box(Color.TRANSPARENT,Color.TRANSPARENT,0))
	pause.add_theme_color_override("font_color",Color(0.8,0.6,1,0.3))
	pause.tooltip_text = "Pausa · Esc"

func announce(text: String) -> void:
	notice = text
	notice_time = 1.5

func _process(delta: float) -> void:
	if not visible or not game.score:
		return
	tick += delta
	hint_left = maxf(0,hint_left-delta)
	displayed_score = lerpf(displayed_score,game.score.round_score,1.0-exp(-delta*17))
	displayed_progress = lerpf(displayed_progress,minf(1,float(game.score.round_score)/game.target),1.0-exp(-delta*9))
	notice_time = maxf(0,notice_time-delta)
	queue_redraw()

func _frame(rect: Rect2, color: Color) -> void:
	draw_rect(rect,Color(color,0.045))
	draw_rect(rect.grow(3),Color(color,0.08),false,6)
	draw_rect(rect,Color(color,0.65),false,2)
	draw_rect(rect.grow(-6),Color(color,0.38),false,1)

func _draw() -> void:
	if not game or not game.score:
		return
	_frame(Rect2(72,32,448,69),Color("a126ea"))
	draw_rect(Rect2(96,45,47,45),Color("028bc5"))
	draw_polyline(PackedVector2Array([Vector2(111,56),Vector2(126,68),Vector2(111,80)]),Color("153651"),3,true)
	draw_line(Vector2(104,68),Vector2(126,68),Color("153651"),3,true)
	for i in 6:
		draw_rect(Rect2(162+i*27,57,19,21),Color("049cd9") if i<game.cuts else Color(0.03,0.2,0.4,0.35))
	PixelText.draw(self,str(game.cuts),Vector2(476,55),3.3,Color("ed24cf"))
	var score_text := "%04d / %04d" % [roundi(displayed_score),game.target]
	var pixel := minf(4.6,330.0/(score_text.length()*6))
	var score_point := Vector2(1360-PixelText.width(score_text,pixel),51)
	PixelText.draw(self,score_text,score_point+Vector2(2,1),pixel,Color(1,0.2,0.5,0.38),true)
	PixelText.draw(self,score_text,score_point,pixel,Color("fff6ff"),true)
	var bar := Rect2(1376,49,438,38)
	_frame(bar,Color("008baf"))
	draw_rect(Rect2(1384,56,422*displayed_progress,23),Color(0.0,0.7,0.85,0.35))
	var caption := "RODADA %02d" % game.round_number
	PixelText.draw(self,caption,Vector2(1595-PixelText.width(caption,2.4)/2,60),2.4,Color("caa9dd"))
	if game.reactions.active and game.score.activations>=3:
		var combo := "COMBO X%d" % game.score.multiplier()
		var pixel_scale := 3.0+sin(tick*15)*0.1
		PixelText.draw(self,combo,Vector2(960-PixelText.width(combo,pixel_scale)/2,123),pixel_scale,Color("ffb9ed"),true)
	if notice_time>0 and game.score.activations>0:
		var font := ThemeDB.fallback_font
		var w := font.get_string_size(notice,HORIZONTAL_ALIGNMENT_LEFT,-1,19).x
		draw_string(font,Vector2(960-w/2,1010),notice,HORIZONTAL_ALIGNMENT_LEFT,-1,19,Color(0.9,0.8,1,minf(0.8,notice_time)))
	elif hint_left>0:
		var text := "SEGURE E ARRASTE PARA CORTAR   /   ESC PAUSA"
		PixelText.draw(self,text,Vector2(960-PixelText.width(text,1.8)/2,1012),1.8,Color(0.6,0.5,0.8,minf(0.65,hint_left)))
