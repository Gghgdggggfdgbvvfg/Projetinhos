class_name SplitScreens
extends Control

var game: Node
var surface: Control
var offers: Array[UpgradeData] = []
var screen_name := ""
var settings_return := "menu"

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func clear() -> void:
	if is_instance_valid(surface):
		remove_child(surface)
		surface.queue_free()
	surface = Control.new()
	surface.size = Vector2(1920, 1080)
	surface.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(surface)

func _shade(alpha: float = 0.9) -> void:
	var shade := ColorRect.new()
	shade.color = Color(0.025, 0.015, 0.065, alpha)
	shade.size = Vector2(1920, 1080)
	surface.add_child(shade)

func _button(text: String, rect: Rect2, action: Callable, primary: bool = false, accent: Color = SplitDesign.CYAN) -> Button:
	var button := SplitDesign.button(surface, text, rect, func():
		game.audio.play("ui")
		action.call(), primary, accent)
	button.mouse_entered.connect(func(): game.audio.play("ui", 1.25))
	return button

func show_menu() -> void:
	clear()
	screen_name = "menu"
	SplitDesign.panel(surface,Rect2(115,285,495,520),Color(0.04,0.02,0.1,0.82),Color(0.48,0.08,0.7,0.5))
	var logo := Control.new()
	logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	logo.draw.connect(func():
		PixelText.draw(logo,"SPLIT",Vector2(159,347),12,Color(1,0.0,0.7,0.2),true)
		PixelText.draw(logo,"SPLIT",Vector2(156,343),12,Color("f5efff"),true)
		PixelText.draw(logo,"ONE MORE CUT",Vector2(159,454),3,Color("ec32d0")))
	surface.add_child(logo)
	SplitDesign.paragraph(surface,"Divida formas. Provoque reações.\nFaça cada corte valer.",Rect2(157,513,410,77),22,Color("d4c2e8"))
	var play := _button("JOGAR   →",Rect2(157,618,410,64),game.start_run,true)
	play.grab_focus()
	_button("COMO JOGAR",Rect2(157,702,195,48),show_guide).add_theme_font_size_override("font_size",16)
	_button("CONFIGURAÇÕES",Rect2(368,702,199,48),func():show_settings("menu")).add_theme_font_size_override("font_size",16)
	_button("SAIR",Rect2(157,837,100,42),func():game.get_tree().quit()).add_theme_font_size_override("font_size",14)
	SplitDesign.label(surface,"RECORDE %06d" % game.settings.best_score,Vector2(350,848),16,SplitDesign.MUTED)

func show_guide() -> void:
	clear()
	screen_name = "guide"
	_shade(0.96)
	SplitDesign.label(surface, "MANUAL DA LÂMINA", Vector2(180, 90), 18, SplitDesign.CYAN)
	SplitDesign.label(surface, "Três cortes. Faça valer.", Vector2(180, 135), 54)
	SplitDesign.paragraph(surface, "Segure o botão esquerdo, atravesse as formas e solte. Curvas funcionam: cada forma é dividida entre a entrada e a saída da lâmina. Gestos acima de 25 px gastam um corte, mesmo se errarem.", Rect2(180, 231, 1500, 95), 24)
	SplitDesign.label(surface, "3 ALVOS DIRETOS = +1 CORTE     /     8 ATIVAÇÕES = +1 CORTE", Vector2(180, 340), 24, SplitDesign.PINK)
	for i in 6:
		var x := 180.0 + (i % 3) * 525
		var y := 430.0 + (i / 3) * 165
		SplitDesign.panel(surface, Rect2(x, y, 495, 142), Color("17102c"), Color(ObjectCatalog.COLORS[i], 0.4))
		SplitDesign.label(surface, ObjectCatalog.GLYPHS[i], Vector2(x + 22, y + 20), 34, ObjectCatalog.COLORS[i])
		SplitDesign.label(surface, ObjectCatalog.NAMES[i], Vector2(x + 83, y + 23), 18, ObjectCatalog.COLORS[i])
		SplitDesign.paragraph(surface, ObjectCatalog.DESCRIPTIONS[i], Rect2(x + 83, y + 64, 380, 66), 18)
	SplitDesign.paragraph(surface, "Alcance a meta e escolha uma melhoria. Fragmentos não pontuam por si; com Efeito Dominó, suas colisões ativam novos alvos. Reações devolvem no máximo 2 cortes. Novos tipos surgem nas rodadas 2 e 3.", Rect2(180, 795, 1480, 80), 20)
	_button("ENTENDI. VAMOS CORTAR.  ↗", Rect2(180, 920, 480, 65), game.start_run, true)
	_button("VOLTAR", Rect2(1445, 920, 255, 65), show_menu)

func show_pause() -> void:
	clear()
	screen_name = "pause"
	_shade(0.87)
	SplitDesign.label(surface, "TEMPO SUSPENSO", Vector2(695, 254), 19, SplitDesign.CYAN)
	SplitDesign.label(surface, "Só mais um corte.", Vector2(695, 300), 53)
	SplitDesign.label(surface, "Sua reação continua exatamente de onde parou.", Vector2(695, 391), 20, SplitDesign.MUTED)
	SplitDesign.label(surface,"PARTIDA",Vector2(135,300),18,SplitDesign.CYAN)
	SplitDesign.label(surface,"TOTAL %06d\nRODADA %02d\nMELHOR COMBO %d" % [game.score.total,game.round_number,game.score.best_combo],Vector2(135,348),25)
	var arsenal := PackedStringArray()
	for data in UpgradeCatalog.all():
		if game.upgrades.has(data.id):
			arsenal.append(data.title)
	SplitDesign.paragraph(surface,"ARSENAL\n"+"\n".join(arsenal),Rect2(135,510,435,410),18)
	_button("CONTINUAR     →", Rect2(695, 479, 530, 72), game.toggle_pause, true).grab_focus()
	_button("CONFIGURAÇÕES", Rect2(695, 575, 530, 66), func(): show_settings("pause"))
	_button("REINICIAR PARTIDA", Rect2(695, 662, 530, 66), game.start_run)
	_button("MENU PRINCIPAL", Rect2(695, 749, 530, 66), game.show_menu)

func show_settings(from_screen: String) -> void:
	settings_return = from_screen
	clear()
	screen_name = "settings"
	_shade(0.96)
	SplitDesign.label(surface, "AJUSTE SUA FREQUÊNCIA", Vector2(480, 130), 17, SplitDesign.CYAN)
	SplitDesign.label(surface, "Configurações", Vector2(480, 174), 57)
	var specs := [["Volume geral", "master"], ["Música", "music"], ["Efeitos sonoros", "sfx"], ["Intensidade do impacto", "shake"]]
	for i in specs.size():
		var y := 300.0 + i * 78
		SplitDesign.label(surface, specs[i][0], Vector2(480, y), 22)
		var value := SplitDesign.label(surface, "%d%%" % int(game.settings.get(specs[i][1]) * 100), Vector2(1380, y), 19, SplitDesign.CYAN, 100)
		var slider := HSlider.new()
		slider.position = Vector2(1010, y + 5)
		slider.size = Vector2(330, 30)
		slider.min_value = 0
		slider.max_value = 1
		slider.step = 0.01
		slider.value = game.settings.get(specs[i][1])
		slider.add_theme_stylebox_override("slider", SplitDesign.box(Color("3a2d56")))
		slider.add_theme_stylebox_override("grabber_area", SplitDesign.box(SplitDesign.CYAN))
		var key: String = specs[i][1]
		slider.value_changed.connect(func(v: float):
			game.settings.set(key, v)
			value.text = "%d%%" % int(v * 100)
			game.apply_settings())
		surface.add_child(slider)
	var toggles := [["Filtro CRT", "crt"], ["Efeitos em alta qualidade", "high_fx"], ["Tela cheia", "fullscreen"]]
	for i in toggles.size():
		var y := 632.0 + i * 67
		SplitDesign.label(surface, toggles[i][0], Vector2(480, y), 22)
		var toggle := CheckButton.new()
		toggle.position = Vector2(1170, y)
		toggle.size = Vector2(235, 40)
		toggle.text = "ATIVADO" if game.settings.get(toggles[i][1]) else "DESATIVADO"
		toggle.button_pressed = game.settings.get(toggles[i][1])
		toggle.add_theme_font_size_override("font_size", 16)
		var key: String = toggles[i][1]
		toggle.toggled.connect(func(v: bool):
			game.settings.set(key, v)
			toggle.text = "ATIVADO" if v else "DESATIVADO"
			game.apply_settings())
		surface.add_child(toggle)
	_button("SALVAR E VOLTAR", Rect2(480, 886, 945, 68), close_settings, true)

func close_settings() -> void:
	game.settings.save_profile()
	if settings_return == "pause":
		show_pause()
	else:
		show_menu()

func show_upgrades() -> void:
	clear()
	screen_name = "upgrades"
	_shade(0.94)
	offers = UpgradeCatalog.choices(game.upgrades)
	SplitDesign.label(surface, "RODADA %02d CONCLUÍDA   /   +%d PONTOS" % [game.round_number, game.score.round_score], Vector2(180, 126), 18, SplitDesign.CYAN)
	SplitDesign.label(surface, "Escolha seu próximo caos.", Vector2(180, 173), 57)
	SplitDesign.label(surface, "Uma melhoria. Novas possibilidades. Os efeitos duram toda a partida.", Vector2(180, 267), 23, SplitDesign.MUTED)
	for i in offers.size():
		var data := offers[i]
		var x := 180.0 + i * 530
		var color: Color = UpgradeCatalog.COLORS[data.rarity]
		SplitDesign.panel(surface, Rect2(x, 367, 500, 480), Color("17102b"), Color(color, 0.5))
		SplitDesign.label(surface, "0%d   /   %s" % [i + 1, UpgradeCatalog.RARITIES[data.rarity]], Vector2(x + 32, 394), 16, color)
		SplitDesign.label(surface, data.icon, Vector2(x + 32, 452), 54, color)
		SplitDesign.label(surface, data.title, Vector2(x + 32, 548), 30, SplitDesign.WHITE, 440)
		SplitDesign.paragraph(surface, data.description, Rect2(x + 32, 605, 430, 124), 21)
		if game.upgrades.has(data.synergy):
			SplitDesign.paragraph(surface, "SINERGIA ATIVA\n" + data.synergy_text, Rect2(x + 32, 737, 430, 82), 17, SplitDesign.CYAN)
		else:
			SplitDesign.label(surface, "UMA NOVA POSSIBILIDADE", Vector2(x + 32, 764), 14, Color(color, 0.8))
		var choice := i
		_button("ESCOLHER   [%d]" % (i + 1), Rect2(x, 874, 500, 67), func(): choose(choice), true, color)
	if offers.is_empty():
		SplitDesign.label(surface, "ARSENAL COMPLETO", Vector2(540, 460), 42, SplitDesign.PINK)
		SplitDesign.paragraph(surface, "Todas as melhorias estão ativas. Continue aumentando seu recorde. Seu arsenal completo concede até 3 cortes iniciais extras.", Rect2(540, 550, 800, 130), 26)
		_button("PRÓXIMA RODADA  →", Rect2(540, 750, 800, 75), func(): game.take_upgrade("mastery"), true)
	SplitDesign.label(surface, "PRÓXIMA META  %d     /     CORTES RECARREGADOS" % game.balance.target_for_round(game.round_number + 1), Vector2(180, 1003), 16, SplitDesign.MUTED)

func choose(index: int) -> void:
	if screen_name == "upgrades" and index >= 0 and index < offers.size():
		game.take_upgrade(offers[index].id)

func show_game_over() -> void:
	clear()
	screen_name = "game_over"
	_shade(0.94)
	SplitDesign.label(surface, "FIM DA REAÇÃO", Vector2(420, 146), 18, SplitDesign.PINK)
	SplitDesign.label(surface, "Ainda cabe mais um.", Vector2(420, 194), 64)
	SplitDesign.label(surface, "%06d" % game.score.total, Vector2(420, 306), 100)
	SplitDesign.label(surface, "PONTUAÇÃO TOTAL", Vector2(427, 445), 18, SplitDesign.MUTED)
	var stats := [["RODADA", "%02d" % game.round_number], ["MAIOR COMBO", "%d ativações" % game.score.best_combo], ["OBJETOS CORTADOS", str(game.score.objects_cut)]]
	for i in 3:
		var x := 420.0 + i * 360
		SplitDesign.panel(surface, Rect2(x, 515, 335, 125))
		SplitDesign.label(surface, stats[i][0], Vector2(x + 24, 535), 15, SplitDesign.MUTED)
		SplitDesign.label(surface, stats[i][1], Vector2(x + 24, 569), 30)
	var names := PackedStringArray()
	for data in UpgradeCatalog.all():
		if game.upgrades.has(data.id):
			names.append(data.title)
	SplitDesign.paragraph(surface, "SEU ARSENAL\n" + (" · ".join(names) if not names.is_empty() else "Uma nova partida, uma nova possibilidade."), Rect2(420, 690, 1060, 130), 20)
	_button("MAIS UMA PARTIDA     ↗", Rect2(420, 872, 660, 77), game.start_run, true).grab_focus()
	_button("MENU", Rect2(1104, 872, 370, 77), game.show_menu)
