class_name ScoreState
extends RefCounted

var total := 0
var round_score := 0
var best_combo := 0
var objects_cut := 0
var activations := 0
var gold_bonus := 0

func begin_chain() -> void:
	activations = 0
	gold_bonus = 0

func multiplier() -> int:
	if activations >= 25:
		return 10
	if activations >= 12:
		return 5
	if activations >= 6:
		return 3
	if activations >= 3:
		return 2
	return 1

func activate(kind: int, round_number: int, precision: bool = false) -> int:
	activations += 1
	objects_cut += 1
	best_combo = maxi(best_combo, activations)
	if kind == 3:
		gold_bonus = mini(gold_bonus + 1, 4)
	var points := int(ObjectCatalog.POINTS[kind] * (1.0 + (round_number - 1) * 0.32))
	points *= multiplier() + gold_bonus
	if precision:
		points = int(points * 1.75)
	total += points
	round_score += points
	return points
