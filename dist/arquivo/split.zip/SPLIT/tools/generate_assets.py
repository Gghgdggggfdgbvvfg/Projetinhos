from pathlib import Path
import math, random, struct, wave

ROOT = Path(__file__).resolve().parents[1]
audio = ROOT / 'assets' / 'audio'
audio.mkdir(parents=True, exist_ok=True)
random.seed(7)
RATE = 22050

def save(name, duration, synth):
    with wave.open(str(audio / (name + '.wav')), 'wb') as f:
        f.setparams((1, 2, RATE, 0, 'NONE', 'not compressed'))
        values = []
        for i in range(int(duration * RATE)):
            t = i / RATE
            values.append(struct.pack('<h', int(max(-0.95, min(0.95, synth(t))) * 32767)))
        f.writeframes(b''.join(values))

tau = math.tau
save('slice', .23, lambda t: ((random.random()*2-1)*.5 + math.sin(tau*(1800*t-2800*t*t))*.15) * math.sin(math.pi*t/.23)**2 * math.exp(-t*12))
def crack(t):
    # A dry crack, low impact and bright crystalline tail, all synthesized.
    snap = (random.random()*2-1)*.63*math.exp(-t*145)
    body = math.sin(tau*(155*t+1.6*(1-math.exp(-t*40))))*.42*math.exp(-t*26)
    glass = sum(math.sin(tau*f*t)*.065 for f in [1760,2349,3136])*math.exp(-t*17)
    return snap+body+glass
save('impact', .34, crack)
save('explosion', .6, lambda t: ((random.random()*2-1)*.5 + math.sin(tau*(90*t-50*t*t))*.35)*math.exp(-t*8))
save('combo', .4, lambda t: (math.sin(tau*(660 if t<.12 else 880 if t<.24 else 1320)*t)*.26)*math.exp(-t*6))
save('ui', .1, lambda t: math.sin(tau*880*t)*.2*math.exp(-t*45))
save('win', .8, lambda t: sum(math.sin(tau*f*t)*.12 for f in [261.63,329.63,392,523.25])*min(1,t*35)*math.exp(-t*4))
save('lose', .75, lambda t: math.sin(tau*(220*t-90*t*t))*.25*min(1,t*30)*math.exp(-t*5))

# Original 8-bar, 112.5 BPM synth loop; no sampled or third-party audio.
beat = 60/112.5
duration = beat*32
notes = [110, 130.8128, 164.8138, 146.8324]
arp = [0, 7, 12, 19, 12, 7, 3, 10]
def music(t):
    phase = t % beat
    bar = int(t/(beat*8)) % 4
    root = notes[bar]
    kick = math.sin(tau*(47*phase + 8*(1-math.exp(-phase*25)))) * math.exp(-phase*19)*.36
    bass = math.sin(tau*root*t)*.16*(.7+.3*math.exp(-phase*10))
    step = int(t/(beat/2))
    env = math.exp(-(t%(beat/2))*16)
    frequency = root*2*2**(arp[step%8]/12)
    melody = (math.sin(tau*frequency*t)+.16*math.sin(tau*frequency*2*t))*.11*env
    hat_phase=t%(beat/2)
    hat=(random.random()*2-1)*.045*math.exp(-hat_phase*85)
    pad=sum(math.sin(tau*root*2**(n/12)*t) for n in [0,3,7])*.035
    # Short fades on loop seam eliminate discontinuity clicks.
    fade=min(1,t/.015,(duration-t)/.015)
    return (kick+bass+melody+hat+pad)*fade
save('music', duration, music)

upgrades = [
('ghost','Corte Fantasma','Uma segunda lâmina acompanha seu gesto, 42 px ao lado. Não consome cortes extras.',2,'//','explosive','Duas lâminas. O dobro de epicentros.'),
('explosive','Reação Explosiva','Todo alvo cortado libera uma explosão curta que pode ativar os vizinhos.',3,'*','ghost','Corte Fantasma espalha as explosões.'),
('recycle','Reciclagem','Recupere 1 corte com 5 ativações, em vez de 8. Até 2 cortes recuperados por gesto.',0,'+','electric','Descargas ajudam a alcançar o combo.'),
('domino','Efeito Dominó','Fragmentos acima de 220 px/s ativam alvos ao colidir. Cada fragmento ativa uma vez.',4,'>>','chaos','Mais fragmentos, mais colisões possíveis.'),
('electric','Lâmina Elétrica','Cada ativação conduz uma descarga a um alvo próximo, a até 280 px.',3,'Z','recycle','Reações longas recuperam seus cortes.'),
('double','Corte Duplo','Adiciona uma lâmina paralela a 48 px do outro lado. Combina com Corte Fantasma.',2,'II','ghost','Três trajetórias em um único gesto.'),
('chaos','Fragmentação Caótica','Cada alvo se divide em até quatro polígonos físicos, em vez de dois.',1,'X','domino','Cada fragmento vira uma nova oportunidade.'),
('gravity','Gravidade Instável','A cada 5 segundos, um pulso atrai os alvos ao centro e reorganiza a arena.',1,'O','explosive','Aglomerados ampliam as reações explosivas.'),
('precision','Precisão Perfeita','Cortes a menos de 22% do raio do centro recebem 75% mais pontos.',0,'+','freeze','Alvos lentos facilitam cortes centrais.'),
('growing','Explosão Crescente','Explosões ganham 6 px de alcance por ativação, até um bônus de 125 px.',2,'<>','explosive','Toda explosão cresce junto com a reação.'),
('freeze','Reação Congelante','Cada corte desacelera os alvos em um raio de 220 px por 2,2 segundos.',1,'#','precision','Mais controle para acertar o centro.'),
('chance','Última Chance','Uma vez por rodada, ao chegar a zero com pelo menos 2 ativações, recupere 1 corte.',0,'1','domino','Uma colisão tardia pode salvar a rodada.'),
]
folder = ROOT/'resources'/'upgrades'
folder.mkdir(parents=True,exist_ok=True)
for id,title,description,rarity,icon,synergy,synergy_text in upgrades:
    def quote(s): return '"'+s.replace('"','\\"')+'"'
    content='[gd_resource type="Resource" script_class="UpgradeData" load_steps=2 format=3]\n[ext_resource type="Script" path="res://scripts/upgrades/upgrade_data.gd" id="1"]\n[resource]\nscript = ExtResource("1")\n'
    for k,v in dict(id=id,title=title,description=description,rarity=rarity,icon=icon,synergy=synergy,synergy_text=synergy_text).items():
        content+=f'{k} = {v if isinstance(v,int) else quote(v)}\n'
    (folder/(id+'.tres')).write_text(content,encoding='utf-8')
print('Generated 8 original audio files and 12 upgrade resources.')

