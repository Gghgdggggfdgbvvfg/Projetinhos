# Verificação — 30/10/2026

Engine usada: **Godot 4.7.2 stable**, Windows x86_64, renderizador OpenGL Compatibility. Nenhum perfil real do jogador foi alterado nos testes.

## Testes automatizados

Resultado: **5.400 verificações, 0 falhas** em `tests/run_all.gd`. O número inclui verificações repetidas de propriedades geométricas e limites durante a simulação; não representa 5.400 casos de gameplay diferentes.

- 1.200 divisões de polígonos convexos com 3–24 lados, ângulos e tamanhos variados; conservação de área e centroides finitos.
- Cortes horizontal, vertical, diagonal por vértices, curva atravessando um alvo, curva que contorna um alvo, tangência, segmento curto e borda degenerada.
- Eventos de pressionar, mover e soltar no mesmo frame. Corrigido o uso da posição final consultada do mouse: a lâmina usa a posição de cada evento.
- Fragmentos físicos dos seis tipos; duplicação limitada do azul; quatro peças do rosa; explosão, condução e campo de atração.
- Devolução de cortes, tiers de combo, limite de duas devoluções, pontuação sem duplicação.
- Doze melhorias exercitadas, incluindo **colisão física real de um fragmento em outro alvo** com Efeito Dominó.
- Pausa com eventos pendentes, retomada, meta atingida, três cartas, avanço de rodada, game over e reinício limpo.
- Estresse com 36 alvos e todas as melhorias: limites de 80 fragmentos e 64 ativações respeitados, reação encerrada.
- Criação dos menus de ajuda e configurações, retorno e isolamento do perfil de teste.

A execução final não reportou erros de script, recursos pendentes ou objetos vazados. Áudio é omitido no driver headless; o áudio normal é carregado e executado na sessão com janela.

## Verificação visual e interação

Capturas renderizadas pela Godot foram inspecionadas para arena, ruptura, menu, cartas, manual e configurações. Um problema de texto escapando das cartas foi corrigido definindo a quebra de linha antes do tamanho dos labels.

O executável Windows exportado foi aberto diretamente. Foram verificados: botão Jogar, arrasto diagonal com fragmentação visível, aumento de pontos, término de reação, tela de melhorias, escolha por teclado, início da rodada 2, arsenal persistente, pausa e retomada por Esc. A inicialização headless do executável também foi concluída.

## Desempenho

Medição de 10 segundos em janela 1440×810, Radeon RX 7600, efeitos altos e todas as melhorias, com descarte dos dois primeiros segundos:

- Tempo médio por frame: **13,78 ms** (aproximadamente 72,6 FPS).
- Percentil 95: **27,45 ms**.
- 582 amostras; pico de 80 fragmentos e 283 partículas.

Essa medição ocorreu enquanto outra verificação automatizada usava CPU. Não demonstra 60 FPS constantes nem cobre outros computadores. O script `tests/benchmark.gd` permite repetir a medição isoladamente.

## Limites da validação

Balanceamento de rodadas muito altas, conforto do CRT/tremor em sessões longas, variedade musical e desempenho em GPUs integradas ainda merecem testes com jogadores. A divisão geométrica valida polígonos convexos; não há corte côncavo arbitrário. Compatibilidade com versões diferentes da Godot 4.7.2 não foi executada.
