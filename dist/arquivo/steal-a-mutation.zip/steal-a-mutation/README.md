# Steal a Mutation

Arquitetura inicial de um simulator multiplayer Roblox para coleção de criaturas mutantes, produção de DNA, melhorias de bases e roubo. Esta entrega prepara contratos e inicialização; **não implementa gameplay ou persistência**.

## Onde começar

- `AGENTS.md`: regras de trabalho, identidade visual, padrões de código e segurança.
- `docs/ARCHITECTURE.md`: responsabilidades, dependências e fluxo futuro dos sistemas.
- `docs/NETWORK.md`: envelopes, ações e validações previstas para a rede.
- `docs/VALIDATION.md`: inspeção e resultados das verificações desta entrega.
- `default.project.json`: mapeamento Rojo; `rokit.toml`: Rojo fixado em 7.7.1.

## Estrutura

| Pasta | Destino / responsabilidade |
| --- | --- |
| `src/shared` | `ReplicatedStorage.StealAMutation.Shared`: tipos, configurações públicas, catálogos, protocolo e utilitários |
| `src/server` | `ServerScriptService.StealAMutationServer`: bootstrap, oito serviços, esquema e adapter privado |
| `src/client` | `StarterPlayer.StarterPlayerScripts.StealAMutationClient`: bootstrap, oito controllers e contratos de UI |
| `src/ui` | `StarterGui.StealAMutationUI`: ScreenGui vazio e desativado |
| `scripts` | Validador local e checks executáveis no Studio, fora da árvore de produção |
| `build` | Place da arquitetura, sourcemap e relatório gerados pelo Rojo |

O projeto também reserva `ServerStorage.StealAMutationAssets/{Creatures,Bases,Capsules}` e `Workspace.StealAMutationWorld/{Bases,SpawnPoints,Capsules}`. São pastas vazias: não há modelos, sons, imagens ou IDs fictícios.

## Rodar com Rojo

Requer Roblox Studio, Python 3.10+ para o validador e Rojo 7.7.1. A configuração do editor recomenda as extensões Rojo e Luau LSP, mas não as instala.

Com [Rokit](https://github.com/rojo-rbx/rokit) já instalado, abra o terminal **nesta pasta**:

```powershell
rokit install
python scripts/validate.py --rojo rojo
rojo serve default.project.json --address 127.0.0.1
```

Sem Rokit, obtenha o executável da [release oficial do Rojo 7.7.1](https://github.com/rojo-rbx/rojo/releases/tag/v7.7.1), coloque-o no PATH ou passe seu caminho ao validador:

```powershell
python scripts/validate.py --rojo C:\ferramentas\rojo.exe
```

Instale o plugin Rojo correspondente no Studio conforme a [documentação oficial](https://rojo.space/docs/v7/getting-started/installation/). No plugin, conecte a `localhost:34872`, revise a prévia e sincronize com o place correto. O projeto usa preservação de instâncias desconhecidas no mapa e nas pastas de código, conforme o [formato do Rojo](https://rojo.space/docs/v7/project-format/). Arquivos conhecidos pelo Rojo continuam sendo gerenciados por ele: mantenha alterações de código na fonte local.

O destino confirmado é **Roube uma Mutação**, PlaceId **103267208724119**. `servePlaceIds` restringe a sincronização a esse ID. Para usar outro place, revise e altere explicitamente essa lista. A preparação desta arquitetura não publica alterações no Roblox.

Nesta entrega a cópia inicial no Studio é aplicada pela conexão MCP, a partir dos arquivos locais. Isso não significa que o plugin Rojo esteja instalado ou que exista sincronização contínua. Não foram alterados PATH, plugins globais ou configurações de produção.

## Validar e gerar o place

```powershell
# Somente estrutura, JSON, imports explícitos, dependências e guardas do scaffold:
python scripts/validate.py

# As mesmas verificações + build Rojo e comparação dos Sources exportados:
python scripts/validate.py --rojo rojo

# Equivalentes diretos:
rojo build default.project.json --output build/StealAMutation.rbxlx
rojo sourcemap default.project.json --output build/sourcemap.json --include-non-scripts
```

O build `build/StealAMutation.rbxlx` contém **somente a arquitetura mapeada**, sem copiar baseplate, terreno ou outros objetos já existentes em um place. Ele serve para inspecionar o scaffold isolado. A sincronização no place existente preserva esses objetos; abrir o build é abrir outro place.

Com a árvore sincronizada e o Studio parado em Edit, execute o conteúdo de `scripts/lifecycle-checks.luau` e `scripts/scaffold-checks.luau` na Command Bar. Depois use Play, confira as mensagens de inicialização de servidor/cliente no Output e volte a Edit. Os scripts de verificação não são mapeados pelo Rojo.

## Limites deliberados

Todos os FeatureFlags começam em `false`. Os contratos de domínio devolvem `{ ok = false, code = "NOT_IMPLEMENTED", ... }`; não simulam carregamento bem-sucedido. O catálogo está vazio e a GUI desligada. O adapter não lê nem escreve DataStore. Não é necessário ativar acesso às APIs do Studio.

Há canais RemoteEvent declarados, mas nenhum listener nem envio de mensagens de gameplay. Antes de conectá-los, implemente validação de payload, limitação por jogador/ação, autorização e correlação/idempotência. Alterar uma flag não implementa essas proteções.

A ordem sugerida de implementação é persistência e sessão, coleção/economia, bases/cápsulas, transação de roubo, interface/eventos. As garantias de proteção contra duplicação e recuperação precisam ser implementadas e testadas antes de habilitar roubo.
