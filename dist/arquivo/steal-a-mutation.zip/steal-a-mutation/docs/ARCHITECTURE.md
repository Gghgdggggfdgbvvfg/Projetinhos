# Arquitetura — Steal a Mutation

O projeto prepara um simulator multiplayer no qual criaturas mutantes produzem DNA, bases oferecem capacidade e progressão, cápsulas originam criaturas e jogadores podem disputar propriedade por roubo. Esta entrega define os lugares e contratos desses sistemas. Ainda não calcula produção, sorteia criaturas, transfere propriedade, salva perfis ou apresenta uma interface jogável.

## Limites da implementação

O bootstrap e os módulos estabelecem um ciclo de vida verificável. As ações de gameplay continuam como stubs e respondem com `NOT_IMPLEMENTED`; os recursos ficam desativados por padrão. O adapter de persistência não executa chamadas a DataStore. Os remotes existem como contrato estrutural, sem handlers de gameplay nesta fase.

Não há pacotes externos obrigatórios, modelos de criaturas, mapa completo, ferramentas de administração, monetização nem dependência de assets remotos. Pastas de assets são pontos de extensão, não modelos já entregues.

## Fonte de verdade e mapeamento

O código local e o arquivo de projeto Rojo descrevem a hierarquia desejada. Uma cópia inserida no Studio por ferramentas de inspeção ou sincronização continua sendo derivada dessa fonte. Alterações no Studio que devam persistir precisam ser reconciliadas com os arquivos locais antes da próxima sincronização.

| Fonte ou declaração Rojo | Destino Roblox | Responsabilidade |
| --- | --- | --- |
| `src/shared` | `ReplicatedStorage.StealAMutation.Shared` | Tipos, configuração pública, protocolo e utilitários |
| Remotes declarados no projeto | `ReplicatedStorage.StealAMutation.Remotes` | Instâncias de comunicação |
| `src/server` | `ServerScriptService.StealAMutationServer` | Bootstrap, serviços, política de persistência e storage |
| `src/client` | `StarterPlayer.StarterPlayerScripts.StealAMutationClient` | Bootstrap do cliente, controllers e helpers de UI |
| `src/ui` | `StarterGui.StealAMutationUI` | `ScreenGui` desativada, preparada para futuras telas |
| Pastas declaradas no projeto | `ServerStorage.StealAMutationAssets` | Assets de criaturas, bases e cápsulas, sem execução implícita |
| Pastas declaradas no projeto | `Workspace.StealAMutationWorld` | Pontos de organização do mundo: bases, spawns e cápsulas |

Os namespaces isolam o scaffold de outros conteúdos do place. Ao conectar Rojo a um lugar existente, confira o diff e preserve filhos não mapeados. Não substitua o DataModel nem remova scripts, terrenos ou modelos preexistentes para acomodar o scaffold.

## Organização das fontes

```text
src/
  shared/
    Types.luau
    Config/
      GameConfig.luau
      FeatureFlags.luau
      EconomyConfig.luau
      MutationCatalog.luau
      BaseConfig.luau
      CapsuleCatalog.luau
      EventCatalog.luau
      Theme.luau
    Network/Protocol.luau
    Util/
      Result.luau
      Lifecycle.luau
      AwaitChild.luau
  server/
    bootstrap.server.luau
    ServiceSupport.luau
    Services/
      DataService.luau
      EconomyService.luau
      MutationService.luau
      BaseService.luau
      CapsuleService.luau
      TheftService.luau
      EventService.luau
      NetworkService.luau
    Storage/
      ProfileSchema.luau
      DataStoreAdapter.luau
    Config/PersistenceConfig.luau
  client/
    bootstrap.client.luau
    Controllers/
      DataController.luau
      EconomyController.luau
      MutationController.luau
      BaseController.luau
      CapsuleController.luau
      TheftController.luau
      EventController.luau
      UIController.luau
    UI/
      ViewRegistry.luau
      Formatters.luau
  ui/
    init.meta.json
```

`Types` documenta os formatos compartilhados. Configs e catálogos concentram parâmetros e IDs estáveis; valores iniciais são material de estruturação, não uma economia balanceada. `Theme` concentra a identidade visual. `Result` padroniza os resultados explícitos. `Lifecycle` organiza dependências e inicialização. `AwaitChild` evita esperas indefinidas ao resolver instâncias necessárias.

## Fronteiras dos serviços

| Serviço | Responsabilidade futura | O que não deve assumir |
| --- | --- | --- |
| `DataService` | Sessão do jogador, estado autoritativo, carregamento, atualização e salvamento | Um erro de leitura não significa perfil novo |
| `EconomyService` | Produção, saldo, preço e débitos/créditos validados | Quantidades ou preços enviados pelo cliente |
| `MutationService` | IDs de criaturas, propriedade, catálogo e regras de mutação | Resultados aleatórios calculados pelo cliente |
| `BaseService` | Alocação, slots, capacidade, upgrades e proteção | Atributos de modelos como fonte única de propriedade |
| `CapsuleService` | Elegibilidade, custo, sorteio e concessão de criaturas | Débito e concessão independentes sem recuperação |
| `TheftService` | Elegibilidade, disputa, transferência e recuperação | Atomicidade entre dois perfis por usar DataStore |
| `EventService` | Estado e calendário de eventos do jogo | Relógio do cliente como autoridade |
| `NetworkService` | Fronteira entre remotes, validação e despacho | Tipos Luau como validação de payload em runtime |

Dependências concretas ficam declaradas em cada módulo e são verificadas pelo bootstrap. A direção conceitual parte de dados e regras fundamentais para orquestração: dados sustentam economia, criaturas e bases; cápsulas e roubo combinam essas regras; a camada de rede será a entrada validada das intenções do cliente. Serviços não importam controllers nem acessam diretamente telas.

`ProfileSchema` é o ponto de definição do perfil serializável e de sua versão. `DataStoreAdapter` isola a API de armazenamento. `PersistenceConfig` fica exclusivamente no servidor, pois configura ambiente e política de persistência. Essa separação permite evoluir o adapter sem acoplar gameplay a chamadas diretas ao DataStore. `ServiceSupport` reúne helpers do servidor e cria estado de ciclo de vida independente para cada serviço.

## Cliente e interface

`DataController` será responsável pela cópia de estado autorizada para o jogador local. Os controllers de economia, mutações, bases, cápsulas, roubo e eventos traduzirão esse estado e as intenções do jogador para suas respectivas áreas da interface. `UIController` coordenará exibição, foco e navegação.

`ViewRegistry` reserva o catálogo de telas e `Formatters` concentra apresentação de valores. A `ScreenGui` inicial permanece desativada para não ocupar a tela com controles sem funcionalidade. Nenhum controller concede DNA, calcula o resultado de uma cápsula ou confirma o roubo por conta própria.

A direção visual está descrita em `AGENTS.md`: laboratório lúdico, fundo azul-marinho, verde-lima para DNA, ciano para informação e violeta para mutações. As telas futuras devem funcionar com toque e gamepad, respeitar áreas seguras e comunicar estado sem depender exclusivamente de cor.

## Ciclo de vida

1. O bootstrap resolve as pastas obrigatórias com limite de espera e carrega os módulos, sem efeitos colaterais em `require`.
2. O executor valida nomes e dependências, detecta referências ausentes e ordena os módulos de acordo com essas dependências.
3. `Init` recebe o contexto de cada módulo. Todos os módulos são inicializados antes que qualquer `Start` seja chamado.
4. `Start` é o ponto futuro para ativar tarefas e conexões autorizadas pelas flags. Nesta fase, não inicia loops de gameplay nem chamadas a DataStore.
5. `Destroy` encerra recursos em ordem inversa. O executor deve limpar também uma inicialização parcialmente concluída quando possível.

A ordem não deve depender da ordem arbitrária de `GetChildren`. Adicionar um módulo exige atualizar o registro do bootstrap e suas dependências, além de confirmar que todas as instâncias necessárias existem no mapeamento.

## Rede e fluxo futuro de ações

Todos os canais são `RemoteEvent` e ficam sob `ReplicatedStorage.StealAMutation.Remotes`:

| Canal | Direção prevista | Finalidade |
| --- | --- | --- |
| `RequestAction` | Cliente → servidor | Intenção de uma ação e dados mínimos necessários |
| `ActionResult` | Servidor → cliente | Resultado de uma solicitação, correlacionado à intenção |
| `StateSnapshot` | Servidor → cliente | Estado completo autorizado ao destinatário |
| `StateDelta` | Servidor → cliente | Alteração incremental do estado autorizado |
| `EventNotice` | Servidor → cliente | Avisos e estados de eventos do jogo |

O protocolo compartilhado é o lugar de nomes e contratos. A existência dos canais não indica que ações já estejam disponíveis: não há handlers de gameplay conectados nesta entrega.

O fluxo planejado é: controller envia intenção; `NetworkService` valida estrutura, tamanho, frequência e identidade; o serviço responsável valida a regra e o estado atual; a operação altera o estado autoritativo; só então resultado e estado visível são enviados ao cliente. IDs de solicitação deverão permitir correlação; ações suscetíveis a replay também precisarão de idempotência no servidor.

Snapshots não devem divulgar o perfil inteiro. Progresso privado, configuração de armazenamento e dados internos ficam no servidor. Deltas futuros precisam de versionamento e estratégia de ressincronização; o cliente não pode assumir que toda atualização foi recebida em ordem ou aplicada com sucesso.

## Persistência: desenho a implementar

Antes de habilitar carregamento real, definir uma máquina de estados de sessão: carregando, pronta, indisponível e encerrando. Somente uma sessão pronta pode aceitar alterações que dependam do perfil. Um erro de carregamento mantém a sessão indisponível; não cria um perfil vazio para sobrescrever o antigo.

Uma sessão futura deve adquirir um lock persistente com identificador e prazo, renová-lo e confirmar sua propriedade em cada gravação. A atualização deve usar `UpdateAsync` e callback puro, porque o callback pode ser repetido. Retries precisam de limites, backoff, jitter e observação dos orçamentos da API.

Perfis levam versão de esquema; migrações são explícitas, verificáveis e preservam os dados necessários. O sistema deve recusar versões incompatíveis sem sobrescrevê-las. O encerramento precisa tentar concluir operações dentro do tempo disponível e deixar informação suficiente para recuperação quando isso não for possível.

Esses mecanismos ainda não estão implementados. A presença de `ProfileSchema`, `DataStoreAdapter` e `PersistenceConfig` somente reserva as fronteiras onde serão desenvolvidos.

## Roubo: desenho a implementar

Cada criatura precisa de um ID estável e exatamente um proprietário confirmado. O roubo será uma operação do servidor, com validação de alvo, propriedade, proteção, distância, cooldown, capacidade do destino e estado atual dos participantes. Uma operação que aguarde deve revalidar as condições antes de confirmar a transferência.

Para impedir duplicação e perda, o protocolo futuro deve definir um ID de transferência, locks adquiridos em ordem determinística, registro persistente da intenção, fases recuperáveis, commit idempotente e reconciliação após desconexão ou crash. O saldo/inventário exibido deve refletir apenas estados permitidos pelo protocolo.

`UpdateAsync` atualiza uma chave por operação; não torna a alteração de dois perfis atomicamente indivisível. A escolha do registro de propriedade e da estratégia de recuperação deve ser fechada e testada antes da implementação de roubo. Nenhum método do scaffold deve sugerir que essa garantia já existe.

## Próximas etapas e critérios de avanço

1. **Infraestrutura executável:** confirmar build Rojo, inicialização sem referências ausentes e limpeza do ciclo de vida no Studio. Essa etapa não ativa gameplay.
2. **Dados e confiabilidade:** implementar sessões, adapter, migrações e política de recuperação; testar indisponibilidade, concorrência e perda de lock em ambiente isolado.
3. **Coleção e economia:** implementar criaturas e produção com IDs estáveis, saldo válido, limites de ganho e operações idempotentes; testar invariantes antes de conectar UI.
4. **Bases e cápsulas:** implementar capacidade, ocupação, upgrades e sorteio no servidor com débito/concessão recuperáveis.
5. **Roubo:** definir e testar a transação de propriedade, inclusive falhas entre fases, reconexão e recuperação.
6. **Interface e eventos:** conectar snapshots/deltas, acessibilidade, feedback, eventos e telemetria às operações já validadas; medir desempenho com múltiplos jogadores.

Nenhuma etapa deve avançar apenas porque os arquivos existem. Os critérios são comportamento observado, invariantes preservadas e falhas recuperáveis. Os comandos de setup e o registro das validações desta entrega ficam no `README.md`.

