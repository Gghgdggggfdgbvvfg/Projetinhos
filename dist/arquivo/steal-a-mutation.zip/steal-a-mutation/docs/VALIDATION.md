# Registro de validação — 23/10/2026

## Inspeção e preservação

A pasta local estava vazia e não havia AGENTS.md ancestral aplicável. O Studio inicialmente mostrou Place1 sem scripts; depois passou a identificar **Roube uma Mutação**, PlaceId **103267208724119**, GameId **10772598261**. O usuário confirmou que é o mesmo projeto, apenas renomeado, e autorizou esse destino. A preparação desta entrega não publicou alterações.

Antes da importação, ReplicatedStorage, ServerScriptService, ServerStorage e StarterGui estavam vazios. Workspace continha Baseplate, SpawnLocation, Terrain e Camera. Foram acrescentadas 64 instâncias sob seis namespaces próprios, com registro de alterações mantido pela ferramenta do Studio.

Após o teste em Play, foram conferidos os 37 Sources contra a fonte local e a existência da cena original. Baseplate e SpawnLocation preservaram posição, tamanho, Anchored e quantidade de descendentes. Não houve edição intencional de terreno, câmera, iluminação ou configurações globais.

## Verificações executadas

| Verificação | Resultado |
| --- | --- |
| JSON, mapeamentos Rojo e metadados de preservação | Passou |
| 54 imports explícitos resolvidos até ModuleScripts existentes | Passou |
| Grafos de oito serviços e oito controllers | Passou, sem ciclos/dependências ausentes |
| Rojo 7.7.1 build e sourcemap | Passou |
| Sources do build comparados com os arquivos locais | 37 correspondências |
| Carregamento dos ModuleScripts no Studio Edit | 35 carregados sem erro |
| Ciclo de vida | 10 checks passaram |
| Smoke checks de infraestrutura e contratos | 12 grupos de checks passaram |
| Contratos inertes | 48 retornaram NOT_IMPLEMENTED, ok=false e sem data |
| Perfis novos | DNA zero, inventário vazio, tabelas independentes e rejeição de IDs/NaN/infinitos inválidos |
| Configuração | Oito flags desligadas, persistência e produção offline desligadas |
| Rede e GUI | Cinco RemoteEvents corretos, sete views válidas, ScreenGui desativada |
| Play local | Bootstraps de servidor e cliente iniciaram sem erros no Output |
| Replicação no cliente de Play | Scripts presentes em PlayerScripts; ScreenGui presente e desativada em PlayerGui |
| Paridade após Stop | 37 Sources do Studio idênticos aos arquivos importados |
| Estado final | Studio devolvido ao modo Edit |

O executável portátil usado na validação veio da [release oficial Rojo 7.7.1](https://github.com/rojo-rbx/rojo/releases/tag/v7.7.1). O SHA-256 do ZIP Windows x86_64 foi conferido contra o digest da API da release: `d4dfa3493a1613a43fc87312d6dac660d7c8bf38e6a99aa5dcd0d26154ba0b82`. A ferramenta ficou em work deste chat; não foi instalada globalmente nem incluída no pacote do projeto.

## Evidência do Output em Play

```text
[Steal a Mutation] Arquitetura iniciada; gameplay e persistência não implementados.
[Steal a Mutation] Client scaffold initialized; gameplay and interface remain disabled.
```

## Limites

Não foi executado um analisador completo de tipos Luau. Os cabeçalhos strict, imports, compilação/carregamento de módulos e execução no Studio foram verificados, mas isso não equivale a um relatório completo de tipos.

Não houve teste com vários clientes, persistência real, concorrência de gameplay, balanceamento ou segurança de sistemas implementados: esses sistemas ainda são contratos inertes. Os testes do schema não constituem implementação de migrações/locks. O catálogo vazio não contém assets de criaturas/cápsulas.

A sincronização inicial foi feita por MCP. Não foi instalado o plugin Rojo, iniciado servidor contínuo de sincronização ou publicado o jogo. O build contém somente a arquitetura mapeada; os objetos originais da cena continuam no Studio.

Para repetir as verificações, consulte README.md e os scripts em scripts/. O relatório local legível por máquina está em build/validation.json.

