# Contrato de rede a implementar

Este documento define a intenção do protocolo v1. `src/shared/Network/Protocol.luau` declara nomes e limites; não há handlers conectados. Tipos Luau não substituem validação de entrada.

## Envelopes

`RequestAction` receberá um único envelope `{ Version = 1, RequestId = string, Action = string, Payload = table }`. Limites iniciais: RequestId e identificadores até 64 bytes, payload até oito chaves, sem tabelas aninhadas livres. Rejeitar campos inesperados, números não finitos e tipos que não pertençam à ação. Valores finais e política de rate limit ainda serão definidos no servidor.

`ActionResult` enviará `{ Version = 1, RequestId = string, Result = OperationResult }` apenas ao solicitante. O cliente nunca decide o resultado de uma ação.

`StateSnapshot` enviará `{ Version = 1, Snapshot = PlayerSnapshot }` ao jogador autorizado. `StateDelta` terá `{ Version = 1, FromRevision = integer, ToRevision = integer, Changes = allowlistedFields }`. Os tipos concretos de delta serão adicionados junto à implementação; lacunas de revisão exigirão ressincronização, sem aplicar estado parcial como confirmado.

`EventNotice` terá `{ Version = 1, EventId = string, State = string, ServerTimestamp = number }`; destinatários e campos públicos serão definidos pelo EventService.

## Ações previstas

| Ação | Payload planejado | Responsável | Validações obrigatórias futuras |
| --- | --- | --- | --- |
| RequestSnapshot | vazio | NetworkService / DataService | sessão pronta, limite de frequência |
| CollectDNA | baseId | EconomyService | dono, base válida, produção e tempo calculados no servidor |
| UpgradeBase | vazio | BaseService / EconomyService | base do jogador, próximo nível, custo do catálogo, saldo e commit idempotente |
| OpenCapsule | capsuleId | CapsuleService | cápsula existente, preço no servidor, capacidade e débito/concessão recuperáveis |
| BeginTheft | creatureId | TheftService | derivar dono pelo registro do servidor, distância, proteção, estado, cooldown, capacidade |
| CancelTheft | theftId | TheftService | operação ativa pertencente ao jogador, cancelamento idempotente |
| ClaimEventReward | eventId | EventService | janela do servidor, elegibilidade e recompensa ainda não reivindicada |

Métodos internos de serviços podem exigir parâmetros adicionais. O dispatcher futuro os preencherá com dados confiáveis; ele não deve repassar cegamente o payload. Não há ação cliente para conceder DNA, sortear resultado, mudar dono, salvar perfil ou confirmar conclusão do roubo.

## Autorização e concorrência

Use o Player fornecido pelo Roblox, nunca UserId enviado como autoridade. Preços, valores produzidos, aleatoriedade, posições e elegibilidade serão calculados ou verificados no servidor. Limites e filas devem ser aplicados antes de trabalho caro; o descarte de solicitações abusivas não pode criar tarefas ilimitadas.

RequestId correlaciona mensagens; sozinho não garante idempotência. Será preciso guardar resultados/IDs de operações com limites e estratégia de persistência apropriada. Transações que podem alterar saldo/propriedade após yield exigem bloqueio, revalidação e recuperação. Consulte o desenho de persistência e roubo em `ARCHITECTURE.md`.

Referência de segurança: [fronteira cliente-servidor do Roblox](https://create.roblox.com/docs/scripting/security/client-server-boundary).
