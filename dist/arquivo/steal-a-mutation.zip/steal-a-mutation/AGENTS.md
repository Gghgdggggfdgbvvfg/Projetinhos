# Steal a Mutation — regras do projeto

Este arquivo orienta agentes e colaboradores em todo este diretório. O projeto é um simulator multiplayer Roblox: jogadores colecionam criaturas mutantes, produzem DNA, melhoram bases e disputam criaturas por meio de roubo. O scaffold prepara as fronteiras do sistema; não representa um jogo pronto.

## Escopo e preservação

- Inspecione os arquivos, o mapeamento Rojo e a hierarquia do Studio antes de alterar algo. Preserve trabalho existente e mudanças de outros colaboradores.
- O código local é a fonte de verdade. Toda sincronização com Studio deve reproduzir essa fonte nos namespaces `StealAMutation`, `StealAMutationServer`, `StealAMutationClient`, `StealAMutationUI`, `StealAMutationAssets` e `StealAMutationWorld`.
- Não exclua, renomeie, substitua nem reorganize instâncias existentes fora desses namespaces. Havendo conflito dentro deles, inspecione o conteúdo antes de substituir; interrompa apenas a operação conflitante quando não houver forma segura de preservação.
- Não faça uma sincronização abrangente que remova filhos não mapeados. Revise as opções de preservação do projeto Rojo e qualquer diff antes de aceitar a sincronização.
- Não copie scripts de Toolbox, assets executáveis desconhecidos ou dependências externas sem revisão. Não adicione pacotes sem necessidade e sem fixar versões.
- Construa sistemas em etapas pequenas e verificáveis. Não transforme stubs em sistemas completos por inferência. Monetização, produtos, passes e compras não fazem parte do escopo atual.
- Não publique o place, altere configurações de produção ou ative persistência real como efeito colateral de preparar ou testar arquitetura.
- Documente decisões, limitações e verificações realmente executadas. Nunca afirme que um teste passou sem executar e inspecionar o resultado.

## Identidade visual e experiência

A direção é um laboratório de mutantes lúdico, com aparência de brinquedos colecionáveis: formas arredondadas, cápsulas translúcidas, criaturas de silhuetas claras e máquinas fáceis de reconhecer. Humor e curiosidade guiam a experiência; evite horror gráfico.

| Uso | Cor |
| --- | --- |
| Fundo azul-marinho | `#101827` |
| DNA e ação principal, verde-lima | `#B7FF3C` |
| Informação e energia, ciano | `#36DDEB` |
| Mutação e destaque, violeta | `#A875FF` |
| Texto principal | `#F3F7FC` |
| Perigo e erro | `#FF5D73` |

- Centralize tokens em `src/shared/Config/Theme.luau`; não espalhe cores e medidas pela interface.
- Use texto e ícones junto com cor para raridade, estado, alertas e progresso. Confira contraste; cores de destaque não são automaticamente adequadas para textos pequenos.
- Priorize leitura da quantidade de DNA, ocupação da base e estado de uma criatura. Nunca apresente um resultado local como confirmado antes da resposta do servidor.
- Interfaces futuras devem atender mouse/teclado, toque e gamepad, com foco visível, navegação previsível, alvos de toque confortáveis e estado pressionado/desabilitado.
- Respeite áreas seguras da tela, recortes, barra superior e proporções de celular. Evite botões essenciais nas bordas e textos que dependam de hover.
- Não cubra eventos relevantes com efeitos intensos; ofereça redução de movimento quando animações forem implementadas. Sons não podem ser o único indicador de uma ação.
- A GUI atual é uma casca desativada. Não a apresente como uma interface completa.

## Padrões de código e arquitetura

- Use Luau com `--!strict`, identificadores em inglês e documentação orientada a usuários em português. Use `PascalCase` para módulos/tipos e `camelCase` para variáveis/funções locais. Adote o estilo do arquivo ao editar.
- Cada arquivo de módulo retorna exatamente uma API explícita. Não crie globals, dependências circulares ou serviços ocultos em módulos utilitários.
- `require` não deve conectar eventos, iniciar tarefas, acessar DataStore, criar instâncias nem alterar estado do jogo. Esses efeitos pertencem ao ciclo de vida ou a métodos explícitos.
- O bootstrap monta o contexto, resolve dependências declaradas e executa `Init` de todos os módulos antes de `Start`. Encerre em ordem inversa e libere conexões/tarefas em `Destroy`.
- Módulos em `shared` devem ser seguros para leitura por qualquer cliente. Configuração de persistência, acesso a DataStore e decisões autoritativas permanecem em `server`.
- Controllers apresentam estado e intenção. Services validam e alteram estado autoritativo. UI não importa código de servidor; serviços não dependem de controllers ou da árvore visual.
- Centralize o contrato de rede em `src/shared/Network/Protocol.luau`. Evite nomes de remotes e payloads espalhados pelo código. Trate tipos estáticos como documentação, nunca como validação de entrada de rede.
- Use esperas limitadas e erros descritivos para instâncias obrigatórias. Não mantenha `WaitForChild` infinito que esconda um erro de mapeamento.
- Prefira resultados explícitos de sucesso/erro a exceções para ações esperadas do jogador. Stubs devem retornar `NOT_IMPLEMENTED`, sem conceder recompensas ou sinalizar sucesso fictício.
- Não crie laços por frame, tarefas recorrentes, conexões de rede ou gravações durante a fase de scaffold. Toda assinatura futura precisa de política de limpeza e falha.
- Não use `wait`, `spawn` ou `delay` legados. Quando necessário, use `task.*` com cancelamento/condição de encerramento e limites claros.
- Dados de perfil devem ser serializáveis: tabelas simples, IDs estáveis e números válidos. Não armazene `Instance`, funções, referências transitórias nem segredos em perfis replicados.
- Mantenha mudanças de contrato, tipos, catálogo e documentação alinhadas. Não declare rotas, assets ou dependências que não existam.

## Segurança e economia

- O servidor controla DNA, inventário, produção, sorteio de cápsulas, mutações, bases, proteção e roubo. O cliente envia intenção; nunca determina preço, recompensa, raridade, saldo, propriedade ou resultado aleatório.
- Valide tipo, formato, tamanho e limites de cada payload. Números precisam ser finitos; rejeite `NaN`, infinitos, quantidades fracionárias quando só inteiros forem válidos, valores negativos e quantidades fora da faixa.
- Aplique limites por jogador e por ação no servidor, antes de operações caras. Limite payloads, filas e trabalho concorrente. Desconsidere IDs de usuário fornecidos como prova de identidade: use o `Player` recebido pelo servidor.
- Verifique propriedade, capacidade, distância medida no servidor, estado vivo, cooldown, proteção da base e demais pré-condições no momento da operação. Revalide antes do commit em ações que aguardem qualquer operação assíncrona.
- Use operações idempotentes quando houver possibilidade de repetição. Nunca confira saldo, suspenda a execução e debite depois sem uma estratégia de concorrência.
- Roubo futuro deve garantir uma única propriedade por criatura e um resultado recuperável. Nunca remova primeiro do dono e espere conseguir salvar/adicionar depois. Defina transação, bloqueios ordenados, cancelamento, confirmação e recuperação antes de ativá-lo.
- Transações entre dois perfis não são atômicas só por usarem `UpdateAsync`. Não prometa essa garantia; será necessário um protocolo persistente de transferência e recuperação.
- Não confie em física controlada pelo cliente, posição enviada em payloads, atributos replicados ou UI como prova suficiente de autorização.
- Não coloque chaves, tokens, endpoints privados ou configuração sensível em `ReplicatedStorage`, `StarterGui`, `StarterPlayer` ou nos logs.

## Salvamento e falhas

- Persistência começa desativada. O adapter desta fase não deve chamar DataStore. Testes do scaffold não exigem habilitar acesso às APIs do Studio.
- Antes de ativar persistência, implemente aquisição/renovação/liberação de sessão, expiração controlada de locks, migrações versionadas, validação de esquema e prevenção de gravações por uma sessão que perdeu o lock.
- Use `UpdateAsync` com callback puro e seguro para repetição. Separe ambientes e nomes de stores; trate orçamento, throttling, timeouts e retries com limites, backoff e jitter.
- Falha de leitura não equivale a jogador novo. Não substitua um perfil indisponível ou inválido por defaults e depois o salve. Bloqueie mutações e informe indisponibilidade quando não for possível garantir integridade.
- Preserve dados desconhecidos conforme política de migração e mantenha uma estratégia de recuperação. Não reduza silenciosamente a versão de um perfil.
- Encerramento e saída do jogador precisam de salvamento limitado pelo tempo disponível, prevenção de escrita duplicada e telemetria. `BindToClose` isoladamente não garante persistência.
- Não habilite recompensas, cápsulas ou roubo que exijam dados persistentes antes de a sessão estar pronta e a estratégia de recuperação estar testada.

## Validação proporcional

- Para mudanças no mapeamento ou nomes, execute build Rojo quando a ferramenta estiver disponível e confira que todos os destinos/imports existem.
- Para mudanças em bootstrap ou ciclo de vida, valide inicialização no Studio, ausência de erros e limpeza no encerramento quando houver sessão de teste disponível.
- Ao implementar economia, persistência ou transferências, teste invariantes e falhas: saldo não negativo, propriedade única, repetição de solicitações, desconexão, lock perdido, timeout e recuperação de operação incompleta.
- Não crie testes que apenas reproduzam a implementação. Registre ferramentas indisponíveis e verificações não executadas como limitações.
