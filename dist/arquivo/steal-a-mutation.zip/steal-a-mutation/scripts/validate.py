"""Valida mapa/refs/dependências do scaffold. Opcionalmente executa Rojo real.
Não é um analisador estático Luau nem um teste de gameplay.
"""
import argparse
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NODES = {}
SOURCES = {}
ERRORS = []


def check(condition, message):
    if not condition:
        ERRORS.append(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def add_node(path, class_name, source=None):
    check(path not in NODES, f"Nome de instância duplicado: {'.'.join(path)}")
    NODES[path] = class_name
    if source:
        SOURCES[path] = source


def directory(path, instance_path, override=None):
    meta_path = path / "init.meta.json"
    meta = read_json(meta_path) if meta_path.exists() else {}
    check(meta.get("ignoreUnknownInstances") is True,
          f"Preservação ausente no diretório: {path.relative_to(ROOT)}")
    add_node(instance_path, override or meta.get("className", "Folder"))
    for child in sorted(path.iterdir()):
        if child.is_dir():
            directory(child, instance_path + (child.name,))
        elif child.suffix == ".luau":
            name = child.stem
            cls = "ModuleScript"
            if name.endswith(".server"):
                name, cls = name[:-7], "Script"
            elif name.endswith(".client"):
                name, cls = name[:-7], "LocalScript"
            add_node(instance_path + (name,), cls, child)


def project_node(node, path=()):
    check(node.get("$ignoreUnknownInstances") is True,
          f"Preservação ausente no projeto: {'.'.join(path) or 'DataModel'}")
    source = node.get("$path")
    if source:
        source_path = (ROOT / source).resolve()
        check(source_path.is_relative_to(ROOT), f"Path fora do projeto: {source}")
        check(source_path.is_dir(), f"Path inexistente: {source}")
        if source_path.is_dir():
            directory(source_path, path, node.get("$className"))
    else:
        add_node(path, node.get("$className", "Folder"))
    for key, value in node.items():
        if not key.startswith("$"):
            project_node(value, path + (key,))


def resolve_require(expression, script_path, aliases):
    parts = expression.strip().split(".")
    if parts[0] == "script":
        result = script_path
    elif parts[0] in aliases:
        result = (aliases[parts[0]],)
    else:
        return None
    for part in parts[1:]:
        result = result[:-1] if part == "Parent" else result + (part,)
    return result


def validate_sources():
    require_count = 0
    for instance_path, source_path in SOURCES.items():
        text = source_path.read_text(encoding="utf-8")
        label = str(source_path.relative_to(ROOT))
        check(text.startswith("--!strict\n"), f"--!strict/encoding inválido: {label}")
        code = re.sub(r"--[^\n]*", "", text)
        aliases = dict(re.findall(r'local\s+(\w+)\s*=\s*game:GetService\("(\w+)"\)', code))
        for expression in re.findall(r"require\(([^)\n]+)\)", code):
            target = resolve_require(expression, instance_path, aliases)
            check(target is not None, f"require não rastreável: {label}: {expression}")
            if target is not None:
                check(NODES.get(target) == "ModuleScript",
                      f"require quebrado: {label} -> {'.'.join(target)}")
                if "src/client" in source_path.as_posix():
                    check(target[0] not in {"ServerStorage", "ServerScriptService"},
                          f"Cliente importa servidor: {label}")
            require_count += 1
        for forbidden in [
            r'GetService\("DataStoreService"\)', r":GetDataStore\s*\(",
            r":UpdateAsync\s*\(", r":SetAsync\s*\(",
            r"\.OnServerEvent\s*:\s*Connect", r"\.OnClientEvent\s*:\s*Connect",
            r":FireServer\s*\(", r":FireClient\s*\(", r":FireAllClients\s*\(",
        ]:
            check(not re.search(forbidden, code), f"Scaffold tem IO/rede ativa: {label}")
    return require_count


def validate_graph(relative_dir):
    graph = {}
    for source in sorted((ROOT / relative_dir).glob("*.luau")):
        code = source.read_text(encoding="utf-8")
        match = re.search(r"Dependencies\s*=\s*\{([^}]*)\}", code, re.S)
        check(match is not None, f"Dependencies ausente: {source.name}")
        if match:
            graph[source.stem] = re.findall(r'"(\w+)"', match.group(1))
    active, complete = set(), set()

    def visit(name):
        if name in complete:
            return
        if name in active:
            ERRORS.append(f"Ciclo em {relative_dir}: {name}")
            return
        active.add(name)
        for dependency in graph[name]:
            if dependency not in graph:
                ERRORS.append(f"Dependência ausente: {name} -> {dependency}")
            else:
                visit(dependency)
        active.remove(name)
        complete.add(name)

    for name in graph:
        visit(name)
    return len(graph)


def validate_build(rojo):
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    subprocess.run([rojo, "build", "default.project.json", "--output",
                    "build/StealAMutation.rbxlx"], cwd=ROOT, check=True)
    subprocess.run([rojo, "sourcemap", "default.project.json", "--output",
                    "build/sourcemap.json", "--include-non-scripts"], cwd=ROOT, check=True)
    xml = ET.parse(build / "StealAMutation.rbxlx").getroot()
    built_sources = {}
    def walk(item, path):
        props = item.find("Properties")
        name = props.find("./string[@name='Name']").text
        current = path + (name,)
        check(NODES.get(current) == item.attrib["class"],
              f"Classe/destino incorreto no build: {'.'.join(current)}")
        source = props.find("./*[@name='Source']")
        if source is not None:
            built_sources[current] = source.text or ""
        for child in item.findall("Item"):
            walk(child, current)
    for item in xml.findall("Item"):
        walk(item, ())
    check(set(built_sources) == set(SOURCES), "Scripts no build diferem da fonte")
    for path, source in built_sources.items():
        check(source == SOURCES[path].read_text(encoding="utf-8"),
              f"Source divergente: {'.'.join(path)}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rojo", help="Executável Rojo 7.7.1 para build real")
    args = parser.parse_args()
    for path in ROOT.rglob("*.json"):
        if "build" not in path.parts and ".tools" not in path.parts:
            read_json(path)
    project_node(read_json(ROOT / "default.project.json")["tree"])
    requires = validate_sources()
    services = validate_graph("src/server/Services")
    controllers = validate_graph("src/client/Controllers")
    check(services == 8 and controllers == 8, "Esperados 8 services e 8 controllers")
    for name in ["RequestAction", "ActionResult", "StateSnapshot", "StateDelta", "EventNotice"]:
        check(NODES.get(("ReplicatedStorage", "StealAMutation", "Remotes", name)) == "RemoteEvent",
              f"Remote ausente: {name}")
    flags = (ROOT / "src/shared/Config/FeatureFlags.luau").read_text(encoding="utf-8")
    check("= true" not in flags, "FeatureFlags deve permanecer desligado")
    if not ERRORS and args.rojo:
        validate_build(str(Path(args.rojo).resolve()) if Path(args.rojo).exists() else args.rojo)
    report = {
        "status": "failed" if ERRORS else "passed",
        "sources": len(SOURCES),
        "modules": sum(cls == "ModuleScript" for cls in NODES.values()),
        "requiresChecked": requires,
        "services": services,
        "controllers": controllers,
        "rojoBuildExecuted": bool(args.rojo) and not ERRORS,
        "limitations": ["Não executa análise completa de tipos Luau nem testes de gameplay."],
        "errors": ERRORS,
    }
    (ROOT / "build").mkdir(exist_ok=True)
    (ROOT / "build/validation.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    raise SystemExit(1 if ERRORS else 0)


if __name__ == "__main__":
    main()
