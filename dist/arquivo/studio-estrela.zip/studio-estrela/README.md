# Studio Estrela

Site institucional demonstrativo em React, Vite, TypeScript, Tailwind CSS, Motion e Lucide. Conteúdo em português, layout responsivo e nenhuma dependência de backend.

## Executar

Use Node.js 22.12+ ou 24 LTS, com npm instalado.

```sh
npm ci
npm run dev
```

## Validar e compilar

```sh
npm test
npm run build
npm run preview
```

Antes de executar os testes pela primeira vez, instale o navegador de teste com `npx playwright install chromium`.

## Publicar na Vercel

Importe esta pasta como um projeto Git na Vercel. O arquivo `vercel.json` define o preset Vite, `npm run build` e a pasta `dist`. Também é possível executar `npx vercel` nesta pasta usando sua conta Vercel. O site não requer variáveis de ambiente, banco ou servidor de aplicação.

## Configurar conteúdo

Edite `src/config.ts` para ajustar Instagram, endereço, catálogo de serviços e fotografias. Telefone (11) 5081-2898, sete serviços e logo foram fornecidos pelo solicitante. WhatsApp e horários permanecem não confirmados. Enquanto o catálogo estiver vazio, a seção apresenta orientações para contato, sem atribuir serviços específicos ao negócio.

Os botões de agendamento apenas abrem o Instagram. Nenhum horário é reservado ou confirmado pelo site. O mapa é uma composição ilustrativa e o link abre a pesquisa pelo endereço no Google Maps.

Esta versão comercial usa `noindex,nofollow` para evitar indexar a demonstração como página oficial. Para uma publicação oficial, confirme os dados e a autorização, troque imagens demonstrativas por material autorizado, remova essa diretiva de `index.html` e adicione canonical, og:url e sitemap com o domínio real. Título, descrição, idioma e metadados Open Graph já estão definidos. Não foram criados depoimentos, preços, equipe, horários ou dados estruturados comerciais não verificados.

## Fotografias e fontes

As três fotografias ilustrativas são distribuídas em `public/images` e foram obtidas do Unsplash:

- Retrato: https://images.unsplash.com/photo-1524504388940-b1c1722653e1
- Ambiente: https://images.unsplash.com/photo-1600948836101-f9ffda59d250
- Cosméticos: https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9

Não representam trabalhos, clientes ou o ambiente real do Studio. Fontes Cormorant Garamond e Manrope são carregadas via Google Fonts, com fallbacks locais. O restante da interface e imagens funciona sem serviços externos; Instagram e Maps são links externos.

## Organização

- `src/main.tsx`: componentes, navegação, FAQ e modal de galeria.
- `src/config.ts`: dados comerciais e imagens.
- `src/style.css`: identidade visual, responsividade e redução de movimento.
- `tests/site.spec.ts`: testes de navegação, canais de contato, imagens, modal, FAQ e layouts.
- `dist/`: resultado estático de produção.

Acessibilidade: landmarks semânticos, link de pular conteúdo, foco visível, menu com estado expandido e Escape, modal nativo com foco contido e retorno ao gatilho, textos alternativos e respeito a `prefers-reduced-motion`.
