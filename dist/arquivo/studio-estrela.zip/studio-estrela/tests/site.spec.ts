import { test, expect } from "@playwright/test";
test("navegação, imagens e canais de contato", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toContainText(
    "Seu momento",
  );
  const brokenAnchors = await page
    .locator('a[href^="#"]')
    .evaluateAll(
      (links) =>
        links.filter(
          (a) => !document.getElementById(a.getAttribute("href")!.slice(1)),
        ).length,
    );
  expect(brokenAnchors).toBe(0);
  for (const img of await page.locator("img").all()) {
    await img.scrollIntoViewIfNeeded();
    await expect(img).toHaveJSProperty("complete", true);
    expect(
      await img.evaluate((el: HTMLImageElement) => el.naturalWidth),
    ).toBeGreaterThan(0);
  }
  await expect(
    page.getByRole("link", { name: "Agendar horário" }),
  ).toHaveAttribute("href", "https://www.instagram.com/studioestrela_1211/");
  expect(await page.locator('a[href*="wa.me"]').count()).toBe(0);
  await expect(page.getByRole("link", { name: "Como chegar" })).toHaveAttribute(
    "href",
    /google.com\/maps\/search/,
  );
  expect(errors).toEqual([]);
});
test("galeria acessível abre e fecha com Escape", async ({ page }) => {
  await page.goto("/");
  const trigger = page.getByRole("button", {
    name: "Ampliar: Cosméticos em composição editorial",
  });
  await trigger.click();
  await expect(page.locator("dialog")).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Fechar imagem" }),
  ).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(page.locator("dialog")).not.toBeVisible();
  await expect(trigger).toBeFocused();
});
test("perguntas frequentes expandem e recolhem", async ({ page }) => {
  await page.goto("/");
  const question = page.getByRole("button", {
    name: "Como consultar a disponibilidade?",
  });
  await question.click();
  await expect(question).toHaveAttribute("aria-expanded", "true");
  await expect(page.locator("#answer-0")).toBeVisible();
  await question.click();
  await expect(page.locator("#answer-0")).not.toBeVisible();
});
for (const width of [320, 390, 768, 1440])
  test(`layout sem overflow em ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 900 });
    await page.goto("/");
    await page.evaluate(() => document.fonts.ready);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    if (width < 850) {
      const button = page.getByRole("button", { name: "Abrir menu" });
      await button.click();
      await expect(
        page.getByRole("button", { name: "Fechar menu" }),
      ).toHaveAttribute("aria-expanded", "true");
      await page
        .locator("#mobile-nav")
        .getByRole("link", { name: "Localização", exact: true })
        .click();
      await expect(page.locator("#mobile-nav")).toHaveCount(0);
      await expect(page).toHaveURL(/#localizacao$/);
      await page.getByRole("button", { name: "Abrir menu" }).click();
      await page.keyboard.press("Escape");
      await expect(page.locator("#mobile-nav")).toHaveCount(0);
    }
  });

test("dados confirmados e marca do Studio", async ({ page }) => {
  await page.goto("/");
  await expect(page.locator('a[href="tel:+551150812898"]')).toHaveCount(2);
  for (const name of [
    "Corte",
    "Coloração",
    "Química",
    "Design de sobrancelhas",
    "Manicure e pedicure",
    "Estética",
    "Nutricionista",
  ])
    await expect(
      page.locator("#servicos").getByRole("heading", { name, exact: true }),
    ).toBeVisible();
  await expect(page.locator("header .brand-logo")).toHaveAttribute(
    "src",
    "/images/logo-studio-estrela.png",
  );
});
test("capturas para revisão visual", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto("/");
  await page.evaluate(() => document.fonts.ready);
  for (const section of await page.locator("main section").all())
    await section.scrollIntoViewIfNeeded();
  await page.getByRole("heading", { level: 1 }).scrollIntoViewIfNeeded();
  await page.screenshot({
    path: "../studio-estrela-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.evaluate(() => document.fonts.ready);
  for (const section of await page.locator("main section").all())
    await section.scrollIntoViewIfNeeded();
  await page.getByRole("heading", { level: 1 }).scrollIntoViewIfNeeded();
  await page.screenshot({
    path: "../studio-estrela-mobile.png",
    fullPage: true,
  });
});
