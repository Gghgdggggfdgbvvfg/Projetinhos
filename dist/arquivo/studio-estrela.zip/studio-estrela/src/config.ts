export const studio = {
  name: "Studio Estrela",
  instagram: "https://www.instagram.com/studioestrela_1211/",
  handle: "@studioestrela_1211",
  address: "Rua Napoleão de Barros, 1211",
  neighborhood: "Vila Clementino, São Paulo — SP",
  phone: "(11) 5081-2898",
  phoneHref: "tel:+551150812898",
  logo: "/images/logo-studio-estrela.png",
  whatsapp: null as string | null,
  hours: null as string | null,
  services: [
    {
      name: "Corte",
      description: "Converse com o Studio sobre o corte que você deseja.",
    },
    {
      name: "Coloração",
      description: "Consulte as opções de coloração e disponibilidade.",
    },
    {
      name: "Química",
      description: "Saiba mais sobre os procedimentos oferecidos pelo Studio.",
    },
    {
      name: "Design de sobrancelhas",
      description: "Consulte detalhes e agende seu momento de cuidado.",
    },
    {
      name: "Manicure e pedicure",
      description: "Um cuidado para suas mãos e pés. Consulte a agenda.",
    },
    {
      name: "Estética",
      description: "Conheça os cuidados estéticos disponíveis.",
    },
    {
      name: "Nutricionista",
      description: "Consulte informações sobre o atendimento em nutrição.",
    },
  ],
  demo: true,
};
export const mapsUrl =
  "https://www.google.com/maps/search/?api=1&query=" +
  encodeURIComponent(`${studio.address}, ${studio.neighborhood}`);
export const photos = [
  {
    src: "/images/retrato.jpg",
    alt: "Retrato editorial em luz natural",
    title: "Beleza que é sua",
  },
  {
    src: "/images/ambiente.jpg",
    alt: "Ambiente de salão usado como referência visual",
    title: "Um tempo para você",
  },
  {
    src: "/images/beleza.jpg",
    alt: "Cosméticos em composição editorial",
    title: "Detalhes que inspiram",
  },
];
