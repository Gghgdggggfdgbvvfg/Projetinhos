import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { motion, MotionConfig, useReducedMotion } from "motion/react";
import {
  ArrowUpRight,
  ArrowDown,
  Instagram,
  Phone,
  Menu,
  X,
  MapPin,
  Plus,
  Minus,
} from "lucide-react";
import { studio, mapsUrl, photos } from "./config";
import "./style.css";
const sections = [
  ["inicio", "Início"],
  ["sobre", "Sobre"],
  ["servicos", "Serviços"],
  ["galeria", "Galeria"],
  ["localizacao", "Localização"],
  ["contato", "Contato"],
];
function Contact({
  children,
  className = "button",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <a
      className={className}
      href={studio.instagram}
      target="_blank"
      rel="noopener noreferrer"
    >
      {children}
      <ArrowUpRight size={17} />
    </a>
  );
}
function Reveal({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  const reducedMotion = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reducedMotion ? false : { opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.65 }}
    >
      {children}
    </motion.div>
  );
}
function App() {
  const [menu, setMenu] = useState(false),
    [scrolled, setScrolled] = useState(false),
    [active, setActive] = useState("inicio"),
    [faq, setFaq] = useState<number | null>(null),
    [selected, setSelected] = useState<number | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const menuButton = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        }),
      { rootMargin: "-20% 0px -55% 0px" },
    );
    document
      .querySelectorAll("main section[id]")
      .forEach((s) => observer.observe(s));
    return () => {
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, []);
  useEffect(() => {
    if (selected !== null) dialog.current?.showModal();
    else dialog.current?.close();
  }, [selected]);
  useEffect(() => {
    if (!menu) return;
    const close = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenu(false);
        menuButton.current?.focus();
      }
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [menu]);
  const questions = [
    [
      "Como consultar a disponibilidade?",
      "Envie uma mensagem ao perfil do Studio Estrela no Instagram. A disponibilidade e a confirmação do horário devem ser combinadas diretamente com o estabelecimento.",
    ],
    [
      "Onde fica o Studio Estrela?",
      `${studio.address} — ${studio.neighborhood}. Use o link de localização para traçar sua rota.`,
    ],
    [
      "Onde consultar serviços e valores?",
      "Os serviços estão apresentados nesta página. Consulte valores, detalhes e horários de funcionamento pelo Instagram ou pelo telefone (11) 5081-2898.",
    ],
  ];
  return (
    <MotionConfig reducedMotion="user">
      <a href="#conteudo" className="skip">
        Pular para o conteúdo
      </a>
      <header className={scrolled ? "header solid" : "header"}>
        <a
          className="brand"
          href="#inicio"
          aria-label="Studio Estrela — início"
        >
          <img
            className="brand-logo"
            src={studio.logo}
            alt=""
            width="56"
            height="56"
          />
          <span>
            STUDIO ESTRELA<small>BELEZA & CUIDADO</small>
          </span>
        </a>
        <nav aria-label="Navegação principal" className="desktop-nav">
          {sections.map(([id, label]) => (
            <a
              className={active === id ? "active" : ""}
              href={"#" + id}
              key={id}
            >
              {label}
            </a>
          ))}
        </nav>
        <div className="header-actions">
          <a
            className="social"
            href={studio.instagram}
            aria-label="Instagram do Studio Estrela (abre em nova aba)"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Instagram size={18} />
          </a>
          <Contact className="button small header-book">
            Agendar horário
          </Contact>
          <button
            ref={menuButton}
            className="menu-toggle"
            onClick={() => setMenu(!menu)}
            aria-expanded={menu}
            aria-controls="mobile-nav"
            aria-label={menu ? "Fechar menu" : "Abrir menu"}
          >
            {menu ? <X /> : <Menu />}
          </button>
        </div>
        {menu && (
          <nav id="mobile-nav" aria-label="Navegação mobile">
            {sections.map(([id, label]) => (
              <a key={id} href={"#" + id} onClick={() => setMenu(false)}>
                {label}
                <ArrowUpRight size={18} />
              </a>
            ))}
            <Contact>Agendar pelo Instagram</Contact>
          </nav>
        )}
      </header>
      <main id="conteudo">
        <section id="inicio" className="hero">
          <div className="hero-copy">
            <p className="eyebrow">
              <span />
              VILA CLEMENTINO · SÃO PAULO
            </p>
            <h1>
              Seu momento
              <br />
              de <em>brilhar</em>
              <br />
              começa aqui<span className="gold">.</span>
            </h1>
            <p className="intro">
              Um espaço dedicado à beleza, ao cuidado e à valorização de cada
              detalhe.
            </p>
            <div className="hero-buttons">
              <a href="#servicos" className="button">
                Conheça nossos serviços <ArrowUpRight size={17} />
              </a>
              <Contact className="text-link">Entre em contato</Contact>
            </div>
            <a href="#sobre" className="explore">
              <span>
                <ArrowDown size={15} />
              </span>
              DESCUBRA O STUDIO
            </a>
          </div>
          <div className="hero-visual">
            <img src={photos[0].src} alt={photos[0].alt} fetchPriority="high" />
            <div className="image-shade" />
            <span className="photo-note">IMAGEM ILUSTRATIVA</span>
            <span className="hero-spark">✧</span>
            <div className="photo-caption">
              <span>ESSENCIALMENTE VOCÊ.</span>
              <p>
                A beleza está
                <br />
                nos seus detalhes.
              </p>
            </div>
            <div className="round-stamp">
              BELEZA
              <br />
              <span>✧</span>
              <br />
              COM ESSÊNCIA
            </div>
          </div>
          <div className="hero-index">01 — UM MOMENTO SÓ SEU</div>
        </section>
        <div className="ribbon">
          <span>BELEZA COM ESSÊNCIA</span>
          <span>✧</span>
          <span>CUIDADO EM CADA DETALHE</span>
          <span>✧</span>
          <span>SEU MOMENTO DE BRILHAR</span>
          <span>✧</span>
        </div>
        <section id="sobre" className="section about">
          <Reveal className="about-image">
            <img src={photos[1].src} alt={photos[1].alt} loading="lazy" />
            <span>REFERÊNCIA DE AMBIENTE · IMAGEM ILUSTRATIVA</span>
            <div className="image-number">01 / O STUDIO</div>
          </Reveal>
          <Reveal className="about-copy">
            <p className="eyebrow">UM OLHAR PARA VOCÊ</p>
            <h2>
              Mais que beleza.
              <br />
              Um momento
              <br />
              <em>de conexão.</em>
            </h2>
            <p>
              Desacelerar. Olhar para si. Reservar um espaço na rotina para
              aquilo que faz você se sentir bem.
            </p>
            <p>
              É com essa inspiração que apresentamos o Studio Estrela: beleza e
              cuidados pessoais na Vila Clementino, em São Paulo.
            </p>
            <div className="signature">
              Sua essência, seu brilho. <span>✧</span>
            </div>
            <a href="#localizacao" className="text-link">
              Conheça nossa localização <ArrowUpRight size={17} />
            </a>
          </Reveal>
        </section>
        <section id="servicos" className="section services">
          <Reveal>
            <div className="section-heading">
              <div>
                <p className="eyebrow">BELEZA EM CADA ESCOLHA</p>
                <h2>
                  O cuidado começa
                  <br />
                  <em>com você.</em>
                </h2>
              </div>
              <p>
                Descubra as possibilidades para o seu momento.
                <br />
                Consulte os serviços disponíveis diretamente com o Studio.
              </p>
            </div>
            <div className="service-list">
              {(studio.services.length
                ? studio.services
                : [
                    {
                      name: "Realce a sua essência",
                      description:
                        "Converse sobre o que você deseja e conheça as opções de cuidado.",
                    },
                    {
                      name: "Reserve um tempo para si",
                      description:
                        "Consulte a disponibilidade e planeje seu momento com o Studio.",
                    },
                    {
                      name: "Encontre a sua inspiração",
                      description:
                        "Explore o perfil no Instagram e descubra mais sobre o estabelecimento.",
                    },
                  ]
              ).map((s, i) => (
                <Contact className="service-row" key={s.name}>
                  <span className="service-number">0{i + 1}</span>
                  <h3>{s.name}</h3>
                  <p>{s.description}</p>
                </Contact>
              ))}
            </div>
            <p className="fine-print">
              {studio.services.length
                ? "Consulte condições e disponibilidade pelo Instagram."
                : "Apresentação conceitual. O catálogo de serviços será incluído após confirmação pelo estabelecimento."}
            </p>
          </Reveal>
        </section>
        <section id="galeria" className="section gallery">
          <Reveal>
            <div className="section-heading">
              <div>
                <p className="eyebrow">UM UNIVERSO DE INSPIRAÇÕES</p>
                <h2>
                  Beleza que <em>inspira.</em>
                </h2>
              </div>
              <Contact className="text-link">Acompanhe no Instagram</Contact>
            </div>
            <div className="gallery-grid">
              {[photos[2], photos[0], photos[1]].map((p, i) => (
                <button
                  className={"gallery-item item-" + i}
                  key={p.src}
                  onClick={() => setSelected(photos.indexOf(p))}
                  aria-label={"Ampliar: " + p.alt}
                >
                  <img src={p.src} alt={p.alt} loading="lazy" />
                  <span className="gallery-caption">
                    {p.title}
                    <Plus size={20} />
                  </span>
                </button>
              ))}
            </div>
            <p className="fine-print">
              Curadoria visual demonstrativa. As imagens são ilustrativas e não
              representam o espaço, a equipe ou trabalhos do Studio Estrela.
            </p>
          </Reveal>
        </section>
        <section id="localizacao" className="location">
          <Reveal className="location-copy">
            <p className="eyebrow">PERTINHO DE VOCÊ</p>
            <h2>
              Um encontro
              <br />
              com o seu <em>brilho.</em>
            </h2>
            <div className="address">
              <MapPin size={22} />
              <div>
                <strong>{studio.address}</strong>
                <p>{studio.neighborhood}</p>
              </div>
            </div>
            <a className="text-link location-phone" href={studio.phoneHref}>
              <Phone size={16} />
              {studio.phone}
            </a>
            <p>
              Para consultar horários e combinar sua visita,
              <br />
              fale com o Studio pelo Instagram ou telefone.
            </p>
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="button"
            >
              Como chegar <ArrowUpRight size={17} />
            </a>
          </Reveal>
          <div
            className="location-art"
            aria-label="Representação decorativa da localização, não é um mapa"
          >
            <div className="road road-one" />
            <div className="road road-two" />
            <div className="road road-three" />
            <span className="map-label">VILA CLEMENTINO</span>
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="map-pin"
            >
              <span>✧</span>
              <strong>STUDIO ESTRELA</strong>
              <small>Rua Napoleão de Barros, 1211</small>
              <span className="map-link">Abrir no Google Maps ↗</span>
            </a>
            <p className="map-disclaimer">
              REPRESENTAÇÃO ILUSTRATIVA · CONSULTE A ROTA NO MAPS
            </p>
          </div>
        </section>
        <section className="section faq">
          <div>
            <p className="eyebrow">ANTES DO SEU MOMENTO</p>
            <h2>
              Vamos <em>conversar?</em>
            </h2>
          </div>
          <div>
            {questions.map(([q, a], i) => (
              <div className="faq-row" key={q}>
                <h3>
                  <button
                    aria-expanded={faq === i}
                    aria-controls={"answer-" + i}
                    onClick={() => setFaq(faq === i ? null : i)}
                  >
                    {q}
                    {faq === i ? <Minus size={18} /> : <Plus size={18} />}
                  </button>
                </h3>
                <div id={"answer-" + i} hidden={faq !== i}>
                  <p>{a}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
        <section id="contato" className="contact">
          <Reveal>
            <span className="contact-star">✧</span>
            <p className="eyebrow">SEU PRÓXIMO MOMENTO</p>
            <h2>
              Permita-se <em>brilhar.</em>
            </h2>
            <p>
              O primeiro passo é uma boa conversa.
              <br />
              Fale com o Studio Estrela e reserve um tempo para você.
            </p>
            <Contact className="button light">
              <Instagram size={18} />
              Conversar pelo Instagram
            </Contact>
            <span className="contact-handle">{studio.handle}</span>
            <a href={studio.phoneHref} className="phone-link">
              <Phone size={17} /> Ligar: {studio.phone}
            </a>
          </Reveal>
        </section>
      </main>
      <footer>
        <a href="#inicio" className="brand">
          <img
            className="brand-logo"
            src={studio.logo}
            alt=""
            width="56"
            height="56"
          />
          <span>
            STUDIO ESTRELA<small>BELEZA & CUIDADO</small>
          </span>
        </a>
        <p>Beleza que respeita a sua essência.</p>
        <a
          href={studio.instagram}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Visitar Instagram"
        >
          <Instagram size={20} />
        </a>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Studio Estrela</span>
          <span>
            Demonstração comercial independente · Dados sujeitos à confirmação.
          </span>
          <a href="#inicio">Voltar ao topo ↑</a>
        </div>
      </footer>
      <dialog
        ref={dialog}
        onCancel={() => setSelected(null)}
        onClick={(e) => {
          if (e.target === e.currentTarget) setSelected(null);
        }}
        className="lightbox"
      >
        <button
          autoFocus
          onClick={() => setSelected(null)}
          aria-label="Fechar imagem"
        >
          <X />
        </button>
        {selected !== null && (
          <>
            <img src={photos[selected].src} alt={photos[selected].alt} />
            <p>{photos[selected].title} · Imagem ilustrativa</p>
          </>
        )}
      </dialog>
    </MotionConfig>
  );
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
