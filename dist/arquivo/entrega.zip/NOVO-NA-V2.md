# Animações e mapa — versão 2

Atualização aplicada diretamente ao projeto **Place1**. A versão 1 e seu ZIP foram preservados; este diretório e `Entrega-ou-Ja-Era-v2.zip` contêm a versão atualizada, incluindo instalador completo para outro lugar.

## Animações prontas

- Pedalada proporcional à velocidade da bicicleta; parado, o avatar mantém a postura de condução.
- Mãos posicionadas à frente, tronco inclinado e pernas alternando.
- Gesto curto de coleta ao receber o pacote inicial ou usar o balcão sem pacote.
- Gesto de entrega seguido de comemoração.
- Raios das rodas girando durante o deslocamento.
- Aviso “ENTREGUE! +25 moedas” e pequena explosão de partículas após uma entrega aceita.

`CourierAnimations` roda em `StarterPlayerScripts` e desenha os movimentos de todos os jogadores que estão próximos da câmera. Usa `Transform` de `Motor6D`/`AnimationConstraint` durante `PreSimulation`, restaurando os offsets antes da próxima avaliação do Animator para evitar acumulação. Tem adaptação básica para R6; o teste de avatar desta entrega foi com R15 usando AnimationConstraint. Nenhum arquivo de animação precisa ser publicado, nenhuma API de upload é usada e nenhum ID fictício fica nos scripts.

São movimentos procedurais simples para este protótipo. Você ainda pode substituir essas poses por animações autorais publicadas no futuro. A aparência pode variar com proporções e tipos de avatar.

O servidor publica `ActionName`, `ActionTime`, `ActionReward` e `ActionSequence` somente após coleta/entrega válida. `ActionSequence` sinaliza um evento completo; o cliente não concede recompensas. `DeliveryEffects` usa esse sinal para mostrar feedback e limpa partículas automaticamente. Nenhum RemoteEvent adicional foi criado.

## Bairro atualizado

- **Padaria:** fachada creme/amarela, toldo listrado, vitrine de pães e placa.
- **Clínica:** fachada azul, vitrines, toldo e símbolo de saúde.
- **Mercado:** fachada verde, toldo e caixotes com frutas.
- **Central:** cobertura, pilares, caixas com fita e marcação de estacionamento.
- **Ruas:** árvores, calçadas centrais, postes, bancos, praça com flores e faixas.
- **Rotas:** sinalização para circuito seguro, rampa e atalho a pé.
- **Telhados:** dois terraços elevados conectados à central e à padaria; passarela com um vão de 5 studs que exige pular.
- **Atalho anterior:** reposicionado para o lado leste, sem atravessar os novos terraços.

Os novos terraços ficam em Y=26/28; a passarela mais alta em Y=32. As rotas seguras originais continuam em Y=24, acima da lava final Y=22. As lojas ficam atrás dos pontos de entrega para deixar a aproximação desobstruída. A decoração leve não possui colisão nem participa dos raycasts da bicicleta.

## Novos objetos principais

```text
ServerScriptService.EntregaOuJaEra.Modules.MapDecor   ModuleScript
StarterPlayer.StarterPlayerScripts.CourierAnimations LocalScript
StarterPlayer.StarterPlayerScripts.DeliveryEffects   LocalScript
Workspace.EntregaMap.ArtV2                           Folder
  DistrictFacades / DepotDetails / StreetDetails
  PocketPark / RooftopRoute / RouteSigns              Models
PlayerGui.DeliveryEffects                            ScreenGui
  DeliveryToast                                     TextLabel
```

`MapDecor.Apply()` monta a atualização uma vez e registra `EntregaMap.StyleVersion=2`. Ao iniciar outra rodada ou Play, não duplica a decoração. Edições feitas manualmente nos objetos continuam preservadas. Para reconstruir somente a decoração em Edit, remova `ArtV2`, remova o atributo `StyleVersion` e execute `MapDecor.Apply()` novamente. A ordem de montagem é MapBuilder → MapDecor → serviços do jogo.

## Teste rápido

1. Play, aguarde os 15s, pegue a bicicleta na central. Segure W: as pernas e os raios devem se mover. Solte: a pedalada para conforme a bicicleta desacelera.
2. Desmonte, vá ao destino indicado e entregue: observe gesto, comemoração, partículas e aviso de moedas.
3. Na central, use a passarela laranja marcada “TELHADOS”. Explore os dois terraços e pule o vão sinalizado. Errar o salto pode derrubar você para a cidade inundada.
4. Execute `Regressao.command.luau` na Command Bar do servidor durante Play: a versão 2 deve imprimir **PASS: 20 verificações**.

Veja `TESTES.md` para distinguir testes executados dos ainda pendentes. Salve o lugar no Studio; a atualização não publica o jogo nem substitui o arquivo `.rbxl` automaticamente.

Referências técnicas: [Animator](https://create.roblox.com/docs/reference/engine/classes/Animator), [AnimationConstraint](https://create.roblox.com/docs/reference/engine/classes/AnimationConstraint).
