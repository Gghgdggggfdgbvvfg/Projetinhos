# Correções do piso e nova bicicleta

Aplicadas ao projeto conectado **Place1** em 14/10/2026, a partir da imagem enviada pelo usuário.

## Piso verde sobreposto ao cinza

A versão anterior mantinha ruas e plataformas sobre a mesma região e em Y=24. Duas faces ocupando o mesmo plano causavam a cintilação e as bordas recortadas mostradas na imagem.

- O circuito foi dividido em cinco trechos, cada um terminando na borda das plataformas.
- Foi criada a plataforma `Geometry.SouthWestLanding` para fechar a esquina sudoeste sem sobrepor trechos.
- As plataformas dos destinos agora usam piso neutro de concreto, separado da rua de asfalto.
- Fundações das fachadas terminam na borda da plataforma; não ficam por cima dela.
- A área de entrega usa somente quatro barras discretas acima do piso. A peça do prompt é invisível e sem colisão.
- Foram removidas as placas visuais duplicadas que atravessavam a área do jogador. Os nomes dos destinos continuam nas fachadas.

Foi verificada a ausência de interseção interior entre **78 pares** das 13 superfícies principais do circuito, plataformas e fundações. A captura `PISOS-CORRIGIDOS.jpg` mostra o mercado durante uma rodada, com junções limpas.

## Bicicleta substituída

`BikeModel` constrói um novo modelo original com tubos metálicos, quadro em diamante, dois pneus vazados, aros, raios, cubos, garfo, guidão com manoplas e alavancas, selim arredondado, pedais, coroa, cassete, corrente e refletores.

O modelo tem 153 peças básicas e permanece editável por Luau. Uma única peça fica ancorada; o restante se conecta por soldas. Três articulações Motor6D controlam as duas rodas e os pedais. O servidor atualiza a posição do quadro e as articulações, preservando autoridade sobre movimento, velocidade e propriedade da bicicleta.

A aparência é mais próxima de uma bicicleta real, mas a condução continua arcade, adequada ao protótipo. A bicicleta também se inclina suavemente conforme a diferença de altura entre o chão na frente e atrás. O teste executado foi em terreno elevado com um avatar R15; a travessia de todas as rampas e vários jogadores simultâneos continua pendente.

## Outros ajustes

- O cliente mostra prompt de entrega somente no destino correto e somente ao carregar um pacote.
- No computador, os botões de direção ficam ocultos; WASD/setas e o botão Descer continuam funcionando. Em dispositivos touch, os botões permanecem.
- O marcador flutuante se esconde quando você está perto do destino, evitando competir com o prompt.
- Central e destinos usam streaming persistente; bicicletas usam streaming atômico.
- O HUD verifica se os objetos existem antes de acessá-los e mostra estado de carregamento quando necessário.

Durante os testes foi identificado um erro transitório de `DeliveryPoint` ausente no cliente. Depois da correção, retirar e devolver temporariamente o ponto no cliente mostrou o texto de carregamento e recuperou a interface sem erro. O último log da sessão mostrou inicialização e **PASS: 20 verificações**, sem erros dos scripts do jogo.

O Studio foi devolvido ao modo Edit, sem objetos temporários de prévia. A versão 2 e seu ZIP foram preservados. Salve o lugar no Studio para guardar as alterações no arquivo `.rbxl`.
