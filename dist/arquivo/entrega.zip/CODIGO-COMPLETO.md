## BikeModel (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.BikeModel
-- Modelo original de bicicleta: quadro tubular, pneus vazados, aros e transmissão.
local Builder={}
local function part(parent,name,size,cf,color,material,shape)
	local p=Instance.new("Part")
	p.Name,p.Size,p.CFrame=name,size,cf
	p.Anchored=false; p.CanCollide=false; p.CanTouch=false; p.CanQuery=false; p.Massless=true
	p.Color=color; p.Material=material or Enum.Material.SmoothPlastic
	p.TopSurface=Enum.SurfaceType.Smooth; p.BottomSurface=Enum.SurfaceType.Smooth
	if shape then p.Shape=shape end
	if p.Material==Enum.Material.Metal then p.Reflectance=.08 end
	p.Parent=parent; return p
end
local function weld(root,p)
	local w=Instance.new("WeldConstraint"); w.Part0=root; w.Part1=p; w.Parent=p
end
local function tube(parent,root,name,origin,a,b,radius,color)
	local axis=(b-a).Unit
	local reference=math.abs(axis.Y)>.95 and Vector3.xAxis or Vector3.yAxis
	local up=(reference-axis*axis:Dot(reference)).Unit
	local localCf=CFrame.fromMatrix((a+b)/2,axis,up,axis:Cross(up))
	local p=part(parent,name,Vector3.new((b-a).Magnitude,radius*2,radius*2),origin*localCf,color,Enum.Material.Metal,Enum.PartType.Cylinder)
	weld(root,p); return p
end
function Builder.Build(origin,player)
	local model=Instance.new("Model"); model.Name="Bike_"..player.UserId
	model.ModelStreamingMode=Enum.ModelStreamingMode.Atomic
	model:SetAttribute("OwnerUserId",player.UserId)
	model:SetAttribute("ModelVersion",3)
	local frame=part(model,"Frame",Vector3.new(.3,.3,2.5),origin,Color3.new(0,0,0))
	frame.Anchored=true; frame.Transparency=1; model.PrimaryPart=frame
	local paint=Color3.fromRGB(30,107,153)
	local black=Color3.fromRGB(25,29,34)
	local silver=Color3.fromRGB(181,192,201)
	local bottom=Vector3.new(0,-.05,.25)
	local stem=Vector3.new(0,1.0,.65)
	local head=Vector3.new(0,.94,-.93)
	local headLow=Vector3.new(0,.55,-.86)
	tube(model,frame,"TopTube",origin,stem,head,.065,paint)
	tube(model,frame,"DownTube",origin,headLow,bottom,.085,paint)
	tube(model,frame,"SeatTube",origin,bottom,stem,.07,paint)
	tube(model,frame,"HeadTube",origin,head,headLow,.09,paint)
	for _,side in {-1,1} do
		local rear=Vector3.new(side*.16,-.11,1.7)
		tube(model,frame,"SeatStay",origin,stem,rear,.04,paint)
		tube(model,frame,"ChainStay",origin,bottom,rear,.05,paint)
		tube(model,frame,"FrontFork",origin,headLow+Vector3.new(side*.14,0,0),Vector3.new(side*.14,-.11,-1.7),.055,silver)
	end
	tube(model,frame,"SeatPost",origin,stem,Vector3.new(0,1.18,.71),.045,silver)
	tube(model,frame,"HandleStem",origin,head,Vector3.new(0,1.47,-1.12),.045,silver)
	tube(model,frame,"Handlebar",origin,Vector3.new(-.82,1.47,-1.25),Vector3.new(.82,1.47,-1.25),.045,silver)
	for _,side in {-1,1} do
		local grip=part(model,"Grip",Vector3.new(.3,.12,.12),origin*CFrame.new(side*.71,1.47,-1.25),black,nil,Enum.PartType.Cylinder)
		weld(frame,grip)
		tube(model,frame,"BrakeLever",origin,Vector3.new(side*.60,1.43,-1.26),Vector3.new(side*.77,1.4,-1.45),.018,black)
	end
	local seat=Instance.new("Seat"); seat.Name="Saddle"
	seat.Size=Vector3.new(1.0,.26,1.2); seat.CFrame=origin*CFrame.new(0,1.22,.75)
	seat.Anchored=false; seat.CanCollide=false; seat.CanTouch=false; seat.CanQuery=false; seat.Massless=true
	seat.Color=black; seat.Material=Enum.Material.SmoothPlastic; seat.Parent=model; weld(frame,seat)
	seat.Transparency=1
	local saddleBack=part(model,"SaddleCushion",Vector3.new(.98,.24,.58),origin*CFrame.new(0,1.24,1.02),black)
	local backMesh=Instance.new("SpecialMesh"); backMesh.MeshType=Enum.MeshType.Sphere; backMesh.Parent=saddleBack
	weld(frame,saddleBack)
	local saddleNose=part(model,"SaddleNose",Vector3.new(.43,.21,.88),origin*CFrame.new(0,1.24,.65),black)
	local noseMesh=Instance.new("SpecialMesh"); noseMesh.MeshType=Enum.MeshType.Sphere; noseMesh.Parent=saddleNose
	weld(frame,saddleNose)
	local back=part(model,"RearReflector",Vector3.new(.28,.16,.12),origin*CFrame.new(0,.94,1.34),Color3.fromRGB(220,64,45))
	weld(frame,back)
	local front=part(model,"FrontReflector",Vector3.new(.25,.18,.12),origin*CFrame.new(0,1.42,-1.34),Color3.fromRGB(245,243,212))
	weld(frame,front)
	local motors={}
	for index,z in {-1.7,1.7} do
		local wheel=Instance.new("Model"); wheel.Name="Wheel_"..index; wheel.Parent=model
		local offset=CFrame.new(0,-.11,z)
		local wheelOrigin=origin*offset
		local hub=part(wheel,"Hub",Vector3.new(.50,.17,.17),wheelOrigin,silver,Enum.Material.Metal,Enum.PartType.Cylinder)
		local motor=Instance.new("Motor6D"); motor.Name="WheelMotor_"..index
		motor.Part0=frame; motor.Part1=hub; motor.C0=offset; motor.Parent=frame
		table.insert(motors,{Joint=motor,Base=offset,Ratio=1})
		for n=0,23 do
			local a=n*math.pi*2/24; local b=(n+1)*math.pi*2/24
			local p1=Vector3.new(0,math.cos(a)*1.07,math.sin(a)*1.07)
			local p2=Vector3.new(0,math.cos(b)*1.07,math.sin(b)*1.07)
			local tire=tube(wheel,hub,"Tire",wheelOrigin,p1,p2,.105,black)
			tire.Material=Enum.Material.SmoothPlastic; tire.Reflectance=0
			tube(wheel,hub,"Rim",wheelOrigin,p1*(.92/1.07),p2*(.92/1.07),.025,silver)
		end
		for n=0,11 do
			local a=n*math.pi*2/12
			tube(wheel,hub,"Spoke",wheelOrigin,Vector3.new(n%2==0 and -.14 or .14,0,0),Vector3.new(0,math.cos(a)*.90,math.sin(a)*.90),.012,silver)
		end
		if z>0 then
			local cassette=part(wheel,"Cassette",Vector3.new(.1,.43,.43),wheelOrigin*CFrame.new(.28,0,0),silver,Enum.Material.Metal,Enum.PartType.Cylinder)
			weld(hub,cassette)
		end
	end
	-- Braços e pedais giram como uma terceira articulação mecânica.
	local crank=Instance.new("Model"); crank.Name="Crankset"; crank.Parent=model
	local crankOffset=CFrame.new(bottom)
	local crankOrigin=origin*crankOffset
	local axle=part(crank,"Chainring",Vector3.new(.1,.6,.6),crankOrigin*CFrame.new(.25,0,0),silver,Enum.Material.Metal,Enum.PartType.Cylinder)
	local crankMotor=Instance.new("Motor6D"); crankMotor.Name="CrankMotor"
	crankMotor.Part0=frame; crankMotor.Part1=axle
	crankMotor.C0=crankOffset*CFrame.new(.25,0,0); crankMotor.Parent=frame
	table.insert(motors,{Joint=crankMotor,Base=crankMotor.C0,Ratio=.52})
	for _,side in {-1,1} do
		tube(crank,axle,"CrankArm",crankOrigin,Vector3.new(side*.3,0,0),Vector3.new(side*.3,side*.34,0),.035,silver)
		local pedal=part(crank,"Pedal",Vector3.new(.45,.10,.25),crankOrigin*CFrame.new(side*.45,side*.34,0),black)
		weld(axle,pedal)
	end
	tube(model,frame,"ChainUpper",origin,Vector3.new(.3,.2,.25),Vector3.new(.3,.02,1.7),.018,black)
	tube(model,frame,"ChainLower",origin,Vector3.new(.3,-.28,.25),Vector3.new(.3,-.24,1.7),.018,black)
	return model,frame,seat,motors
end
return Builder

```
## BikeService (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.BikeService
-- Bicicleta arcade cinemática: o cliente manda comandos, nunca posição/velocidade.
local RunService=game:GetService("RunService")
local ModelBuilder=require(script.Parent.BikeModel)
local Service={}; Service.__index=Service
function Service.new(map,players,state,config,remote)
	local self=setmetatable({Map=map,Players=players,State=state,Config=config,Bikes={},Connections={}},Service)
	table.insert(self.Connections,remote.OnServerEvent:Connect(function(p,throttle,steer)
		local b=self.Bikes[p]
		if not b or not b.Seat.Occupant or game:GetService("Players"):GetPlayerFromCharacter(b.Seat.Occupant.Parent)~=p then return end
		if throttle=="Dismount" then b.Seat.Occupant.Sit=false; return end
		if typeof(throttle)~="number" or typeof(steer)~="number" or throttle~=throttle or steer~=steer then return end
		local now=os.clock()
		if now-(b.LastPacket or 0)<.04 then return end
		b.LastPacket=now; b.Throttle=math.clamp(throttle,-1,1); b.Steer=math.clamp(steer,-1,1)
	end))
	table.insert(self.Connections,map.Central.BikeStation.Interaction.Triggered:Connect(function(p) self:Spawn(p) end))
	table.insert(self.Connections,RunService.Heartbeat:Connect(function(dt) self:Update(math.min(dt,.1)) end))
	return self
end
function Service:Spawn(p)
	local r=self.Players.Records[p]
	local root,h=self.Players:Root(p)
	if self.Config.Stage<5 or self.State:GetAttribute("Phase")~="Round" or not r or not r.Active or not root then return end
	if (root.Position-self.Map.Central.BikeStation.Position).Magnitude>self.Config.PromptDistance then return end
	self:Remove(p)
	local origin=CFrame.new(7,25.3,74)*CFrame.Angles(0,math.pi/2,0)
	local model,frame,seat,wheelMotors=ModelBuilder.Build(origin,p)
	model.Parent=self.Map.Runtime
	local prompt=Instance.new("ProximityPrompt"); prompt.Name="MountPrompt"
	prompt.ActionText="Montar"; prompt.ObjectText="Bicicleta de "..p.DisplayName
	prompt.MaxActivationDistance=8; prompt.RequiresLineOfSight=false; prompt.Parent=seat
	local b={Model=model,Frame=frame,Seat=seat,Position=origin.Position,Heading=math.pi/2,Throttle=0,Steer=0,Speed=0,FallSpeed=0,Connections={},WheelMotors=wheelMotors,WheelAngle=0,AttributeClock=0,Pitch=0}
	self.Bikes[p]=b
	b.Connections[1]=prompt.Triggered:Connect(function(who)
		local rr=self.Players.Records[who]; local rt,hum=self.Players:Root(who)
		if who~=p or not rr or not rr.Active or not rt or self.State:GetAttribute("Phase")~="Round" then return end
		if (rt.Position-seat.Position).Magnitude>10 or seat.Occupant then return end
		seat:Sit(hum)
	end)
	b.Connections[2]=seat:GetPropertyChangedSignal("Occupant"):Connect(function()
		local occupant=seat.Occupant
		if occupant and game:GetService("Players"):GetPlayerFromCharacter(occupant.Parent)~=p then occupant.Sit=false end
		p:SetAttribute("RidingBike",seat.Occupant~=nil and seat.Occupant==h)
		prompt.Enabled=seat.Occupant==nil
		b.Throttle,b.Steer,b.Speed=0,0,0
		p:SetAttribute("BikeSpeed",0)
	end)
	seat:Sit(h)
end
function Service:Update(dt)
	for p,b in self.Bikes do
		local r=self.Players.Records[p]
		if not r or not r.Active or self.State:GetAttribute("Phase")~="Round" then self:Remove(p); continue end
		if not b.Seat.Occupant then continue end
		if os.clock()-(b.LastPacket or 0)>.4 then b.Throttle,b.Steer=0,0 end
		local desired=b.Throttle*(b.Throttle>=0 and self.Config.BikeSpeed or self.Config.BikeReverseSpeed)
		b.Speed+=(desired-b.Speed)*math.min(dt*7,1)
		local previousHeading=b.Heading
		b.Heading-=b.Steer*self.Config.BikeTurnSpeed*dt*math.clamp(math.abs(b.Speed)/8,0,1)*(b.Speed<-.5 and -1 or 1)
		local facing=CFrame.Angles(0,b.Heading,0)
		local delta=facing.LookVector*b.Speed*dt
		local pos=b.Position
		local exclusions={self.Map.Runtime}
		for _,pl in game:GetService("Players"):GetPlayers() do if pl.Character then table.insert(exclusions,pl.Character) end end
		local rp=RaycastParams.new(); rp.FilterType=Enum.RaycastFilterType.Exclude; rp.FilterDescendantsInstances=exclusions
		rp.RespectCanCollide=true -- marcadores e prompts sem colisão não viram obstáculos
		-- Piso inclinado é suporte, não parede. Mantê-lo no raycast de chão,
		-- mas fora do teste de obstáculos; paredes e corrimãos continuam sólidos.
		local obstacleExclusions=table.clone(exclusions)
		for _,ramp in self.Map.Geometry:GetChildren() do
			if ramp:IsA("BasePart") and ramp:GetAttribute("BikeRamp")==true then table.insert(obstacleExclusions,ramp) end
		end
		local obstacleParams=RaycastParams.new()
		obstacleParams.FilterType=Enum.RaycastFilterType.Exclude
		obstacleParams.FilterDescendantsInstances=obstacleExclusions
		obstacleParams.RespectCanCollide=true
		local hit=delta.Magnitude>.001 and workspace:Blockcast(CFrame.new(pos+Vector3.new(0,2.05,0))*facing,Vector3.new(3.4,4.2,5.8),delta,obstacleParams)
		if hit then delta=Vector3.zero; b.Speed=0; b.Heading=previousHeading; facing=CFrame.Angles(0,b.Heading,0) end
		local nextPos=pos+delta
		local ground=workspace:Raycast(nextPos+Vector3.new(0,4,0),Vector3.new(0,-200,0),rp)
		local targetY=ground and ground.Position.Y+1.3 or -30
		if targetY>pos.Y+1.6 then nextPos=pos; targetY=pos.Y; b.Speed=0 end
		if targetY>=pos.Y-1.5 then
			b.FallSpeed=0; nextPos=Vector3.new(nextPos.X,targetY,nextPos.Z)
		else
			b.FallSpeed+=workspace.Gravity*dt
			nextPos=Vector3.new(nextPos.X,math.max(targetY,pos.Y-b.FallSpeed*dt),nextPos.Z)
		end
		b.Position=nextPos
		local forward=facing.LookVector*1.7
		local front=workspace:Raycast(nextPos+forward+Vector3.new(0,4,0),Vector3.new(0,-12,0),rp)
		local rear=workspace:Raycast(nextPos-forward+Vector3.new(0,4,0),Vector3.new(0,-12,0),rp)
		local targetPitch=0
		if front and rear and math.abs(front.Position.Y-rear.Position.Y)<2 then
			targetPitch=math.clamp(math.atan2(front.Position.Y-rear.Position.Y,3.4),-math.rad(22),math.rad(22))
		end
		b.Pitch+=(targetPitch-b.Pitch)*math.min(dt*10,1)
		-- Uma única peça ancorada move a estrutura soldada; articulações giram as rodas.
		b.Frame.CFrame=CFrame.new(nextPos)*facing*CFrame.Angles(b.Pitch,0,0)
		b.WheelAngle+=b.Speed*dt/1.07
		for _,wheel in b.WheelMotors do
			wheel.Joint.C0=wheel.Base*CFrame.Angles(b.WheelAngle*wheel.Ratio,0,0)
		end
		b.AttributeClock+=dt
		if b.AttributeClock>=.1 then
			b.AttributeClock=0; p:SetAttribute("BikeSpeed",math.round(b.Speed*10)/10)
		end
	end
end
function Service:Remove(p)
	local b=self.Bikes[p]
	if not b then return end
	for _,c in b.Connections do c:Disconnect() end
	if b.Seat.Occupant then b.Seat.Occupant.Sit=false end
	b.Model:Destroy(); self.Bikes[p]=nil
	if p.Parent then p:SetAttribute("RidingBike",false); p:SetAttribute("BikeSpeed",0) end
end
function Service:Clear()
	local list={}; for p in self.Bikes do table.insert(list,p) end
	for _,p in list do self:Remove(p) end
end
return Service

```
## Bootstrap (Script)
```luau
-- Script: ServerScriptService.EntregaOuJaEra.Bootstrap
local root=script.Parent
local modules=root:WaitForChild("Modules")
local config=require(modules.Config)
assert(config.Stage>=1 and config.Stage<=5,"Config.Stage deve estar entre 1 e 5")
assert(config.RoundDuration>config.LavaDelay,"RoundDuration deve superar LavaDelay")
local replicated=game:GetService("ReplicatedStorage")
local network=Instance.new("Folder"); network.Name="EntregaOuJaEra"; network.Parent=replicated
local state=Instance.new("Folder"); state.Name="State"; state.Parent=network
state:SetAttribute("Stage",config.Stage)
state:SetAttribute("Phase","Waiting"); state:SetAttribute("EndsAt",0)
state:SetAttribute("Results","[]"); state:SetAttribute("LavaActive",false)
state:SetAttribute("ActivePlayers",0); state:SetAttribute("RoundNumber",0)
local input=Instance.new("RemoteEvent"); input.Name="BikeInput"; input.Parent=network
local map=require(modules.MapBuilder).Build()
require(modules.MapDecor).Apply(map)
require(modules.RampFix).Apply(map)
local ps=require(modules.PlayerService).new(map)
local missions=require(modules.MissionService).new(map,ps,state,config)
local lava=require(modules.LavaService).new(map,ps,state,config)
local bikes=require(modules.BikeService).new(map,ps,state,config,input)
ps.OnEliminated=function(p) bikes:Remove(p) end
map.Central.PackageCounter.Interaction.Enabled=config.Stage>=2
map.Central.BikeStation.Interaction.Enabled=config.Stage>=5
for _,d in map.Destinations:GetChildren() do d.DeliveryPoint.Interaction.Enabled=config.Stage>=2 end
print("[Entrega ou Já Era!] Etapa "..config.Stage.." iniciada; servidor autoritativo.")
require(modules.RoundService).new(ps,missions,lava,bikes,state,config):Run()

```
## Config (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.Config
return {
	Stage = 5, -- 1: rodadas; 2: missões; 3: HUD/moedas; 4: lava; 5: bicicleta
	Intermission = 15,
	RoundDuration = 180,
	ResultsDuration = 10,
	LavaDelay = 30,
	LavaStart = -4,
	LavaEnd = 22,
	Reward = 25,
	PromptDistance = 12,
	BikeSpeed = 32,
	BikeReverseSpeed = 12,
	BikeTurnSpeed = 2.2,
}

```
## CourierAnimations (LocalScript)
```luau
-- LocalScript: StarterPlayer.StarterPlayerScripts.CourierAnimations
-- Animação procedural local para todos os jogadores, guiada por atributos do servidor.
-- Compatível com Motor6D e AnimationConstraint; nenhum AnimationId é necessário.
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local records,playerConnections={},{}
local function role(joint)
	local child=joint.Part1
	if not child then return nil end
	local aliases={
		LeftUpperLeg="LeftHip",RightUpperLeg="RightHip",LeftLowerLeg="LeftKnee",RightLowerLeg="RightKnee",
		LeftFoot="LeftAnkle",RightFoot="RightAnkle",LeftUpperArm="LeftShoulder",RightUpperArm="RightShoulder",
		LeftLowerArm="LeftElbow",RightLowerArm="RightElbow",UpperTorso="Waist",Head="Neck",
		["Left Leg"]="LeftHipR6",["Right Leg"]="RightHipR6",["Left Arm"]="LeftShoulderR6",["Right Arm"]="RightShoulderR6",
	}
	return aliases[child.Name]
end
local function restore(entry)
	if entry.Applied and entry.Joint.Parent then entry.Joint.Transform=entry.Base end
	entry.Applied=false
end
local function clear(p)
	local r=records[p]; if not r then return end
	for _,c in r.Connections do c:Disconnect() end
	for _,entry in r.Joints do restore(entry) end
	records[p]=nil
end
local function bind(p,char)
	clear(p)
	local r={Character=char,Joints={},Connections={},Phase=0,RideWeight=0}
	records[p]=r
	local function add(v)
		if not v:IsA("Motor6D") and not v:IsA("AnimationConstraint") then return end
		local name=role(v)
		if name then r.Joints[v]={Joint=v,Role=name,Base=v.Transform,Applied=false} end
	end
	for _,v in char:GetDescendants() do add(v) end
	table.insert(r.Connections,char.DescendantAdded:Connect(add))
	table.insert(r.Connections,char.DescendantRemoving:Connect(function(v)
		local entry=r.Joints[v]; if entry then restore(entry); r.Joints[v]=nil end
	end))
end
local function register(p)
	playerConnections[p]={p.CharacterAdded:Connect(function(c) bind(p,c) end),p.CharacterRemoving:Connect(function() clear(p) end)}
	if p.Character then bind(p,p.Character) end
end
Players.PlayerAdded:Connect(register)
Players.PlayerRemoving:Connect(function(p)
	clear(p)
	for _,c in playerConnections[p] or {} do c:Disconnect() end
	playerConnections[p]=nil
end)
for _,p in Players:GetPlayers() do register(p) end
-- Restaurar antes de o Animator avaliar impede acumular offsets entre frames.
RunService.PreAnimation:Connect(function()
	for _,r in records do for _,entry in r.Joints do restore(entry) end end
end)
RunService.PreSimulation:Connect(function(dt)
	local now=workspace:GetServerTimeNow()
	for p,r in records do
		local hum=r.Character:FindFirstChildOfClass("Humanoid")
		local root=r.Character:FindFirstChild("HumanoidRootPart")
		if not hum or not root or hum.Health<=0 then continue end
		local animator=hum:FindFirstChildOfClass("Animator")
		if animator and animator.EvaluationThrottled then continue end
		if p~=Players.LocalPlayer and workspace.CurrentCamera and (root.Position-workspace.CurrentCamera.CFrame.Position).Magnitude>300 then continue end
		local riding=p:GetAttribute("RidingBike")==true and p:GetAttribute("Active")==true
		local weight=riding and 1 or 0
		r.RideWeight+=(weight-r.RideWeight)*math.min(dt*12,1)
		local speed=math.abs(p:GetAttribute("BikeSpeed") or 0)
		if riding and speed>.8 then r.Phase+=(speed/32)*dt*math.pi*5 end
		local cycle=math.sin(r.Phase)
		local movement=math.clamp(speed/8,0,1)
		local age=now-(p:GetAttribute("ActionTime") or 0)
		local action=p:GetAttribute("ActionName")
		local gesture=0; local celebrate=0
		if p:GetAttribute("Active") and age>=0 then
			if action=="Collect" and age<.75 then gesture=math.sin(age/.75*math.pi)
			elseif action=="Deliver" then
				if age<.5 then gesture=math.sin(age/.5*math.pi)
				elseif age<1.4 then celebrate=math.sin((age-.5)/.9*math.pi) end
			end
		end
		for _,entry in r.Joints do
			local j,name=entry.Joint,entry.Role
			local base=j.Transform
			local target=base
			local w=r.RideWeight
			if w>.002 then
				local a=cycle*movement
				if name=="LeftHip" then target=CFrame.Angles(math.rad(62+28*a),0,0)
				elseif name=="RightHip" then target=CFrame.Angles(math.rad(62-28*a),0,0)
				elseif name=="LeftKnee" then target=CFrame.Angles(math.rad(-55+25*a),0,0)
				elseif name=="RightKnee" then target=CFrame.Angles(math.rad(-55-25*a),0,0)
				elseif name=="LeftAnkle" then target=CFrame.Angles(math.rad(12-8*a),0,0)
				elseif name=="RightAnkle" then target=CFrame.Angles(math.rad(12+8*a),0,0)
				elseif name=="LeftShoulder" or name=="RightShoulder" then target=CFrame.Angles(math.rad(72),0,0)
				elseif name=="LeftElbow" or name=="RightElbow" then target=CFrame.Angles(math.rad(18),0,0)
				elseif name=="Waist" then target=CFrame.Angles(math.rad(-12),0,0)
				elseif name=="Neck" then target=CFrame.Angles(math.rad(9),0,0)
				elseif name=="LeftHipR6" then target=base*CFrame.Angles(0,0,math.rad(24*a))
				elseif name=="RightHipR6" then target=base*CFrame.Angles(0,0,math.rad(-24*a))
				end
				target=base:Lerp(target,w)
			end
			local armWeight=math.max(gesture,celebrate)
			if armWeight>.001 then
				if name=="LeftShoulder" or name=="RightShoulder" then
					local side=name=="LeftShoulder" and -1 or 1
					local pose=CFrame.Angles(math.rad(gesture>celebrate and 82 or 145),0,side*math.rad(celebrate*18))
					target=target:Lerp(pose,armWeight)
				elseif name=="LeftShoulderR6" or name=="RightShoulderR6" then
					local side=name=="LeftShoulderR6" and -1 or 1
					target=target*CFrame.Angles(0,0,side*math.rad(90)*armWeight)
				end
			end
			if w>.002 or armWeight>.001 then
				entry.Base=base; entry.Applied=true; j.Transform=target
			end
		end
	end
end)

```
## DeliveryEffects (LocalScript)
```luau
-- LocalScript: StarterPlayer.StarterPlayerScripts.DeliveryEffects
-- Feedback visual somente após confirmação da transação pelo servidor.
local Players=game:GetService("Players")
local TweenService=game:GetService("TweenService")
local Debris=game:GetService("Debris")
local p=Players.LocalPlayer
local gui=Instance.new("ScreenGui"); gui.Name="DeliveryEffects"; gui.ResetOnSpawn=false
gui.DisplayOrder=15; gui.Parent=p:WaitForChild("PlayerGui")
local toast=Instance.new("TextLabel"); toast.Name="DeliveryToast"
toast.AnchorPoint=Vector2.new(.5,0); toast.Position=UDim2.new(.5,0,0,84)
toast.Size=UDim2.fromOffset(204,36); toast.BackgroundColor3=Color3.fromRGB(244,239,224)
toast.TextColor3=Color3.fromRGB(37,43,45); toast.Font=Enum.Font.GothamBold
toast.TextSize=15; toast.TextWrapped=true; toast.Visible=false; toast.Parent=gui
local corner=Instance.new("UICorner"); corner.CornerRadius=UDim.new(0,5); corner.Parent=toast
local effectToken=0; local tween
local lastSequence=p:GetAttribute("ActionSequence") or 0
local function show()
	local sequence=p:GetAttribute("ActionSequence") or 0
	if sequence==lastSequence then return end
	lastSequence=sequence
	if p:GetAttribute("ActionName")~="Deliver" then return end
	if workspace:GetServerTimeNow()-(p:GetAttribute("ActionTime") or 0)>2 then return end
	effectToken+=1; local token=effectToken
	if tween then tween:Cancel() end
	toast.Text="Entregue  +"..(p:GetAttribute("ActionReward") or 0).." moedas"
	local y=workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize.X<700 and 170 or 84
	toast.Position=UDim2.new(.5,0,0,y+8); toast.TextTransparency=0; toast.BackgroundTransparency=0
	toast.Visible=true
	tween=TweenService:Create(toast,TweenInfo.new(.18,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),{Position=UDim2.new(.5,0,0,y)})
	tween:Play()
	local root=p.Character and p.Character:FindFirstChild("HumanoidRootPart")
	if root then
		local attachment=Instance.new("Attachment"); attachment.Name="DeliveryConfetti"; attachment.Parent=root
		local emitter=Instance.new("ParticleEmitter"); emitter.Name="SuccessBurst"
		emitter.Texture="rbxasset://textures/particles/sparkles_main.dds"
		emitter.Color=ColorSequence.new(Color3.fromRGB(255,221,98),Color3.fromRGB(84,235,191))
		emitter.Rate=0; emitter.Lifetime=NumberRange.new(.4,.8); emitter.Speed=NumberRange.new(5,11)
		emitter.SpreadAngle=Vector2.new(160,160); emitter.Size=NumberSequence.new(.22)
		emitter.LightEmission=.6; emitter.Parent=attachment; emitter:Emit(18)
		Debris:AddItem(attachment,1.2)
	end
	task.delay(1.5,function()
		if token~=effectToken then return end
		tween=TweenService:Create(toast,TweenInfo.new(.3),{TextTransparency=1,BackgroundTransparency=1})
		tween:Play()
		task.delay(.3,function() if token==effectToken then toast.Visible=false end end)
	end)
end
p:GetAttributeChangedSignal("ActionSequence"):Connect(function()
	-- Ler depois do lote replicado para consumir nome, prêmio e timestamp juntos.
	task.defer(show)
end)

```
## GameAudio (LocalScript)
```luau
-- LocalScript: StarterPlayer.StarterPlayerScripts.GameAudio
-- Reprodução local a partir de sinais validados do servidor.
local Players=game:GetService("Players")
local SoundService=game:GetService("SoundService")
local ContentProvider=game:GetService("ContentProvider")
local RunService=game:GetService("RunService")
local p=Players.LocalPlayer
local state=game:GetService("ReplicatedStorage"):WaitForChild("EntregaOuJaEra"):WaitForChild("State")
local folder=Instance.new("Folder"); folder.Name="CourierAudio"; folder.Parent=SoundService
local group=Instance.new("SoundGroup"); group.Name="CourierMix"; group.Volume=.8; group.Parent=SoundService
local sounds={}
local function sound(name,file,volume,speed,loop)
	local s=Instance.new("Sound"); s.Name=name; s.SoundId="rbxasset://sounds/"..file
	s.Volume=volume; s.PlaybackSpeed=speed or 1; s.Looped=loop or false
	s.SoundGroup=group; s.Parent=folder; sounds[name]=s; return s
end
sound("Click","switch.wav",.14,1.2)
sound("Collect","switch.wav",.27,.8)
sound("Deliver","electronicpingshort.wav",.32,1.2)
sound("DeliverHigh","electronicpingshort.wav",.23,1.6)
sound("Start","electronicpingshort.wav",.28,1)
sound("LavaWarning","electronicpingshort.wav",.36,.65)
sound("End","electronicpingshort.wav",.27,.82)
sound("LastSeconds","switch.wav",.14,1.6)
sound("Eliminated","action_jump.mp3",.25,.65)
local bike=sound("Bicycle","action_footsteps_plastic.mp3",0,.9,true)
local eq=Instance.new("EqualizerSoundEffect"); eq.LowGain=-3; eq.MidGain=-3; eq.HighGain=-10; eq.Parent=bike
if p:GetAttribute("AudioMuted")==nil then p:SetAttribute("AudioMuted",false) end
local function mute() group.Volume=p:GetAttribute("AudioMuted") and 0 or .8 end
p:GetAttributeChangedSignal("AudioMuted"):Connect(mute); mute()
local list={}; for _,s in sounds do table.insert(list,s) end
task.spawn(function()
	pcall(function() ContentProvider:PreloadAsync(list) end)
	local loaded=0; for _,s in list do if s.IsLoaded then loaded+=1 end end
	folder:SetAttribute("LoadedSounds",loaded)
end)
local function play(name)
	local s=sounds[name]
	if s then s.TimePosition=0; s:Play(); folder:SetAttribute("LastCue",name) end
end
local lastAction=p:GetAttribute("ActionSequence") or 0
p:GetAttributeChangedSignal("ActionSequence"):Connect(function()
	task.defer(function()
		local sequence=p:GetAttribute("ActionSequence") or 0
		if sequence==lastAction then return end
		lastAction=sequence
		if workspace:GetServerTimeNow()-(p:GetAttribute("ActionTime") or 0)>2 then return end
		local action=p:GetAttribute("ActionName")
		if action=="Collect" then play("Collect")
		elseif action=="Deliver" then
			play("Deliver")
			task.delay(.12,function() if p:GetAttribute("ActionSequence")==sequence then play("DeliverHigh") end end)
		end
	end)
end)
local wasActive=p:GetAttribute("Active")==true
p:GetAttributeChangedSignal("Active"):Connect(function()
	local active=p:GetAttribute("Active")==true
	if wasActive and not active and state:GetAttribute("Phase")=="Round" then play("Eliminated") end
	wasActive=active
end)
local oldPhase=state:GetAttribute("Phase")
state:GetAttributeChangedSignal("Phase"):Connect(function()
	local phase=state:GetAttribute("Phase")
	if phase~=oldPhase then
		if phase=="Round" then play("Start") elseif phase=="Results" then play("End") end
	end
	oldPhase=phase
end)
state:GetAttributeChangedSignal("LavaActive"):Connect(function()
	if state:GetAttribute("LavaActive") and state:GetAttribute("Phase")=="Round" then play("LavaWarning") end
end)
local uiConnections={}
local function bindButton(v)
	if v:IsA("TextButton") and not uiConnections[v] then uiConnections[v]=v.Activated:Connect(function() play("Click") end) end
end
local playerGui=p:WaitForChild("PlayerGui")
for _,v in playerGui:GetDescendants() do if v:IsA("TextButton") and v:FindFirstAncestor("EntregaHUD") then bindButton(v) end end
playerGui.DescendantAdded:Connect(function(v) if v:IsA("TextButton") and v:FindFirstAncestor("EntregaHUD") then bindButton(v) end end)
playerGui.DescendantRemoving:Connect(function(v) if uiConnections[v] then uiConnections[v]:Disconnect(); uiConnections[v]=nil end end)
local accumulator=0; local lastSecond=-1
RunService.Heartbeat:Connect(function(dt)
	accumulator+=dt; if accumulator<.1 then return end; accumulator=0
	local riding=p:GetAttribute("RidingBike")==true and p:GetAttribute("Active")==true and state:GetAttribute("Phase")=="Round"
	local speed=math.abs(p:GetAttribute("BikeSpeed") or 0)
	if riding and speed>1 then
		bike.Volume=.09*math.clamp(speed/20,0,1); bike.PlaybackSpeed=.65+math.clamp(speed/32,0,1)*.65
		if not bike.IsPlaying then bike:Play() end
	else bike:Stop(); bike.Volume=0 end
	local seconds=math.ceil((state:GetAttribute("EndsAt") or 0)-workspace:GetServerTimeNow())
	if state:GetAttribute("Phase")=="Round" and seconds>0 and seconds<=10 and seconds~=lastSecond then play("LastSeconds") end
	lastSecond=seconds
end)

```
## EntregaHUD (LocalScript)
```luau
-- LocalScript: StarterPlayer.StarterPlayerScripts.EntregaHUD
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local UIS=game:GetService("UserInputService")
local HttpService=game:GetService("HttpService")
local me=Players.LocalPlayer
local net=game:GetService("ReplicatedStorage"):WaitForChild("EntregaOuJaEra")
local state=net:WaitForChild("State")
local input=net:WaitForChild("BikeInput")
local map=workspace:WaitForChild("EntregaMap")
local destinations=map:WaitForChild("Destinations")
local counterPrompt=map:WaitForChild("Central"):WaitForChild("PackageCounter"):WaitForChild("Interaction")
local paper=Color3.fromRGB(244,239,224)
local ink=Color3.fromRGB(37,43,45)
local muted=Color3.fromRGB(108,111,105)
local names={Padaria="Padaria Sol",Clinica="Clínica Azul",Mercado="Mercado Lima"}
local gui=Instance.new("ScreenGui"); gui.Name="EntregaHUD"; gui.ResetOnSpawn=false
gui.ZIndexBehavior=Enum.ZIndexBehavior.Sibling; gui.Parent=me:WaitForChild("PlayerGui")
gui.DisplayOrder=10
pcall(function() game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList,false) end)
local function corner(o,r)
 local c=Instance.new("UICorner"); c.CornerRadius=UDim.new(0,r or 5); c.Parent=o
end
local function card(parent,name,size,pos)
 local f=Instance.new("Frame"); f.Name=name; f.Size=size; f.Position=pos
 f.BackgroundColor3=paper; f.BorderSizePixel=0; f.Parent=parent; corner(f)
 local s=Instance.new("UIStroke"); s.Color=ink; s.Transparency=.82; s.Thickness=1; s.Parent=f
 return f
end
local function label(parent,name,size,pos,textSize,bold)
 local t=Instance.new("TextLabel"); t.Name=name; t.Size=size; t.Position=pos
 t.BackgroundTransparency=1; t.TextColor3=ink; t.TextSize=textSize or 15
 t.Font=bold and Enum.Font.GothamBold or Enum.Font.Gotham
 t.TextXAlignment=Enum.TextXAlignment.Left; t.TextTruncate=Enum.TextTruncate.AtEnd
 t.Parent=parent; return t
end
local function button(parent,name,text,size,pos)
 local b=Instance.new("TextButton"); b.Name=name; b.Size=size; b.Position=pos
 b.BackgroundColor3=paper; b.TextColor3=ink; b.Text=text
 b.Font=Enum.Font.GothamMedium; b.TextSize=14; b.AutoButtonColor=true
 b.BorderSizePixel=0; b.Parent=parent; corner(b)
 local s=Instance.new("UIStroke"); s.Color=ink; s.Transparency=.8; s.Parent=b
 return b
end
local clock=card(gui,"Clock",UDim2.fromOffset(140,68),UDim2.new(.5,-70,0,8))
local phaseLabel=label(clock,"Phase",UDim2.new(1,-16,0,16),UDim2.fromOffset(8,5),11)
phaseLabel.TextXAlignment=Enum.TextXAlignment.Center; phaseLabel.TextColor3=muted
local timeLabel=label(clock,"Time",UDim2.new(1,-16,0,28),UDim2.fromOffset(8,20),26,true)
timeLabel.TextXAlignment=Enum.TextXAlignment.Center
local aliveLabel=label(clock,"ActivePlayers",UDim2.new(1,-16,0,15),UDim2.fromOffset(8,49),11)
aliveLabel.TextXAlignment=Enum.TextXAlignment.Center; aliveLabel.TextColor3=muted
local stats=card(gui,"Wallet",UDim2.fromOffset(126,58),UDim2.new(1,-140,0,8))
local coinDot=Instance.new("Frame"); coinDot.Name="Coin"; coinDot.Size=UDim2.fromOffset(13,13)
coinDot.Position=UDim2.fromOffset(11,13); coinDot.BackgroundColor3=Color3.fromRGB(224,170,61)
coinDot.BorderSizePixel=0; coinDot.Parent=stats; corner(coinDot,8)
local coins=label(stats,"Coins",UDim2.new(1,-38,0,24),UDim2.fromOffset(31,7),20,true)
local delivered=label(stats,"Deliveries",UDim2.new(1,-20,0,17),UDim2.fromOffset(11,34),12)
delivered.TextColor3=muted
local mute=button(gui,"Mute","Som: ligado",UDim2.fromOffset(104,32),UDim2.fromOffset(14,8))
mute.TextSize=12
mute.Activated:Connect(function() me:SetAttribute("AudioMuted",not me:GetAttribute("AudioMuted")) end)
local ticket=card(gui,"Mission",UDim2.fromOffset(280,78),UDim2.new(0,14,1,-94))
local stripe=Instance.new("Frame"); stripe.Name="Accent"; stripe.Size=UDim2.new(0,4,1,-16)
stripe.Position=UDim2.fromOffset(8,8); stripe.BackgroundColor3=Color3.fromRGB(180,133,74)
stripe.BorderSizePixel=0; stripe.Parent=ticket
local small=label(ticket,"Caption",UDim2.new(1,-38,0,17),UDim2.fromOffset(22,8),11)
small.TextColor3=muted
local mission=label(ticket,"Destination",UDim2.new(1,-38,0,25),UDim2.fromOffset(22,25),17,true)
local distanceLabel=label(ticket,"Distance",UDim2.new(1,-38,0,18),UDim2.fromOffset(22,52),12)
distanceLabel.TextColor3=muted
local warning=card(gui,"LavaNotice",UDim2.fromOffset(224,34),UDim2.new(.5,-112,0,84))
warning.BackgroundColor3=Color3.fromRGB(236,183,114); warning.Visible=false
local warningText=label(warning,"Text",UDim2.new(1,-20,1,0),UDim2.fromOffset(10,0),13,true)
warningText.Text="Lava subindo. Vá para o alto."
local results=card(gui,"Results",UDim2.fromScale(.88,.58),UDim2.fromScale(.5,.54))
results.AnchorPoint=Vector2.new(.5,.5); results.Visible=false
local max=Instance.new("UISizeConstraint"); max.MaxSize=Vector2.new(460,430); max.Parent=results
local title=label(results,"Title",UDim2.new(1,-32,0,34),UDim2.fromOffset(16,13),23,true)
title.Text="Fim da rodada"
local subtitle=label(results,"Subtitle",UDim2.new(1,-32,0,18),UDim2.fromOffset(16,47),12)
subtitle.Text="Quem fez mais entregas?"; subtitle.TextColor3=muted
local header=label(results,"Headers",UDim2.new(1,-32,0,20),UDim2.fromOffset(16,74),11)
header.Text="ENTREGADOR"; header.TextColor3=muted
local countHeader=label(results,"DeliveryHeader",UDim2.fromOffset(62,20),UDim2.new(1,-148,0,74),11)
countHeader.Text="ENTREGAS"; countHeader.TextColor3=muted; countHeader.TextXAlignment=Enum.TextXAlignment.Right
local coinHeader=label(results,"CoinHeader",UDim2.fromOffset(62,20),UDim2.new(1,-78,0,74),11)
coinHeader.Text="MOEDAS"; coinHeader.TextColor3=muted; coinHeader.TextXAlignment=Enum.TextXAlignment.Right
local scroll=Instance.new("ScrollingFrame"); scroll.Name="Ranking"
scroll.Position=UDim2.fromOffset(16,99); scroll.Size=UDim2.new(1,-32,1,-151)
scroll.BackgroundTransparency=1; scroll.BorderSizePixel=0; scroll.ScrollBarThickness=3
scroll.ScrollBarImageColor3=muted; scroll.AutomaticCanvasSize=Enum.AutomaticSize.Y
scroll.CanvasSize=UDim2.new(); scroll.Parent=results
local layout=Instance.new("UIListLayout"); layout.Padding=UDim.new(0,3); layout.Parent=scroll
local resultFoot=label(results,"NextRound",UDim2.new(1,-32,0,30),UDim2.new(0,16,1,-41),13)
resultFoot.TextColor3=muted
local watch=button(gui,"SpectateNext","Ver próximo",UDim2.fromOffset(150,40),UDim2.new(.5,-75,1,-55))
watch.Visible=false
local riding=Instance.new("Frame"); riding.Name="BikeControls"; riding.BackgroundTransparency=1
riding.Size=UDim2.fromOffset(192,154); riding.AnchorPoint=Vector2.new(1,1)
riding.Position=UDim2.new(1,-14,1,-16); riding.Parent=gui; riding.Visible=false
local up=button(riding,"Up","↑",UDim2.fromOffset(56,44),UDim2.fromOffset(64,0))
local left=button(riding,"Left","←",UDim2.fromOffset(56,44),UDim2.fromOffset(2,50))
local down=button(riding,"Down","↓",UDim2.fromOffset(56,44),UDim2.fromOffset(64,50))
local right=button(riding,"Right","→",UDim2.fromOffset(56,44),UDim2.fromOffset(126,50))
local leave=button(riding,"Dismount","Descer",UDim2.fromOffset(180,42),UDim2.fromOffset(2,102))
for _,b in {up,left,down,right} do b.TextSize=23; b.Visible=UIS.TouchEnabled end
if not UIS.TouchEnabled then leave.Size=UDim2.fromOffset(132,36); leave.Position=UDim2.fromOffset(50,116); leave.Text="Descer [Espaço]"; leave.TextSize=12 end
leave.Activated:Connect(function() input:FireServer("Dismount") end)
local keys,touches,buttonHeld={},{},{}
local codes={ [Enum.KeyCode.W]="Up",[Enum.KeyCode.Up]="Up",[Enum.KeyCode.S]="Down",[Enum.KeyCode.Down]="Down",
 [Enum.KeyCode.A]="Left",[Enum.KeyCode.Left]="Left",[Enum.KeyCode.D]="Right",[Enum.KeyCode.Right]="Right" }
UIS.InputBegan:Connect(function(i,processed)
 if processed or UIS:GetFocusedTextBox() then return end
 if codes[i.KeyCode] then keys[i.KeyCode]=true end
 if i.KeyCode==Enum.KeyCode.Space and me:GetAttribute("RidingBike") then input:FireServer("Dismount") end
end)
UIS.InputEnded:Connect(function(i)
 keys[i.KeyCode]=nil
 if i.UserInputType==Enum.UserInputType.MouseButton1 then buttonHeld={} end
 if touches[i] then buttonHeld[touches[i]]=nil end
 touches[i]=nil
end)
UIS.WindowFocusReleased:Connect(function() keys={}; touches={}; buttonHeld={} end)
for b,action in {[up]="Up",[down]="Down",[left]="Left",[right]="Right"} do
 b.InputBegan:Connect(function(i)
  if i.UserInputType==Enum.UserInputType.Touch or i.UserInputType==Enum.UserInputType.MouseButton1 then touches[i]=action; buttonHeld[action]=true end
 end)
 b.InputEnded:Connect(function(i) if touches[i] then buttonHeld[action]=nil; touches[i]=nil end end)
 b.MouseButton1Down:Connect(function() buttonHeld[action]=true end)
 b.MouseButton1Up:Connect(function() buttonHeld[action]=nil end)
end
local function held(action)
 if buttonHeld[action] then return 1 end
 for code in keys do if codes[code]==action then return 1 end end
 for _,a in touches do if a==action then return 1 end end
 return 0
end
local marker=Instance.new("BillboardGui"); marker.Name="MyDestination"; marker.Size=UDim2.fromOffset(142,44)
marker.StudsOffset=Vector3.new(0,5,0); marker.AlwaysOnTop=true; marker.MaxDistance=260
marker.Enabled=false; marker.Parent=gui
local markerText=label(marker,"Label",UDim2.fromScale(1,1),UDim2.new(),13,true)
markerText.BackgroundTransparency=.12; markerText.BackgroundColor3=paper
markerText.TextXAlignment=Enum.TextXAlignment.Center; markerText.TextWrapped=true; corner(markerText,4)
local watched
local function restoreCamera()
 local h=me.Character and me.Character:FindFirstChildOfClass("Humanoid")
 if h and workspace.CurrentCamera then workspace.CurrentCamera.CameraSubject=h end
 watched=nil
end
local function nextTarget()
 local choices={}
 for _,p in Players:GetPlayers() do if p~=me and p:GetAttribute("Active") and p.Character then table.insert(choices,p) end end
 table.sort(choices,function(a,b) return a.UserId<b.UserId end)
 if #choices==0 then restoreCamera(); return end
 local index=0; for i,p in choices do if p==watched then index=i end end
 watched=choices[index%#choices+1]
 local h=watched.Character:FindFirstChildOfClass("Humanoid")
 if h and workspace.CurrentCamera then workspace.CurrentCamera.CameraSubject=h end
end
watch.Activated:Connect(nextTarget)
local function resize()
 local width=workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize.X or 1000
 local compact=width<700
 if compact then
  clock.Size=UDim2.fromOffset(116,68); clock.Position=UDim2.new(.5,-58,0,8)
  stats.Size=UDim2.fromOffset(98,58); stats.Position=UDim2.new(1,-110,0,8)
  mute.Size=UDim2.fromOffset(86,32); mute.Position=UDim2.fromOffset(12,8)
  ticket.Size=UDim2.fromOffset(math.min(280,width-28),78); ticket.Position=UDim2.fromOffset(14,84)
  warning.Position=UDim2.new(.5,-112,0,170)
 else
  clock.Size=UDim2.fromOffset(140,68); clock.Position=UDim2.new(.5,-70,0,8)
  stats.Size=UDim2.fromOffset(126,58); stats.Position=UDim2.new(1,-140,0,8)
  mute.Size=UDim2.fromOffset(104,32)
  ticket.Size=UDim2.fromOffset(280,78); ticket.Position=UDim2.new(0,14,1,-94)
  warning.Position=UDim2.new(.5,-112,0,84)
 end
 if UIS.TouchEnabled then
  mute.Size=UDim2.fromOffset(compact and 86 or 104,44)
  if not compact then
   ticket.Size=UDim2.fromOffset(260,78); ticket.Position=UDim2.fromOffset(14,84)
   warning.Position=UDim2.new(.5,-112,0,170)
  end
 end
 gui:SetAttribute("Layout",compact and "Compact" or (UIS.TouchEnabled and "TouchLandscape" or "Desktop"))
end
if workspace.CurrentCamera then workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(resize) end
resize()
local oldResults=""
local timer=0; local lavaSeen; local savedJumpVisible
RunService.RenderStepped:Connect(function(dt)
 timer+=dt; if timer<.1 then return end; timer=0
 local phase=state:GetAttribute("Phase")
 local stage=state:GetAttribute("Stage") or 5
 local active=me:GetAttribute("Active")==true
 local now=workspace:GetServerTimeNow()
 local seconds=math.max(0,math.ceil((state:GetAttribute("EndsAt") or 0)-now))
 clock.Visible=stage>=3; stats.Visible=stage>=3; ticket.Visible=stage>=3
 timeLabel.Text=phase=="Waiting" and "--:--" or string.format("%02d:%02d",math.floor(seconds/60),seconds%60)
 timeLabel.TextColor3=phase=="Round" and seconds<=20 and Color3.fromRGB(171,64,45) or ink
 phaseLabel.Text=({Waiting="Esperando",Intermission="Começa em",Round="Rodada",Results="Próxima rodada"})[phase] or "Preparando"
 aliveLabel.Text=phase=="Round" and (state:GetAttribute("ActivePlayers") or 0).." na rua" or ""
 local ls=me:FindFirstChild("leaderstats"); local coin=ls and ls:FindFirstChild("Moedas")
 coins.Text=tostring(coin and coin.Value or 0)
 local count=me:GetAttribute("Deliveries") or 0
 delivered.Text=count..(count==1 and " entrega" or " entregas")
 mute.Text=me:GetAttribute("AudioMuted") and "Som: mudo" or "Som: ligado"
 local id=me:GetAttribute("DestinationId") or ""
 local destination=destinations:FindFirstChild(id)
 local point=destination and destination:FindFirstChild("DeliveryPoint")
 local rt=me.Character and me.Character:FindFirstChild("HumanoidRootPart")
 marker.Enabled=false
 if phase=="Round" and active and me:GetAttribute("HasPackage") then
  small.Text="PACOTE PARA"; mission.Text=names[id] or id
  stripe.BackgroundColor3=destination and destination:GetAttribute("Color") or Color3.fromRGB(180,133,74)
  if point and rt then
   local distance=math.floor((rt.Position-point.Position).Magnitude)
   distanceLabel.Text=distance<=12 and "Entrega aqui" or distance.." studs"
   marker.Enabled=distance>14; marker.Adornee=point
   markerText.Text=(names[id] or id).."\n"..distance.." studs"
  else distanceLabel.Text="Carregando destino…" end
 elseif phase=="Round" and not active then
  small.Text="FORA DA RODADA"; mission.Text="Você ficou de fora"
  distanceLabel.Text=watched and "Assistindo "..watched.DisplayName or "Aguarde a próxima rodada"
 else
  small.Text="CENTRAL DE ENTREGAS"; mission.Text="Sua próxima corrida"
  distanceLabel.Text=phase=="Round" and "Retire o pacote na central" or "A rodada começa em breve"
  stripe.BackgroundColor3=Color3.fromRGB(180,133,74)
 end
 local lava=phase=="Round" and state:GetAttribute("LavaActive")==true
 if lava and not lavaSeen then lavaSeen=now end
 if not lava then lavaSeen=nil end
 warning.Visible=stage>=3 and lava and now-lavaSeen<6
 if lava then phaseLabel.Text="Lava subindo" end
 for _,d in destinations:GetChildren() do
  local target=d:FindFirstChild("DeliveryPoint"); local prompt=target and target:FindFirstChild("Interaction")
  if prompt then prompt.Enabled=stage>=2 and phase=="Round" and active and me:GetAttribute("HasPackage")==true and d.Name==id end
 end
 counterPrompt.Enabled=stage>=2 and phase=="Round" and active and not me:GetAttribute("HasPackage")
 local spectator=phase=="Round" and not active
 watch.Visible=spectator and stage>=3
 if spectator then if not watched or not watched.Parent or not watched:GetAttribute("Active") then nextTarget() end
 elseif watched then restoreCamera() end
 riding.Visible=phase=="Round" and active and me:GetAttribute("RidingBike")==true
 local touchGui=me.PlayerGui:FindFirstChild("TouchGui")
 local controlFrame=touchGui and touchGui:FindFirstChild("TouchControlFrame")
 local jump=controlFrame and controlFrame:FindFirstChild("JumpButton")
 if jump then
  if riding.Visible then
   if savedJumpVisible==nil then savedJumpVisible=jump.Visible end
   jump.Visible=false
  elseif savedJumpVisible~=nil then jump.Visible=savedJumpVisible; savedJumpVisible=nil end
 end
 if riding.Visible then input:FireServer(held("Up")-held("Down"),held("Right")-held("Left")) end
 results.Visible=phase=="Results" and stage>=3
 resultFoot.Text="Próxima rodada em "..seconds.."s"
 local data=state:GetAttribute("Results") or "[]"
 if data~=oldResults then
  oldResults=data
  for _,child in scroll:GetChildren() do if child:IsA("Frame") then child:Destroy() end end
  local ok,rows=pcall(HttpService.JSONDecode,HttpService,data)
  if ok then for i,row in rows do
   local f=Instance.new("Frame"); f.Name="Row_"..i; f.Size=UDim2.new(1,-4,0,37)
   f.LayoutOrder=i; f.BackgroundTransparency=row.UserId==me.UserId and .75 or 1
   f.BackgroundColor3=Color3.fromRGB(204,180,131); f.BorderSizePixel=0; f.Parent=scroll
   local rank=label(f,"Rank",UDim2.fromOffset(24,37),UDim2.fromOffset(3,0),13); rank.Text=tostring(i); rank.TextColor3=muted
   local name=label(f,"Name",UDim2.new(1,-162,0,37),UDim2.fromOffset(28,0),14,true); name.Text=row.Name..(row.Left and " (saiu)" or "")
   local score=label(f,"Deliveries",UDim2.fromOffset(54,37),UDim2.new(1,-132,0,0),14,true); score.Text=tostring(row.Deliveries); score.TextXAlignment=Enum.TextXAlignment.Right
   local reward=label(f,"Coins",UDim2.fromOffset(62,37),UDim2.new(1,-62,0,0),14); reward.Text=tostring(row.Coins); reward.TextXAlignment=Enum.TextXAlignment.Right
  end end
 end
end)

```
## LavaService (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.LavaService
local Service={}; Service.__index=Service
function Service.new(map,players,state,config)
	return setmetatable({Map=map,Players=players,State=state,Config=config,Part=nil,Connection=nil},Service)
end
function Service:Start()
	self:Stop()
	if self.Config.Stage<4 then return end
	local lava=Instance.new("Part")
	lava.Name="RisingLava"; lava.Anchored=true; lava.CanCollide=false
	lava.Material=Enum.Material.Neon; lava.Color=Color3.fromRGB(255,74,25)
	lava.Transparency=.12
	lava.Size=Vector3.new(264,4,210); lava.CFrame=CFrame.new(0,self.Config.LavaStart-2,0)
	lava.Parent=self.Map.Runtime; self.Part=lava
	self.Connection=lava.Touched:Connect(function(hit)
		if not self.State:GetAttribute("LavaActive") then return end
		local model=hit:FindFirstAncestorOfClass("Model")
		local p=model and game:GetService("Players"):GetPlayerFromCharacter(model)
		if p then self:CheckPlayer(p) end
	end)
end
function Service:CheckPlayer(p)
	local root=self.Players:Root(p)
	local r=self.Players.Records[p]
	if not root or not r or not r.Active or not self.Part then return end
	local top=self.State:GetAttribute("LavaHeight") or self.Config.LavaStart
	-- Testa as partes físicas do corpo, inclusive pés. Acessórios e pacote não eliminam.
	for _,body in p.Character:GetChildren() do
		if body:IsA("BasePart") and body.Name~="DeliveryPackage" then
			local pos=body.Position
			local half=body.Size/2
			if math.abs(pos.X)<=132+half.X and math.abs(pos.Z)<=105+half.Z and pos.Y-half.Y<=top then
				self.Players:Eliminate(p,"A lava alcançou você!"); return
			end
		end
	end
end
function Service:Update(elapsed)
	if not self.Part then return end
	local active=elapsed>=self.Config.LavaDelay
	self.State:SetAttribute("LavaActive",active)
	local alpha=math.clamp((elapsed-self.Config.LavaDelay)/(self.Config.RoundDuration-self.Config.LavaDelay),0,1)
	local top=self.Config.LavaStart+(self.Config.LavaEnd-self.Config.LavaStart)*alpha
	self.State:SetAttribute("LavaHeight",top)
	local bottom=-10
	self.Part.Size=Vector3.new(264,top-bottom,210)
	self.Part.CFrame=CFrame.new(0,(top+bottom)/2,0)
	if active then for p in self.Players.Records do self:CheckPlayer(p) end end
end
function Service:Stop()
	if self.Connection then self.Connection:Disconnect(); self.Connection=nil end
	if self.Part then self.Part:Destroy(); self.Part=nil end
	self.State:SetAttribute("LavaActive",false)
end
return Service

```
## MapBuilder (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.MapBuilder
local Map = {}
local function part(parent, name, size, cf, color, material)
	local p = Instance.new("Part")
	p.Name, p.Size, p.CFrame = name, size, cf
	p.Anchored = true
	p.Color = color
	p.Material = material or Enum.Material.SmoothPlastic
	p.TopSurface, p.BottomSurface = Enum.SurfaceType.Smooth, Enum.SurfaceType.Smooth
	p.Parent = parent
	return p
end
local function sign(parent, name, position, words, color)
	local p = part(parent, name, Vector3.new(15, 5, .5), CFrame.new(position), color)
	p.CanCollide = false
	for _, face in {Enum.NormalId.Front, Enum.NormalId.Back} do
		local gui = Instance.new("SurfaceGui")
		gui.Face, gui.CanvasSize = face, Vector2.new(640, 220)
		gui.Parent = p
		local text = Instance.new("TextLabel")
		text.Size, text.BackgroundTransparency = UDim2.fromScale(1, 1), 1
		text.Text, text.TextColor3 = words, Color3.new(1, 1, 1)
		text.Font, text.TextScaled = Enum.Font.GothamBold, true
		text.Parent = gui
	end
	return p
end
local function prompt(parent, action, object)
	local p = Instance.new("ProximityPrompt")
	p.Name = "Interaction"
	p.ActionText, p.ObjectText = action, object
	p.MaxActivationDistance, p.HoldDuration = 10, .25
	p.RequiresLineOfSight = false
	p.Parent = parent
end
local function ramp(parent, name, a, b, width, color)
	local delta = b - a
	return part(parent, name, Vector3.new(width, 1, delta.Magnitude),
		CFrame.lookAt((a+b)/2, b), color)
end
function Map.Build()
	if workspace:FindFirstChild("EntregaMap") then return workspace.EntregaMap end
	local model = Instance.new("Model")
	model.Name = "EntregaMap"
	local geometry = Instance.new("Folder")
	geometry.Name, geometry.Parent = "Geometry", model
	local destinations = Instance.new("Folder")
	destinations.Name, destinations.Parent = "Destinations", model
	local runtime = Instance.new("Folder")
	runtime.Name, runtime.Parent = "Runtime", model
	local green = Color3.fromRGB(86, 190, 107)
	local road = Color3.fromRGB(63, 72, 93)
	local deck = Color3.fromRGB(85, 110, 142)
	part(geometry, "Ground", Vector3.new(264, 2, 210), CFrame.new(0, -1, 0), green)
	for _, x in {-92, 0, 92} do
		part(geometry, "StreetNS_"..x, Vector3.new(14, .2, 190), CFrame.new(x, .1, 0), road)
	end
	for _, z in {-70, 0, 70} do
		part(geometry, "StreetEW_"..z, Vector3.new(246, .2, 14), CFrame.new(0, .1, z), road)
	end
	for _, z in {-70, 70} do
		part(geometry, "HighRoadEW_"..z, Vector3.new(200, 2, 14), CFrame.new(0, 23, z), deck)
		for _, side in {z < 0 and -1 or 1} do
			part(geometry, "GuardrailEW", Vector3.new(200, 2, .6), CFrame.new(0, 25, z+side*7), Color3.fromRGB(255,222,99))
		end
	end
	for _, x in {-92, 92} do
		part(geometry, "HighRoadNS_"..x, Vector3.new(14, 2, 140), CFrame.new(x, 23, 0), deck)
		for _, side in {x < 0 and -1 or 1} do
			part(geometry, "GuardrailNS", Vector3.new(.6, 2, 122), CFrame.new(x+side*7, 25, 0), Color3.fromRGB(255,222,99))
		end
	end
	-- Rampa longa: rua baixa -> central. A outra sobe até a esquina oposta.
	ramp(geometry, "RampCentral", Vector3.new(-70, .5, -48), Vector3.new(-70, 24, 70), 12, deck)
	ramp(geometry, "RampNorth", Vector3.new(70, .5, 48), Vector3.new(70, 24, -70), 12, deck)
	for i, pos in {Vector3.new(-92,11,0), Vector3.new(92,11,0), Vector3.new(0,11,-70), Vector3.new(0,11,70)} do
		part(geometry, "BridgePillar_"..i, Vector3.new(4,24,4), CFrame.new(pos), Color3.fromRGB(210,215,221))
	end
	local palette = {Color3.fromRGB(255,153,119), Color3.fromRGB(117,199,244), Color3.fromRGB(197,146,242), Color3.fromRGB(255,213,110)}
	for i, v in {Vector3.new(-40,0,-34), Vector3.new(35,0,-34), Vector3.new(-38,0,32), Vector3.new(36,0,33)} do
		local house = Instance.new("Model")
		house.Name, house.Parent = "House_"..i, geometry
		local h = 8 + i*2
		part(house, "Walls", Vector3.new(26,h,22), CFrame.new(v+Vector3.new(0,h/2,0)), palette[i])
		part(house, "FlatRoof", Vector3.new(29,1,25), CFrame.new(v+Vector3.new(0,h+.5,0)), Color3.fromRGB(243,238,218))
		part(house, "Door", Vector3.new(4,6,.3), CFrame.new(v+Vector3.new(0,3,11.2)), Color3.fromRGB(61,90,111))
		for _, dx in {-8,8} do
			part(house, "Window", Vector3.new(4,3,.3), CFrame.new(v+Vector3.new(dx,h/2,11.2)), Color3.fromRGB(166,239,255), Enum.Material.Neon)
		end
		-- Escadinha acessível a pé; telhados baixos deixam de ser seguros.
		for n=1, math.ceil(h/2) do
			part(house, "Step_"..n, Vector3.new(5,2,3), CFrame.new(v+Vector3.new(17, n*2-1, 14-n*3)), palette[i])
		end
	end
	-- Atalho elevado sem corrimão, mais curto e estreito: só a pé.
	ramp(geometry, "RiskyFootbridge", Vector3.new(-92,24,-70), Vector3.new(0,24,70), 4, Color3.fromRGB(242,139,67))
	sign(geometry,"RiskSign",Vector3.new(-82,28,-57),"ATALHO\nSEM CORRIMÃO",Color3.fromRGB(211,91,53))
	for i, pos in {Vector3.new(-8,1.5,0),Vector3.new(7,1.5,-20),Vector3.new(0,1.5,35)} do
		part(geometry,"RoadObstacle_"..i,Vector3.new(5,3,5),CFrame.new(pos),Color3.fromRGB(255,157,60))
	end
	local central = Instance.new("Model")
	central.Name, central.Parent = "Central", model
	part(central,"Platform",Vector3.new(32,2,26),CFrame.new(0,23,70),Color3.fromRGB(255,202,78))
	local spawn = part(central,"RoundSpawn",Vector3.new(2,1,2),CFrame.new(0,24.5,74),green)
	spawn.Transparency, spawn.CanCollide = 1,false
	local counter = part(central,"PackageCounter",Vector3.new(7,3,3),CFrame.new(-8,25.5,64),Color3.fromRGB(156,107,62))
	prompt(counter,"Pegar pacote","CENTRAL DE ENTREGAS")
	local bike = part(central,"BikeStation",Vector3.new(3,2,3),CFrame.new(8,25,64),Color3.fromRGB(86,224,219))
	prompt(bike,"Pegar / recuperar bicicleta","BICICLETÁRIO")
	sign(central,"Title",Vector3.new(0,32,60),"ENTREGA OU JÁ ERA!\nCENTRAL",Color3.fromRGB(35,112,141))
	local entries = {
		{"Padaria", "PADARIA SOL", Vector3.new(-92,0,-70), Color3.fromRGB(255,188,58)},
		{"Clinica", "CLÍNICA AZUL", Vector3.new(92,0,-70), Color3.fromRGB(72,183,255)},
		{"Mercado", "MERCADO LIMA", Vector3.new(92,0,70), Color3.fromRGB(116,222,86)},
	}
	for _, e in entries do
		local d = Instance.new("Model")
		d.Name, d.Parent = e[1],destinations
		d:SetAttribute("DisplayName",e[2])
		d:SetAttribute("Color",e[4])
		part(d,"Platform",Vector3.new(26,2,26),CFrame.new(e[3]+Vector3.new(0,23,0)),e[4])
		local target = part(d,"DeliveryPoint",Vector3.new(5,2,5),CFrame.new(e[3]+Vector3.new(0,25,0)),e[4],Enum.Material.Neon)
		target.CanCollide = false
		prompt(target,"Entregar pacote",e[2])
		sign(d,"Sign",e[3]+Vector3.new(0,32,-7),e[2].."\nENTREGUE AQUI",e[4])
	end
	local lobby = Instance.new("Model")
	lobby.Name,lobby.Parent = "Lobby",model
	part(lobby,"Platform",Vector3.new(42,2,32),CFrame.new(-145,63,115),Color3.fromRGB(86,183,214))
	local ls = Instance.new("SpawnLocation")
	ls.Name,ls.Size,ls.CFrame = "LobbySpawn",Vector3.new(7,1,7),CFrame.new(-145,64.5,115)
	ls.Anchored,ls.Neutral,ls.Duration = true,true,0
	ls.Color,ls.Parent = Color3.fromRGB(255,224,117),lobby
	for _, z in {99,131} do part(lobby,"LobbyRail",Vector3.new(42,4,1),CFrame.new(-145,66,z),deck) end
	for _, x in {-166,-124} do part(lobby,"LobbyRail",Vector3.new(1,4,32),CFrame.new(x,66,115),deck) end
	sign(lobby,"Welcome",Vector3.new(-145,72,103),"ENTREGA OU JÁ ERA!\nESCOLHA SUA ROTA",Color3.fromRGB(35,112,141))
	for _, x in {-132,132} do
		local wall=part(geometry,"BoundaryX",Vector3.new(2,90,212),CFrame.new(x,44,0),green)
		wall.Transparency=1
	end
	for _, z in {-105,105} do
		local wall=part(geometry,"BoundaryZ",Vector3.new(264,90,2),CFrame.new(0,44,z),green)
		wall.Transparency=1
	end
	model.Parent = workspace
	local oldSpawn = workspace:FindFirstChild("SpawnLocation")
	if oldSpawn and oldSpawn:IsA("SpawnLocation") then oldSpawn.Enabled=false end
	local base=workspace:FindFirstChild("Baseplate")
	if base and base:IsA("BasePart") then base.CanCollide=false; base.Transparency=1 end
	game:GetService("Lighting").ClockTime=14
	game:GetService("Lighting").Brightness=2
	game:GetService("Lighting").Ambient=Color3.fromRGB(145,151,172)
	return model
end
return Map

```
## MapDecor (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.MapDecor
-- Melhorias aditivas: não remove o mapa base nem altera IDs de destinos.
local Decor={}
local C={Cream=Color3.fromRGB(255,242,209),Ink=Color3.fromRGB(43,59,81),
	Yellow=Color3.fromRGB(255,196,66),Blue=Color3.fromRGB(68,175,240),
	Green=Color3.fromRGB(108,209,104),Wood=Color3.fromRGB(172,114,69),
	White=Color3.fromRGB(244,250,253),Orange=Color3.fromRGB(244,136,66)}
local function piece(parent,name,size,cf,color,solid,material,shape)
	local p=Instance.new("Part")
	p.Name,p.Size,p.CFrame=name,size,cf
	p.Anchored=true; p.CanCollide=solid==true
	p.CanQuery=solid==true; p.CanTouch=false
	p.Color=color; p.Material=material or Enum.Material.SmoothPlastic
	p.TopSurface=Enum.SurfaceType.Smooth; p.BottomSurface=Enum.SurfaceType.Smooth
	if shape then p.Shape=shape end
	p.Parent=parent; return p
end
local function folder(parent,name)
	local f=Instance.new("Model"); f.Name=name; f.Parent=parent; return f
end
local function text(parent,name,cf,size,words,color)
	local board=piece(parent,name,size,cf,color,false)
	for _,face in {Enum.NormalId.Front,Enum.NormalId.Back} do
		local gui=Instance.new("SurfaceGui"); gui.Name="Lettering"; gui.Face=face
		gui.CanvasSize=Vector2.new(700,220); gui.Parent=board
		local l=Instance.new("TextLabel"); l.Name="Text"; l.Size=UDim2.fromScale(1,1)
		l.BackgroundTransparency=1; l.Font=Enum.Font.GothamBold; l.TextScaled=true
		l.Text=words; l.TextColor3=C.White; l.Parent=gui
		local padding=Instance.new("UIPadding"); padding.PaddingLeft=UDim.new(0,16)
		padding.PaddingRight=UDim.new(0,16); padding.PaddingTop=UDim.new(0,12)
		padding.PaddingBottom=UDim.new(0,12); padding.Parent=l
	end
	return board
end
local function route(parent,name,a,b,width,color)
	local delta=b-a
	-- Os pontos referem-se ao topo do piso, e não ao centro da peça.
	local p=piece(parent,name,Vector3.new(width,.8,delta.Magnitude),
		CFrame.lookAt((a+b)/2-Vector3.new(0,.4,0),b-Vector3.new(0,.4,0)),color,true)
	return p
end
local function window(parent,cf,size)
	local p=piece(parent,"Window",size,cf,Color3.fromRGB(167,226,240),false,Enum.Material.Glass)
	p.Transparency=.18
	return p
end
local function storefront(parent,id,center,heading,color,title)
	local store=folder(parent,id.."Facade")
	local cf=CFrame.new(center)*CFrame.Angles(0,heading,0)
	local function p(name,size,offset,col,solid,mat,shape)
		return piece(store,name,size,cf*CFrame.new(offset),col,solid,mat,shape)
	end
	p("Foundation",Vector3.new(28,2,18),Vector3.new(0,-1,-1),C.Cream,true)
	p("Building",Vector3.new(24,12,16),Vector3.new(0,6,0),C.Cream,true)
	p("Roof",Vector3.new(27,1,19),Vector3.new(0,12.5,0),color,true)
	for _,x in {-8,8} do
		window(store,cf*CFrame.new(x,5,8.15),Vector3.new(5.7,5.8,.25))
		p("WindowFrame",Vector3.new(6.5,.35,.45),Vector3.new(x,8,8.25),color,false)
		p("WindowSill",Vector3.new(6.5,.45,.9),Vector3.new(x,2,8.5),C.White,false)
	end
	p("Door",Vector3.new(3.5,7,.35),Vector3.new(0,3.5,8.3),C.Ink,false)
	p("DoorGlass",Vector3.new(2.5,3.5,.15),Vector3.new(0,4.6,8.55),Color3.fromRGB(152,225,242),false)
	p("DoorHandle",Vector3.new(.18,1,.18),Vector3.new(1,3,8.7),C.Yellow,false)
	for i=1,8 do
		p("AwningStripe_"..i,Vector3.new(3, .5,4),Vector3.new(-13.5+i*3,9,9.8),i%2==0 and color or C.White,false)
		p("AwningValance_"..i,Vector3.new(3,1,.4),Vector3.new(-13.5+i*3,8.6,11.6),i%2==0 and color or C.White,false)
	end
	text(store,"ShopName",cf*CFrame.new(0,11.5,8.6),Vector3.new(19,2.3,.4),title,color)
	if id=="Padaria" then
		for i=1,3 do
			p("Bread_"..i,Vector3.new(1.6,.75,.7),Vector3.new(-10+i*1.6,3.6,8.6),Color3.fromRGB(224,158,79),false,nil,Enum.PartType.Ball)
		end
		text(store,"BakeryMenu",cf*CFrame.new(7,1.7,11),Vector3.new(4,3,.35),"PÃO\nQUENTINHO",C.Wood)
	elseif id=="Clinica" then
		p("HealthCrossVertical",Vector3.new(1,4,.4),Vector3.new(0,15,0),C.Blue,false,Enum.Material.Neon)
		p("HealthCrossHorizontal",Vector3.new(4,1,.4),Vector3.new(0,15,0),C.Blue,false,Enum.Material.Neon)
		text(store,"ClinicBadge",cf*CFrame.new(-8,1.6,11),Vector3.new(4,2.8,.3),"CUIDAR\nFAZ BEM",C.Blue)
	else
		for _,x in {-8,8} do
			p("FruitCrate",Vector3.new(4,1.5,2.5),Vector3.new(x,.75,10.3),C.Wood,false)
			for n=1,4 do
				p("Fruit",Vector3.new(.8,.8,.8),Vector3.new(x-1.4+n*.65,1.7,10.3),x<0 and C.Orange or C.Green,false,nil,Enum.PartType.Ball)
			end
		end
	end
	return store
end
local function tree(parent,index,x,z)
	local model=folder(parent,"Tree_"..index)
	piece(model,"Trunk",Vector3.new(1.8,7,1.8),CFrame.new(x,3.5,z),C.Wood,true,Enum.Material.Wood)
	piece(model,"Crown",Vector3.new(9,10,9),CFrame.new(x,10,z),C.Green,false,nil,Enum.PartType.Ball)
	piece(model,"CrownAccent",Vector3.new(6,6,6),CFrame.new(x+2,13,z),Color3.fromRGB(144,223,109),false,nil,Enum.PartType.Ball)
	piece(model,"Planter",Vector3.new(5,.6,5),CFrame.new(x,.3,z),C.Cream,false)
end
function Decor.Apply(map)
	map.Central.RoundSpawn.CanQuery=false
	map.Central.RoundSpawn.CanTouch=false
	map.Central.ModelStreamingMode=Enum.ModelStreamingMode.Persistent
	for _,d in map.Destinations:GetChildren() do d.ModelStreamingMode=Enum.ModelStreamingMode.Persistent end
	if map:GetAttribute("StyleVersion")==3 then return map end
	-- Cada trecho termina na borda da praça: não há dois pisos na mesma altura.
	local geometry=map.Geometry
	local north=geometry["HighRoadEW_-70"]
	north.Size=Vector3.new(158,2,14); north.CFrame=CFrame.new(0,23,-70)
	local south=geometry["HighRoadEW_70"]
	south.Size=Vector3.new(63,2,14); south.CFrame=CFrame.new(-47.5,23,70)
	local right=geometry:FindFirstChild("HighRoadEW_70_Right")
	if not right then right=south:Clone(); right.Name="HighRoadEW_70_Right"; right.Parent=geometry end
	right.Size=Vector3.new(63,2,14); right.CFrame=CFrame.new(47.5,23,70)
	for _,x in {-92,92} do
		geometry["HighRoadNS_"..x].Size=Vector3.new(14,2,114)
		geometry["HighRoadNS_"..x].CFrame=CFrame.new(x,23,0)
	end
	local corner=geometry:FindFirstChild("SouthWestLanding")
	if not corner then corner=piece(geometry,"SouthWestLanding",Vector3.new(26,2,26),CFrame.new(-92,23,70),C.Cream,true,Enum.Material.Concrete) end
	for _,p in geometry:GetChildren() do
		if p:IsA("BasePart") and p.Name:match("^HighRoad") then p.Color=Color3.fromRGB(59,68,79); p.Material=Enum.Material.Asphalt end
	end
	map.Central.Platform.Color=C.Cream; map.Central.Platform.Material=Enum.Material.Concrete
	for _,d in map.Destinations:GetChildren() do
		d.Platform.Color=Color3.fromRGB(211,217,214); d.Platform.Material=Enum.Material.Concrete
	end
	-- A versão anterior é conservada até a montagem terminar.
	local art=Instance.new("Folder"); art.Name="ArtV3"
	-- O atalho antigo vai para o lado leste, liberando as casas para terraços.
	local shortcut=map.Geometry:FindFirstChild("RiskyFootbridge")
	if shortcut then
		local a,b=Vector3.new(12,24,70),Vector3.new(92,24,-70)
		shortcut.Size=Vector3.new(4,.8,(b-a).Magnitude)
		shortcut.CFrame=CFrame.lookAt((a+b)/2-Vector3.new(0,.4,0),b-Vector3.new(0,.4,0))
	end
	if map.Geometry:FindFirstChild("RiskSign") then map.Geometry.RiskSign.CFrame=CFrame.new(84,28,-57) end
	local destinations=folder(art,"DistrictFacades")
	storefront(destinations,"Padaria",Vector3.new(-92,24,-91),0,C.Yellow,"PADARIA SOL")
	storefront(destinations,"Clinica",Vector3.new(92,24,-91),0,C.Blue,"CLÍNICA AZUL")
	storefront(destinations,"Mercado",Vector3.new(92,24,91),math.pi,C.Green,"MERCADO LIMA")
	for _,d in map.Destinations:GetChildren() do
		local color=d:GetAttribute("Color")
		local center=d.DeliveryPoint.Position
		-- Marcador discreto acima do piso; sem placas atravessando o ciclista.
		for _,x in {-2.8,2.8} do piece(destinations,d.Name.."DropOutline",Vector3.new(.18,.05,5.6),CFrame.new(center.X+x,24.15,center.Z),color,false) end
		for _,z in {-2.8,2.8} do piece(destinations,d.Name.."DropOutline",Vector3.new(5.6,.05,.18),CFrame.new(center.X,24.15,center.Z+z),color,false) end
		d.DeliveryPoint.Transparency=1
		d.DeliveryPoint.Size=Vector3.new(2,.3,2)
		d.DeliveryPoint.Position=Vector3.new(center.X,24.55,center.Z)
		d.DeliveryPoint.CanQuery=false
		d.DeliveryPoint.CanTouch=false
		d.DeliveryPoint.Interaction.UIOffset=Vector2.new(0,-50)
		d.Sign.Transparency=1
		for _,gui in d.Sign:GetChildren() do if gui:IsA("SurfaceGui") then gui.Enabled=false end end
	end
	local depot=folder(art,"DepotDetails")
	piece(depot,"Canopy",Vector3.new(34,1,26),CFrame.new(0,36,70),C.Yellow,true)
	for _,x in {-15,15} do for _,z in {59,81} do
		piece(depot,"CanopyColumn",Vector3.new(.7,11.5,.7),CFrame.new(x,29.75,z),C.Ink,true)
	end end
	for n=1,5 do
		local x=-12+(n%2)*2
		local y=25+math.floor((n-1)/2)*2
		piece(depot,"StackedPackage_"..n,Vector3.new(1.8,1.8,1.8),CFrame.new(x,y,77),C.Wood,false)
		piece(depot,"PackageTape_"..n,Vector3.new(.25,1.85,1.85),CFrame.new(x,y,77),C.Cream,false)
	end
	for n=1,3 do
		piece(depot,"BikeParkingLine",Vector3.new(.16,.05,7),CFrame.new(4+n*3,24.06,74),C.White,false)
	end
	text(depot,"DepotInstruction",CFrame.new(0,34.5,59),Vector3.new(22,2,.3),"PEGUE • PEDALE • ENTREGUE",C.Ink)
	text(depot,"BicycleSign",CFrame.new(9,28.5,64),Vector3.new(7,2,.3),"BICICLETÁRIO",Color3.fromRGB(35,142,146))
	map.Central.Title.CFrame=CFrame.new(0,39,59)
	-- Paisagismo nas bordas, afastado das pistas e rampas.
	local streets=folder(art,"StreetDetails")
	local number=0
	for _,x in {-119,119} do for _,z in {-84,-42,0,42,84} do
		number+=1; tree(streets,number,x,z)
	end end
	for _,x in {-10,10} do
		piece(streets,"CenterSidewalk",Vector3.new(4,.6,128),CFrame.new(x,.3,0),C.Cream,true)
	end
	for _,z in {-70,70} do
		for n=-4,4 do
			piece(streets,"HighRoadLaneMark",Vector3.new(6,.04,.3),CFrame.new(n*20,24.03,z),C.Cream,false)
		end
	end
	for _,x in {-92,92} do
		for n=-2,2 do piece(streets,"HighRoadLaneMark",Vector3.new(.3,.04,6),CFrame.new(x,24.03,n*22),C.Cream,false) end
	end
	for _,x in {-92,0,92} do for n=-3,3 do
		piece(streets,"StreetLaneMark",Vector3.new(.3,.03,5),CFrame.new(x,.22,n*22),C.Yellow,false)
	end end
	for _,position in {Vector3.new(-107,0,-46),Vector3.new(107,0,-46),Vector3.new(-107,0,46),Vector3.new(107,0,46)} do
		local lamp=folder(streets,"StreetLamp")
		piece(lamp,"Pole",Vector3.new(.5,12,.5),CFrame.new(position+Vector3.new(0,6,0)),C.Ink,true)
		local bulb=piece(lamp,"Lamp",Vector3.new(2,.6,2),CFrame.new(position+Vector3.new(0,12,0)),C.Cream,false,Enum.Material.Neon)
		local light=Instance.new("PointLight"); light.Brightness=.7; light.Range=16; light.Color=C.Cream; light.Parent=bulb
	end
	local park=folder(art,"PocketPark")
	piece(park,"Plaza",Vector3.new(25,.4,18),CFrame.new(36,.2,0),C.Cream,true)
	piece(park,"FlowerBed",Vector3.new(6,1,6),CFrame.new(36,.5,0),C.Wood,true)
	for n=1,7 do
		local angle=n*math.pi*2/7
		piece(park,"Flower",Vector3.new(.7,.7,.7),CFrame.new(36+math.cos(angle)*2,1.1,math.sin(angle)*2),n%2==0 and C.Yellow or C.Orange,false,nil,Enum.PartType.Ball)
	end
	for _,z in {-6,6} do
		piece(park,"BenchSeat",Vector3.new(8,.5,2),CFrame.new(36,1.5,z),C.Wood,true)
		piece(park,"BenchBack",Vector3.new(8,2,.4),CFrame.new(36,2.5,z+(z<0 and -1 or 1)),C.Wood,true)
	end
	-- Terraços e passarela alta: cruza a ponte antiga por cima com folga.
	local roofs=folder(art,"RooftopRoute")
	for _,e in {{"South",-38,32,26,C.Orange},{"North",-40,-34,28,C.Yellow}} do
		local baseRoof=map.Geometry[e[1]=="South" and "House_3" or "House_1"].FlatRoof
		local bottom=baseRoof.Position.Y+baseRoof.Size.Y/2
		piece(roofs,e[1].."Loft",Vector3.new(25,e[4]-bottom-1,21),CFrame.new(e[2],(bottom+e[4]-1)/2,e[3]),C.Cream,true)
		piece(roofs,e[1].."Terrace",Vector3.new(29,1,25),CFrame.new(e[2],e[4]-.5,e[3]),e[5],true)
		window(roofs,CFrame.new(e[2]-7,(bottom+e[4])/2,e[3]+10.6),Vector3.new(5,3,.2))
		window(roofs,CFrame.new(e[2]+7,(bottom+e[4])/2,e[3]+10.6),Vector3.new(5,3,.2))
	end
	route(roofs,"DepotToSouthRoof",Vector3.new(-12,24,74),Vector3.new(-38,26,44),6,C.Orange)
	route(roofs,"RoofToSkyBridge",Vector3.new(-38,26,20),Vector3.new(-50,32,13),5,C.Orange)
	route(roofs,"JumpApproach",Vector3.new(-50,32,13),Vector3.new(-50,32,3),5,C.Orange)
	route(roofs,"JumpLanding",Vector3.new(-50,32,-2),Vector3.new(-50,32,-8),5,C.Orange)
	route(roofs,"SkyBridgeToNorthRoof",Vector3.new(-50,32,-8),Vector3.new(-40,28,-22),5,C.Orange)
	route(roofs,"NorthRoofToBakery",Vector3.new(-50,28,-42),Vector3.new(-84,24,-67),6,C.Orange)
	text(roofs,"RooftopEntry",CFrame.new(-12,29,76),Vector3.new(8,2,.3),"TELHADOS\nATALHO A PÉ",C.Orange)
	text(roofs,"JumpWarning",CFrame.new(-53,35,6),Vector3.new(7,2,.3),"PULE O VÃO!",C.Orange)
	for _,z in {3,-2} do piece(roofs,"JumpLip",Vector3.new(5,.08,.5),CFrame.new(-50,32.05,z),C.Yellow,false,Enum.Material.Neon) end
	local signs=folder(art,"RouteSigns")
	text(signs,"SafeRoute",CFrame.new(20,28,72),Vector3.new(8,2,.3),"ROTA SEGURA\nBICICLETA →",Color3.fromRGB(40,153,134))
	text(signs,"RampHint",CFrame.new(-63,6,-47),Vector3.new(9,3,.3),"SUBA A RAMPA\nANTES DA LAVA",C.Ink)
	text(signs,"ParkSign",CFrame.new(46,4,4),Vector3.new(6,2,.3),"PRAÇA LIMA",Color3.fromRGB(40,153,134))
	for _,name in {"ArtV2","ArtV3"} do
		local previous=map:FindFirstChild(name)
		if previous then previous:Destroy() end
	end
	art.Parent=map
	map:SetAttribute("StyleVersion",3)
	return map
end
return Decor

```
## MissionService (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.MissionService
local Service={}; Service.__index=Service
local function action(p,name,reward)
	p:SetAttribute("ActionName",name)
	p:SetAttribute("ActionReward",reward or 0)
	p:SetAttribute("ActionTime",workspace:GetServerTimeNow())
	p:SetAttribute("ActionSequence",(p:GetAttribute("ActionSequence") or 0)+1)
end
function Service.new(map,players,state,config)
	local self=setmetatable({Map=map,Players=players,State=state,Config=config,Connections={},Random=Random.new()},Service)
	table.insert(self.Connections,map.Central.PackageCounter.Interaction.Triggered:Connect(function(p)
		if self:Valid(p,map.Central.PackageCounter) then self:Give(p) end
	end))
	for _,d in map.Destinations:GetChildren() do
		table.insert(self.Connections,d.DeliveryPoint.Interaction.Triggered:Connect(function(p) self:Deliver(p,d) end))
	end
	return self
end
function Service:Valid(p,point)
	local r=self.Players.Records[p]
	local root=self.Players:Root(p)
	return self.Config.Stage>=2 and self.State:GetAttribute("Phase")=="Round"
		and r and r.Active and root and (root.Position-point.Position).Magnitude<=self.Config.PromptDistance
end
function Service:Give(p,previous)
	local r=self.Players.Records[p]
	local root=self.Players:Root(p)
	if not r or not r.Active or r.Package or not root or self.State:GetAttribute("Phase")~="Round" then return end
	local options={}
	for _,d in self.Map.Destinations:GetChildren() do if d.Name~=previous then table.insert(options,d) end end
	local destination=options[self.Random:NextInteger(1,#options)]
	local box=Instance.new("Part")
	box.Name="DeliveryPackage"; box.Size=Vector3.new(1.5,1.8,1)
	box.Color=Color3.fromRGB(188,131,74); box.Material=Enum.Material.SmoothPlastic
	box.CanCollide=false; box.CanTouch=false; box.CanQuery=false; box.Massless=true
	box.CFrame=root.CFrame*CFrame.new(0,.1,1.2)
	box.Parent=p.Character
	local weld=Instance.new("WeldConstraint"); weld.Part0=root; weld.Part1=box; weld.Parent=box
	r.Package,r.Destination=box,destination.Name
	p:SetAttribute("HasPackage",true); p:SetAttribute("DestinationId",destination.Name)
	if not previous then action(p,"Collect",0) end
end
function Service:Deliver(p,d)
	if not self:Valid(p,d.DeliveryPoint) then return end
	local r=self.Players.Records[p]
	if not r.Package or not r.Package.Parent or r.Destination~=d.Name then return end
	-- Não há yields nesta transação: consumir antes de premiar evita entrega duplicada.
	self.Players:ClearPackage(p)
	r.Deliveries+=1
	p:SetAttribute("Deliveries",r.Deliveries)
	if self.Config.Stage>=3 then r.Coins.Value+=self.Config.Reward end
	self:Give(p,d.Name)
	action(p,"Deliver",self.Config.Stage>=3 and self.Config.Reward or 0)
end
return Service

```
## PlayerService (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.PlayerService
local Players = game:GetService("Players")
local Service = {}
Service.__index = Service
function Service.new(map)
	local self=setmetatable({Map=map, Records={}, Connections={}},Service)
	self.Connections[1]=Players.PlayerAdded:Connect(function(p) self:Add(p) end)
	self.Connections[2]=Players.PlayerRemoving:Connect(function(p) self:Remove(p) end)
	for _,p in Players:GetPlayers() do self:Add(p) end
	return self
end
function Service:Add(p)
	if self.Records[p] then return end
	local stats=Instance.new("Folder"); stats.Name="leaderstats"; stats.Parent=p
	local coins=Instance.new("IntValue"); coins.Name="Moedas"; coins.Parent=stats
	local r={Player=p, Coins=coins, Active=false, Deliveries=0, Package=nil, Destination=nil, Connections={}}
	self.Records[p]=r
	for k,v in {Active=false,HasPackage=false,DestinationId="",Deliveries=0,RidingBike=false,BikeSpeed=0,ActionName="",ActionTime=0,ActionReward=0,ActionSequence=0} do p:SetAttribute(k,v) end
	p.RespawnLocation=self.Map.Lobby.LobbySpawn
	r.Connections[1]=p.CharacterAdded:Connect(function(c) self:Character(p,c) end)
	if p.Character then task.spawn(function() self:Character(p,p.Character) end) end
end
function Service:Character(p,c)
	local h=c:WaitForChild("Humanoid",10)
	local root=c:WaitForChild("HumanoidRootPart",10)
	local r=self.Records[p]
	if not h or not root or not r or p.Character~=c then return end
	if r.DeathConnection then r.DeathConnection:Disconnect() end
	r.DeathConnection=h.Died:Connect(function() self:Eliminate(p,"Caiu ou foi eliminado") end)
	-- Um respawn nunca permite voltar à rodada atual.
	if r.Active then self:Eliminate(p,"Personagem reapareceu") end
	c:PivotTo(self.Map.Lobby.LobbySpawn.CFrame+Vector3.new(0,4,0))
end
function Service:Root(p)
	local c=p.Character
	local h=c and c:FindFirstChildOfClass("Humanoid")
	local root=c and c:FindFirstChild("HumanoidRootPart")
	if h and h.Health>0 and root then return root,h end
end
function Service:ClearPackage(p)
	local r=self.Records[p]; if not r then return end
	if r.Package then r.Package:Destroy() end
	r.Package,r.Destination=nil,nil
	p:SetAttribute("HasPackage",false); p:SetAttribute("DestinationId","")
end
function Service:Activate(p,index)
	local r=self.Records[p]
	local root,h=self:Root(p)
	if not r or not root then return false end
	self:ClearPackage(p)
	h.Sit=false
	r.Active,r.Deliveries=true,0
	p:SetAttribute("Active",true); p:SetAttribute("Deliveries",0); p:SetAttribute("EliminationReason","")
	p:SetAttribute("ActionName",""); p:SetAttribute("ActionTime",0)
	local offset=Vector3.new(((index-1)%5-2)*4,4,math.floor((index-1)/5)*4)
	p.Character:PivotTo(self.Map.Central.RoundSpawn.CFrame+offset)
	root.AssemblyLinearVelocity=Vector3.zero
	return true
end
function Service:Eliminate(p,reason)
	local r=self.Records[p]; if not r or not r.Active then return end
	r.Active=false
	p:SetAttribute("Active",false); p:SetAttribute("EliminationReason",reason)
	self:ClearPackage(p)
	if self.OnEliminated then self.OnEliminated(p) end
	local root,h=self:Root(p)
	if h then h.Sit=false end
	if root and p.Character then
		p.Character:PivotTo(self.Map.Lobby.LobbySpawn.CFrame+Vector3.new(0,4,0))
		root.AssemblyLinearVelocity=Vector3.zero
	end
end
function Service:Finish()
	for p,r in self.Records do
		r.Active=false; p:SetAttribute("Active",false)
		self:ClearPackage(p)
		local root,h=self:Root(p)
		if h then h.Sit=false end
		if root and p.Character then
			p.Character:PivotTo(self.Map.Lobby.LobbySpawn.CFrame+Vector3.new(0,4,0))
			root.AssemblyLinearVelocity=Vector3.zero
		end
	end
end
function Service:Count()
	local n=0
	for _,r in self.Records do if r.Active then n+=1 end end
	return n
end
function Service:Remove(p)
	local r=self.Records[p]; if not r then return end
	if self.OnEliminated then self.OnEliminated(p) end
	self:ClearPackage(p)
	if r.DeathConnection then r.DeathConnection:Disconnect() end
	for _,c in r.Connections do c:Disconnect() end
	self.Records[p]=nil
end
return Service

```
## RampFix (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.RampFix
-- Entrada rente ao chão e classificação explícita de rampas cicláveis.
local Fix={}
function Fix.Apply(map)
	for _,e in {
		{"RampCentral",Vector3.new(-70,0,-50),Vector3.new(-70,24,63)},
		{"RampNorth",Vector3.new(70,0,50),Vector3.new(70,24,-63)},
	} do
		local ramp=map.Geometry:FindFirstChild(e[1])
		if ramp then
			local a,b=e[2],e[3]
			local thickness=.6
			local cf=CFrame.lookAt((a+b)/2,b)
			-- Compensa a espessura: a superfície superior começa em Y=0.
			ramp.Size=Vector3.new(12,thickness,(b-a).Magnitude)
			ramp.CFrame=cf-Vector3.new(0,thickness/(2*cf.UpVector.Y),0)
			ramp:SetAttribute("BikeRamp",true)
		end
	end
	-- O atalho passa acima das vias, sem formar um teto baixo na rampa norte.
	local bridge=map.Geometry:FindFirstChild("RiskyFootbridge")
	if bridge then
		local a,b=Vector3.new(30,32,38),Vector3.new(108,32,-50)
		for _,entry in {
			{"RiskyFootbridge",a,b},
			{"RiskyFootbridgeApproach",Vector3.new(8,24,59),a},
			{"RiskyFootbridgeExit",b,Vector3.new(101,24,-70)},
		} do
			local part=map.Geometry:FindFirstChild(entry[1])
			if not part then part=bridge:Clone(); part.Name=entry[1]; part.Parent=map.Geometry end
			local start,finish=entry[2],entry[3]
			local cf=CFrame.lookAt((start+finish)/2,finish)
			part.Size=Vector3.new(4,.8,(finish-start).Magnitude)
			part.CFrame=cf-Vector3.new(0,.4/cf.UpVector.Y,0)
		end
	end
	map:SetAttribute("RampVersion",5)
	return map
end
return Fix

```
## RoundService (ModuleScript)
```luau
-- ModuleScript: ServerScriptService.EntregaOuJaEra.Modules.RoundService
local Players=game:GetService("Players")
local HttpService=game:GetService("HttpService")
local Service={}; Service.__index=Service
function Service.new(ps,missions,lava,bikes,state,config)
	return setmetatable({Players=ps,Missions=missions,Lava=lava,Bikes=bikes,State=state,Config=config},Service)
end
function Service:Phase(name,duration)
	self.State:SetAttribute("Phase",name)
	self.State:SetAttribute("EndsAt",workspace:GetServerTimeNow()+duration)
end
function Service:ReadyCount()
	local count=0; for p in self.Players.Records do if self.Players:Root(p) then count+=1 end end
	return count
end
function Service:Run()
	while true do
		self:Phase("Waiting",0)
		while #Players:GetPlayers()==0 or self:ReadyCount()==0 do task.wait(.5) end
		self:Phase("Intermission",self.Config.Intermission)
		local aborted=false
		while workspace:GetServerTimeNow()<self.State:GetAttribute("EndsAt") do
			if #Players:GetPlayers()==0 then aborted=true; break end
			task.wait(.2)
		end
		if aborted or self:ReadyCount()==0 then continue end
		local participants={}
		self.State:SetAttribute("Results","[]")
		self.State:SetAttribute("RoundNumber",(self.State:GetAttribute("RoundNumber") or 0)+1)
		self:Phase("Round",self.Config.RoundDuration)
		local start=workspace:GetServerTimeNow()
		for _,p in Players:GetPlayers() do
			if self.Players:Activate(p,#participants+1) then
				table.insert(participants,{Player=p,Name=p.DisplayName,UserId=p.UserId,Record=self.Players.Records[p]})
				if self.Config.Stage>=2 then self.Missions:Give(p) end
			end
		end
		self.Lava:Start()
		while workspace:GetServerTimeNow()<self.State:GetAttribute("EndsAt") and self.Players:Count()>0 do
			self.Lava:Update(workspace:GetServerTimeNow()-start)
			self.State:SetAttribute("ActivePlayers",self.Players:Count())
			task.wait(.1)
		end
		-- Primeiro fechar as entregas; depois destruir objetos e deslocar personagens.
		self:Phase("Results",self.Config.ResultsDuration)
		local results={}
		for _,entry in participants do
			table.insert(results,{Name=entry.Name,UserId=entry.UserId,Deliveries=entry.Record.Deliveries,
				Coins=entry.Record.Coins.Value,Left=entry.Player.Parent~=Players})
		end
		table.sort(results,function(a,b)
			if a.Deliveries~=b.Deliveries then return a.Deliveries>b.Deliveries end
			return a.UserId<b.UserId
		end)
		self.State:SetAttribute("Results",HttpService:JSONEncode(results))
		self.State:SetAttribute("ActivePlayers",0)
		self.Bikes:Clear(); self.Lava:Stop(); self.Players:Finish()
		participants={}
		while workspace:GetServerTimeNow()<self.State:GetAttribute("EndsAt") and #Players:GetPlayers()>0 do task.wait(.2) end
	end
end
return Service

```

