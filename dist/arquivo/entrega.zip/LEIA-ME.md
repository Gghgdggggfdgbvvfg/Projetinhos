Versão 5: consulte CORRECOES-RAMPA.md para a correção das rampas e a validação realizada.

# Entrega ou Já Era! — versão 4: UI e sons

Esta é a versão atual instalada em Place1. O mapa e a bicicleta da v3 foram preservados. A interface agora usa cartões pequenos em tom de papel, relógio separado, carteira no canto, ficha de destino e classificação em colunas. Foram removidos o título gigante do HUD, avisos repetidos e o placar padrão duplicado. O aviso da lava aparece por 6 segundos e depois fica indicado no relógio.

Novo script: **GameAudio.client.luau**, LocalScript em StarterPlayer.StarterPlayerScripts.GameAudio. Total: **14 scripts**. EntregaHUD e DeliveryEffects foram atualizados.

## Sons e controle de volume

Coleta, entrega em duas notas, início/fim de rodada, aviso da lava, últimos dez segundos, eliminação, botões e movimento da bicicleta. Os dez objetos Sound foram carregados e verificados no cliente.

Os sons usam arquivos nativos do Roblox: switch.wav, electronicpingshort.wav, action_jump.mp3 e action_footsteps_plastic.mp3. O efeito da bicicleta é uma textura mecânica simulada com o áudio de passos, volume baixo e equalização; não é uma gravação real de bicicleta. Não há música de fundo nesta versão.

GameAudio cria SoundService.CourierAudio e CourierMix somente no cliente. Todos os sons são locais; não foram adicionados RemoteEvents. A coleta/entrega lê ActionSequence validado no servidor. O loop da bicicleta para ao desmontar ou parar. O botão Som: ligado/mudo ajusta CourierMix.Volume entre 0.8 e 0, conservando a escolha durante a sessão/respawn. Edite o início de GameAudio para trocar arquivos, volume ou PlaybackSpeed.

## Testes executados

- Desktop: HUD, carteira, destino/distância e resultado com uma entrega/25 moedas.
- Dez efeitos carregados, com IsLoaded=true e duração maior que zero.
- Coleta e entrega reais acionaram os efeitos. A segunda nota de entrega estava em reprodução após premiar.
- Bicicleta: IsPlaying=true e TimePosition avançando durante o movimento; loop parou ao desmontar.
- Botão de silenciar: Volume=0; segundo clique restaurou 0.8.
- Prazo de teste reduzido em memória: últimos segundos acionaram o tick; eliminação acionou efeito e encerramento tocou End. Os padrões de Config permanecem intactos.
- Aviso da lava: transição simulada no cliente acionou LavaWarning, IsPlaying=true.
- Simulador iPhone 17 Pro: paisagem (viewport 750×381) e retrato (401×778); UI verificada por captura e medidas dos objetos. StarterGui.ScreenOrientation=Sensor; ScreenInsets=CoreUISafeInsets. Controles têm área de 56×44; botão Som tem altura de 44 no touch.
- No retrato, input Touch no botão de avançar moveu a bicicleta (BikeSpeed=31.9). O salto padrão ficou escondido enquanto montado, evitando sobreposição.
- Último log sem erro dos scripts do jogo. Studio devolvido a Edit e viewport normal, simulador desativado.

A verificação confirmou carregamento e reprodução dos sons por estado/TimePosition; não incluiu avaliação auditiva por gravação. Testes em celular físico e multiplayer continuam recomendados.

Veja UI-NOVA.jpg, UI-CELULAR.jpg e RESULTADO.jpg. O guia abaixo é o histórico/base da v3; o pacote e CODIGO-COMPLETO.md já incluem os scripts da v4.

---

# Entrega ou Já Era! — versão 3

Esta versão corrige o piso verde sobreposto ao cinza e substitui a bicicleta por um modelo com quadro tubular, pneus vazados, aros, raios, garfo, selim arredondado e transmissão. Veja CORRECOES-V3.md e as duas imagens de resultado. A versão já está instalada em Place1.

## Explorer e scripts

```text
ServerScriptService
  EntregaOuJaEra (Folder)
    Bootstrap (Script)
    Modules (Folder)
      BikeModel (ModuleScript)
      BikeService (ModuleScript)
      Config (ModuleScript)
      LavaService (ModuleScript)
      MapBuilder (ModuleScript)
      MapDecor (ModuleScript)
      MissionService (ModuleScript)
      PlayerService (ModuleScript)
      RoundService (ModuleScript)
StarterPlayer.StarterPlayerScripts
  EntregaHUD (LocalScript — arquivo HUD.client.luau)
  CourierAnimations (LocalScript)
  DeliveryEffects (LocalScript)
Workspace.EntregaMap
  Geometry / Central / Destinations / Lobby / Runtime
  ArtV3 (Folder)
    DistrictFacades / DepotDetails / StreetDetails
    PocketPark / RooftopRoute / RouteSigns
```

Os nomes de todos os arquivos correspondem ao nome do script, removendo .luau/.client.luau/.server.luau, exceto HUD.client.luau, que se instala como EntregaHUD. Cada código tem tipo e local no comentário inicial. CODIGO-COMPLETO.md reúne integralmente os 13 scripts.

## Jogar e salvar

Pressione Play. Há 15 segundos de intervalo, rodada de 180 segundos e lava após 30 segundos. Você recebe um pacote e destino aleatório. Entregue com E ou toque no prompt. Cada entrega correta vale 25 moedas e gera uma nova missão. Use a central para pegar/recuperar a bicicleta; WASD/setas ou botões touch para dirigir; Espaço/Descer para desmontar. A lava elimina até a próxima rodada. Moedas são apenas da sessão.

Salve o lugar pelo menu File/Arquivo como Entrega ou Já Era!.rbxl. Esta atualização não publica o jogo automaticamente.

## Instalar em outro lugar

Em uma Baseplate, pare o Play, abra a Command Bar e execute todo o conteúdo de Instalar.command.luau. O instalador escreve os scripts e monta mapa/decoração em Edit. Ele não é um Script de gameplay. Faça backup de scripts homônimos antes de usá-lo em outro projeto.

Para montagem manual, crie a estrutura acima e cole os arquivos correspondentes. Bootstrap monta automaticamente MapBuilder e MapDecor quando o jogo começa. Para visualizar antes de Play, execute MapBuilder.Build() e MapDecor.Apply(map) pela Command Bar.

## Configuração e mapa

Config.Stage controla a implementação progressiva: 1 rodadas; 2 missões; 3 moedas/interface; 4 lava; 5 bicicleta. Pare Play antes de mudar o valor. Os padrões são Intermission=15, RoundDuration=180, ResultsDuration=10, LavaDelay=30, LavaStart=-4, LavaEnd=22, Reward=25 e BikeSpeed=32.

O chão da cidade está em Y=0; circuito seguro e pontos de entrega têm piso Y=24; telhados seguros em Y=26/28 e passarela alta em Y=32. O salto tem vão de 5 studs. Preserve alturas acima da lava e os nomes Central, Destinations, DeliveryPoint e Interaction ao editar.

As ruas elevadas agora terminam nas bordas das plataformas. Não recoloque placas de piso sobrepostas na mesma altura. As fachadas ficam atrás dos destinos. A área de entrega é um contorno discreto; o ponto do prompt é invisível. ArtV3 contém as melhorias e StyleVersion=3 impede duplicação. Central e os três destinos usam ModelStreamingMode Persistent.

BikeModel constrói a bicicleta detalhada. Só Frame é ancorada; os demais componentes são soldados ou articulados a ela. WheelMotor_1, WheelMotor_2 e CrankMotor animam rodas/pedais. BikeService move a estrutura e valida proprietário/comandos. A condução continua arcade. Não ancore separadamente rodas, selim ou pedais, pois isso quebraria as articulações.

## Testes nas cinco etapas

1. Stage=1: confirme lobby, início após 15s, duração 180s, resultado e novo ciclo. Reinicie o avatar: deve ser eliminado.
2. Stage=2: confirme pacote único, destino aleatório, rejeição de distância/destino errado e missão renovada.
3. Stage=3: cada entrega soma 25 moedas; moedas ficam na rodada seguinte, entregas voltam a zero; confira HUD e classificação.
4. Stage=4: lava ativa após 30s, rua baixa elimina e retira pacote; quando todos morrem, encerra; circuito Y=24 permanece seguro.
5. Stage=5: monte, avance, freie, vire, desmonte, remonte e entregue; confira rodas/pedais, colisões, rampas e ausência de pisos cintilando.

Execute Regressao.command.luau na Command Bar do servidor durante Play: a regressão deve imprimir PASS: 20 verificações. Teste também Server & Clients com dois jogadores e Device Emulator/celular. Validação de todos os tipos de avatar e de todas as rampas continua pendente.

