# Versão 4

Os testes de UI, áudio, mute e dispositivos estão registrados no início de LEIA-ME.md. Abaixo, histórico das versões anteriores.

# Testes da versão 3

Veja CORRECOES-V3.md: 78 pares de superfícies sem sobreposição; montagem e condução do novo modelo; prompt apenas no destino correto; recuperação do HUD após ponto ausente; regressão PASS: 20 verificações. Não houve erro do jogo no último log após as correções. O ajuste final de aparência do selim foi inspecionado em Edit.

Os registros abaixo são o histórico das versões anteriores.

# Verificação realizada no Roblox Studio — versões 1 e 2

## Atualização da versão 2

Testada diretamente no Studio em 14/10/2026. A versão final foi devolvida ao modo Edit.

- `MapDecor` montou 380 objetos de arte, texto e geometria adicional. Aplicar novamente não duplicou objetos.
- A sessão iniciou com 12 scripts e `StyleVersion=2`.
- Avatar R15 usando **AnimationConstraint**: o script procedural encontrou as articulações e aplicou pose de condução. Duas amostras de Transform da coxa durante movimento foram diferentes, confirmando pedalada dinâmica. Ao parar, a pose ficou estável.
- Prompt montou a bicicleta, `BikeSpeed` refletiu o deslocamento e os raios apareceram nas rodas.
- Uma entrega real pelo ProximityPrompt concedeu 25 moedas, somou uma entrega e publicou `ActionName=Deliver`, `ActionReward=25` e sequência 2.
- O cliente mostrou `DeliveryToast` com “ENTREGUE! +25 moedas”, visível durante o teste. Scripts de gesto/efeitos carregaram sem erros do jogo.
- Regressão isolada: **PASS: 20 verificações**, incluindo os novos sinais de coleta e entrega e ausência de sinal de sucesso para destino incorreto.
- Geometria: 18 amostras ao longo das seis passarelas por telhados ficaram acima de `LavaEnd` e sem teto sólido a menos de 5,5 studs. O vão de salto permaneceu aberto.
- Raycast sobre o marcador de spawn encontrou piso Y=24, sem colisão indevida. Na sessão final, a bicicleta passou por essa região mantendo Y≈25,3.
- Capturas visuais revisadas: fachadas, cobertura, praça, árvores, telhados e postura do entregador.

Ainda não foram testados todos os avatares R6/customizados, vários clientes simultâneos, celular real, nem uma travessia manual completa do novo salto. O roteiro do guia permanece disponível para esses testes.

## Histórico dos testes da versão 1

Executado no projeto conectado **Place1**, em 14/10/2026. O Studio foi devolvido ao modo **Edit** ao terminar. A configuração de produção permanece `Stage=5`, lobby de 15s, rodada de 180s e lava após 30s.

## Confirmado na sessão com um cliente

- Bootstrap iniciou a etapa 5 e todos os módulos carregaram.
- Lobby, início de rodada e teleporte para a central funcionaram.
- Pacote inicial foi criado e destino aleatório replicou para o cliente.
- Interface exibiu cronômetro, moedas, entregas, distância, marcador individual e alerta da lava.
- Prompt real do bicicletário criou a bicicleta, montou o jogador e habilitou controles.
- Entradas W/D moveram e giraram a bicicleta pelo servidor; posição passou de `(7,25.3,74)` para aproximadamente `(-33.28,25.3,64.38)` após comandos de avanço/curva.
- Desmontar funcionou.
- Entrega pelo ProximityPrompt correto deu 25 moedas, somou uma entrega e mudou de Clínica para Mercado, mantendo apenas um pacote.
- Repetir o prompt da Clínica depois de renovar a missão não concedeu outra recompensa.
- Lava eliminou ao posicionar o personagem na rua inundada; pacote desapareceu e jogador foi ao lobby.
- Quando o único participante foi eliminado, rodada terminou antecipadamente e apareceu resultado com 1 entrega e 25 moedas.
- `Runtime` ficou vazio após o término, sem lava ou bicicleta residual.
- Na rodada seguinte, moedas permaneceram em 25 e entregas voltaram a zero.
- Captura visual mostrou mapa e HUD funcionando. Não houve erro de execução originado pelos scripts do jogo durante esses fluxos.

Para acelerar a verificação dos prompts, personagens foram posicionados por comandos no servidor. Em uma rodada de teste, apenas o atributo de prazo em memória foi ampliado para impedir que ela terminasse durante os comandos. Essas alterações desapareceram ao parar Play; os valores de Config não foram alterados.

## Regressão isolada

`Regressao.command.luau` foi executado no servidor durante Play: **PASS, 16 verificações**. Ele usa personagem e jogador simulados, remove seus objetos ao terminar e não modifica os jogadores reais.

Verificou coleta válida, pacote único, rejeição de destino errado, distância excessiva, fase de resultados e espectador; recompensa correta; nova missão; rejeição de entrega repetida; lava antes/depois de 30s; sobrevivência acima da lava; eliminação; conservação de moedas; limpeza da parte e conexão da lava.

## Ainda precisa de teste manual

- Sessão com dois ou mais clientes: entrada no meio da rodada, saída de sobrevivente, bicicletas individuais e câmera de espectador acompanhando outro jogador.
- Celular real ou Device Emulator: proporções em retrato/paisagem, toques simultâneos, prompts e controles da bicicleta.
- Percorrer continuamente todas as rampas e atalhos, especialmente colisão e queda de bicicleta.
- Servidor vazio sem clientes e publicação em servidor real.

O projeto inclui a lógica para esses casos, mas esta entrega não afirma que esses testes foram executados. Veja o roteiro das cinco etapas em `LEIA-ME.md`.
