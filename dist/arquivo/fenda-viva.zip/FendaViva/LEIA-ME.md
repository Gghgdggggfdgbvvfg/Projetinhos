# Fenda Viva — Crônicas dos Reinos

Sobrevivência medieval em pixel art colorida. Mova seu cavaleiro entre hordas enquanto ele ataca sozinho. Colete cristais, escolha melhorias e vença os guardiões de quatro reinos procedurais.

Esta edição usa **uma arena ampla por reino**, com surgimento contínuo de inimigos. A campanha inclui quatro reinos; ao vencer o quarto guardião, você conclui a jornada.

## Jogar

Execute **Jogar.cmd**. O atalho encontra o Godot instalado neste computador, importa os recursos e abre o jogo. Alternativamente, importe **project.godot** no **Godot 4.7.2** e pressione **F5**.

O ZIP contém o projeto-fonte completo, sem um executável autônomo com o motor embutido. Em outro computador, use Godot 4.7.2; se necessário, defina `GODOT_BIN` com o caminho do executável.

| Ação | Controle |
|---|---|
| Mover | WASD ou setas |
| Esquivar | Espaço |
| Pausar/continuar | Esc |
| Escolher melhoria | Clique ou 1, 2, 3 |
| Mirar e atacar | Automático |

**Não é necessário clicar para atirar.** As armas escolhem inimigos próximos dentro do alcance e com linha de visão. É possível andar e atacar simultaneamente; a esquiva interrompe os disparos brevemente e respeita obstáculos.

Cristais próximos são atraídos para o herói. Os distantes ficam no chão até você se aproximar. Maçãs recuperam vida. Ao atingir a experiência necessária, a ação pausa para escolher uma melhoria.

## Evolução e campanha

Você começa com a **Besta do viajante**. No nível **4**, recebe a **Rajada de adagas**; no nível **7**, recebe o **Cajado das faíscas**. As três armas atacam juntas, com cadências e alcances independentes.

São 12 melhorias: dano, cadência, vida, cura, velocidade, esquiva, multidisparo, perfuração, crítico, veneno, explosão e escudo. Veneno acumula até três doses e expira; projéteis adicionais podem perfurar; eliminações críticas amplificam explosões. O escudo absorve um golpe e se recupera em 12 segundos.

| Reino | Cenário |
|---|---|
| Campina do Estandarte | Campos, árvores, acampamentos e estradas |
| Bosque dos Carvalhos | Vegetação e caminhos entre carvalhos |
| Ruínas de Âmbar | Pedra dourada, colunas e arcos antigos |
| Castelo Celeste | Pátio, mosaicos, jardins, muralhas e torres azuis |

O guardião aparece após **2min30s de combate ativo** em cada reino. As hordas crescem em quantidade e variedade. Durante o confronto com o guardião, os reforços diminuem. Derrote-o para avançar; o quarto guardião encerra a campanha.

Ao avançar, você mantém nível, armas e melhorias, recebe os cristais restantes no chão e recupera 40% da vida máxima. O próximo reino fica **desbloqueado permanentemente no menu**. Uma nova partida pelo menu sempre começa no nível 1, inclusive nos reinos já desbloqueados.

Morrer encerra a build da tentativa, mas preserva os reinos desbloqueados. Não há salvamento de partida em andamento.

## Geração procedural

A semente no menu é opcional. Vazio cria uma semente nova; repetir um número reproduz os quatro mapas da campanha.

As arenas medem 2560×1920 unidades. Caminhos, árvores, pedras, ruínas, acampamentos e decoração mudam conforme a semente e o reino. O centro é seguro; os obstáculos têm separação mínima e os espaços livres permanecem conectados. Geração, decoração e combate usam fontes de aleatoriedade separadas.

Os pontos e a composição das hordas também variam. Os surgimentos ficam afastados do herói, têm aviso e são revalidados antes de materializar o inimigo. A câmera acompanha o jogador dentro dos limites do mapa.

As hordas continuam surgindo enquanto a etapa estiver ativa, inclusive durante o chefe. Inimigos comuns abandonados muito longe e fora da tela liberam espaço para novas hordas próximas. Chefes permanecem até serem derrotados.

## Visual, áudio e ajustes

Pixel art original produzida em código: cavaleiro de capa azul, goblins, arqueiros, javalis, ogros e guardiões coroados. Campos verdes, pedra dourada, interface de pergaminho azul e ouro e áudio sintetizado de inspiração medieval. Nenhum asset comprado, plugin ou serviço externo é necessário.

**Ajustes** oferece volumes independentes, tela cheia, redução de flashes e tremor configurável. Preferências são salvas em `user://settings.cfg`; desbloqueios ficam em `user://kingdoms.cfg`, na pasta de dados de usuário do Godot.

## Organização

- `scripts/core/`: campanha, estados, experiência, recompensas e áudio.
- `scripts/progression/`: diretor de hordas e cristais/itens físicos.
- `scripts/world/`: geração, arena, colisões e cenário em pixel art.
- `scripts/actors/`: jogador, ataque automático, inimigos e sprites.
- `scripts/combat/`: vida, dano, hitboxes, hurtboxes e projéteis.
- `scripts/data/` e `resources/`: definições editáveis de armas, inimigos, melhorias e reinos.
- `scripts/ui/`: menu, HUD, progressão, ajustes e resultados.
- `tests/`: suítes executáveis no motor.

Algumas cenas e recursos da primeira edição permanecem como referência. O fluxo principal atual usa `SurvivalArena` e `HordeDirector`.

Balanceamento pode ser editado nos arquivos `.tres`, na duração dos reinos e no diretor de hordas. Atributos são calculados como **(base + aditivos) × multiplicadores**, sem alterar a base. Os projéteis fazem varredura entre quadros e continuam válidos se o emissor for eliminado.

## Testar e expandir

Execute `powershell -File Jogar.ps1 -Verificar` para importar e rodar as suítes principais. Esse modo usa um perfil temporário próprio, sem alterar seus reinos desbloqueados ou ajustes. Os dados de teste ficam na pasta temporária do Windows.

O teste prolongado adicional é:

```text
godot --headless --path CAMINHO_DO_PROJETO --script res://tests/test_horde_stress.gd
```

Os resultados executados estão em **VALIDACAO.md**. Os scripts de captura abrem uma janela e salvam imagens de teste em `work/survival-captures`, dois níveis acima do projeto.

O percurso completo tem dez minutos de sobrevivência programada, mais confrontos com guardiões e escolhas. Isso descreve a configuração do ritmo, não uma duração medida com jogadores humanos. Builds e dificuldade ainda podem ser ajustadas após suas partidas.

Esta versão tem quatro reinos, três armas simultâneas e quatro arquétipos de inimigos com guardiões. Remapeamento pela interface, personagens selecionáveis, inventário permanente e salvamento durante a partida não estão incluídos.
