param([switch]$Verificar)
$ErrorActionPreference = 'Stop'
$projectPath = $PSScriptRoot

# The source distribution uses an installed Godot 4 executable.
$candidates = @(
    $env:GODOT_BIN,
    (Join-Path $projectPath 'Godot.exe'),
    (Join-Path $env:USERPROFILE 'Downloads\Godot_v4.7.2-stable_win64.exe\Godot_v4.7.2-stable_win64_console.exe'),
    (Join-Path $env:USERPROFILE 'Downloads\Godot_v4.7.2-stable_win64_console.exe')
)
foreach ($name in @('godot', 'godot4')) {
    $command = Get-Command $name -ErrorAction SilentlyContinue
    if ($command) { $candidates += $command.Source }
}
$godotExe = $null
foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
        $godotExe = $candidate
        break
    }
}
if (-not $godotExe) {
    Write-Host 'Godot 4 nao encontrado. Abra project.godot no Godot e pressione F5.'
    Write-Host 'Tambem pode definir GODOT_BIN com o caminho do executavel Godot 4.'
    exit 1
}
$version = & $godotExe --version
if ($version -notmatch '^4\.') {
    Write-Host "E necessario Godot 4.x. Versao encontrada: $version"
    exit 1
}
Write-Host "Fenda Viva - Godot $version"
if ($Verificar) {
    # Validation must never unlock worlds or change the player's preferences.
    $savedAppData = $env:APPDATA
    $savedLocalAppData = $env:LOCALAPPDATA
    $validationData = Join-Path ([IO.Path]::GetTempPath()) ('FendaViva-tests-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $validationData -Force | Out-Null
    $env:APPDATA = $validationData
    $env:LOCALAPPDATA = $validationData
    try {
        Write-Host 'Preparando recursos para verificacao isolada...'
        & $godotExe --headless --path $projectPath --editor --import --quit
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
        foreach ($test in @('test_worlds', 'test_auto_combat', 'test_survival', 'test_survival_ui')) {
            & $godotExe --headless --path $projectPath --script "res://tests/$test.gd"
            if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
        }
    } finally {
        $env:APPDATA = $savedAppData
        $env:LOCALAPPDATA = $savedLocalAppData
    }
    exit 0
}
Write-Host 'Preparando recursos locais...'
& $godotExe --headless --path $projectPath --editor --import --quit
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
# This is the interactive game window, intentionally visible to the player.
& $godotExe --path $projectPath
exit $LASTEXITCODE
