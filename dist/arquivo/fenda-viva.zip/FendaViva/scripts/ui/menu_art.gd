extends Control
## Original pixel illustration: a sunny kingdom and its travelling knight.

var clock: float = 0.0
var animate: bool = true

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)

func _process(delta: float) -> void:
	if animate:
		clock += delta
		if int(clock * 8.0) != int((clock - delta) * 8.0):
			queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("cbe4d7"))
	var factor: float = maxf(size.x / 1280.0, size.y / 800.0)
	draw_set_transform(Vector2(size.x - 1280.0 * factor, 0), 0, Vector2.ONE * factor)
	draw_rect(Rect2(0, 0, 1280, 520), Color("c9e4e4"))
	draw_rect(Rect2(0, 0, 1280, 160), Color("b9d9df"))
	draw_rect(Rect2(1040, 92, 68, 68), Color("f9d57c"))
	draw_rect(Rect2(1028, 104, 92, 44), Color("f9d57c"))
	_cloud(Vector2(734, 114), 1.0)
	_cloud(Vector2(1128, 214), 0.8)
	_cloud(Vector2(527, 55), 0.65)
	_hill(224, 354, Color("91b9a7"), 0)
	_hill(186, 396, Color("789e87"), 87)
	_hill(142, 450, Color("61865f"), 17)
	draw_rect(Rect2(0, 468, 1280, 332), Color("709553"))
	draw_rect(Rect2(0, 522, 1280, 278), Color("85a65a"))
	_castle(Vector2(967, 221))
	draw_colored_polygon(PackedVector2Array([Vector2(1019, 412), Vector2(1049, 412), Vector2(1196, 550), Vector2(1070, 590), Vector2(934, 510)]), Color("c7b77f"))
	for i: int in range(24):
		var x: float = float((i * 137 + 31) % 1280)
		var y: float = 472 + float((i * 43) % 92)
		draw_rect(Rect2(x, y, 4, 8), Color("a7bb68"))
		draw_rect(Rect2(x + 4, y + 5, 4, 3), Color("a7bb68"))
		if i % 3 == 0:
			draw_rect(Rect2(x + 12, y - 2, 4, 5), Color("f5d48c"))
	_tree(Vector2(1204, 430), 1.2)
	_tree(Vector2(765, 420), 0.75)
	_tree(Vector2(1268, 502), 1.65)
	_knight(Vector2(885, 451), 3.0)
	draw_rect(Rect2(0, 584, 1280, 216), Color("e9dfbd"))
	draw_rect(Rect2(0, 584, 1280, 4), Color("c5ae77"))
	for i: int in range(80):
		var x: float = float((i * 193) % 1280)
		var y: float = 596 + float((i * 59) % 202)
		draw_rect(Rect2(x, y, 2, 2), Color(0.45, 0.38, 0.22, 0.06))
	draw_set_transform(Vector2.ZERO)

func _cloud(origin: Vector2, scale_factor: float) -> void:
	var offset: float = floor(sin(clock * 0.12 + origin.x) * 4.0)
	var color: Color = Color("eef1de")
	for rect: Rect2 in [Rect2(0, 16, 100, 16), Rect2(18, 0, 32, 32), Rect2(48, 8, 34, 24)]:
		draw_rect(Rect2(origin + Vector2(offset, 0) + rect.position * scale_factor, rect.size * scale_factor), color)

func _hill(height: int, baseline: int, color: Color, phase: int) -> void:
	for x: int in range(0, 1280, 32):
		var rise: float = floor((sin(float(x + phase) * 0.005) * 0.5 + 0.5) * float(height) / 16.0) * 16.0
		draw_rect(Rect2(x, baseline - rise, 32, 600 - baseline + rise), color)

func _castle(origin: Vector2) -> void:
	var stone: Color = Color("e0d1a6")
	var shadow: Color = Color("b2aa88")
	draw_rect(Rect2(origin + Vector2(-51, 84), Vector2(218, 107)), stone)
	draw_rect(Rect2(origin + Vector2(-51, 168), Vector2(218, 23)), shadow)
	for x: int in [-63, 105]:
		draw_rect(Rect2(origin + Vector2(x, 20), Vector2(68, 171)), shadow)
		draw_rect(Rect2(origin + Vector2(x, 20), Vector2(48, 171)), stone)
		for step: int in range(4):
			draw_rect(Rect2(origin + Vector2(x - 10 + step * 8, 20 - step * 12), Vector2(88 - step * 16, 12)), Color("416a83"))
		draw_rect(Rect2(origin + Vector2(x + 29, -56), Vector2(3, 34)), Color("866837"))
		draw_rect(Rect2(origin + Vector2(x + 32, -54), Vector2(31, 16)), Color("e5b552"))
		draw_rect(Rect2(origin + Vector2(x + 26, 58), Vector2(12, 27)), Color("48616a"))
		draw_rect(Rect2(origin + Vector2(x + 26, 121), Vector2(12, 27)), Color("48616a"))
	for x: int in range(-5, 108, 26):
		draw_rect(Rect2(origin + Vector2(x, 72), Vector2(15, 20)), stone)
	for y: int in range(104, 173, 24):
		for x: int in range(-32, 154, 40):
			draw_rect(Rect2(origin + Vector2(x + (12 if y % 48 == 8 else 0), y), Vector2(18, 3)), shadow)
	draw_rect(Rect2(origin + Vector2(36, 139), Vector2(42, 52)), Color("725d43"))
	draw_rect(Rect2(origin + Vector2(42, 133), Vector2(30, 58)), Color("725d43"))
	draw_rect(Rect2(origin + Vector2(54, 139), Vector2(5, 52)), Color("4b4b41"))

func _tree(origin: Vector2, scale_factor: float) -> void:
	for rect: Rect2 in [Rect2(-6, -9, 12, 42), Rect2(-14, -24, 10, 30)]:
		draw_rect(Rect2(origin + rect.position * scale_factor, rect.size * scale_factor), Color("806b43"))
	for rect: Rect2 in [Rect2(-34, -52, 68, 36), Rect2(-22, -78, 48, 50), Rect2(-42, -40, 78, 22)]:
		draw_rect(Rect2(origin + rect.position * scale_factor, rect.size * scale_factor), Color("416847"))
	for rect: Rect2 in [Rect2(-26, -60, 48, 26), Rect2(-16, -76, 32, 30), Rect2(-36, -42, 38, 17)]:
		draw_rect(Rect2(origin + rect.position * scale_factor, rect.size * scale_factor), Color("63864f"))

func _knight(origin: Vector2, scale_factor: float) -> void:
	var shapes: Array[Array] = [
		[Rect2(-12, 10, 29, 6), "5e7847"], [Rect2(-15, -24, 12, 32), "315876"],
		[Rect2(-18, -10, 13, 22), "315876"], [Rect2(-5, -7, 8, 22), "344c54"],
		[Rect2(6, -7, 8, 22), "344c54"], [Rect2(-7, 13, 11, 4), "324450"],
		[Rect2(6, 13, 11, 4), "324450"], [Rect2(-6, -24, 21, 21), "637e88"],
		[Rect2(-4, -24, 12, 17), "b8ced0"], [Rect2(-7, -10, 22, 4), "d6b052"],
		[Rect2(-7, -42, 22, 19), "56717b"], [Rect2(-4, -45, 17, 16), "c1d6d0"],
		[Rect2(-7, -35, 24, 5), "324d60"], [Rect2(8, -35, 5, 10), "87a4af"],
		[Rect2(-2, -51, 7, 9), "deb858"], [Rect2(-12, -23, 8, 10), "aec7c5"],
		[Rect2(14, -19, 10, 8), "aec7c5"], [Rect2(24, -29, 4, 28), "b6a17a"],
		[Rect2(14, -17, 24, 4), "725d43"], [Rect2(-15, -15, 14, 22), "cba247"],
		[Rect2(-13, -13, 10, 16), "315876"], [Rect2(-10, -11, 4, 12), "e8ca78"],
		[Rect2(-12, -7, 8, 4), "e8ca78"],
	]
	for shape: Array in shapes:
		var rect: Rect2 = shape[0]
		draw_rect(Rect2(origin + rect.position * scale_factor, rect.size * scale_factor), Color(shape[1]))
