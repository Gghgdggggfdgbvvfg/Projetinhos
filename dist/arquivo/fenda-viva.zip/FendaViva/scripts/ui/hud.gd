class_name GameHUD
extends CanvasLayer
## The interface observes game state; only FendaGame owns state transitions.

const MenuArt = preload("res://scripts/ui/menu_art.gd")
const Minimap = preload("res://scripts/ui/minimap.gd")
const INK: Color = Color("263f4e")
const MUTED: Color = Color("5d6b65")
const TEAL: Color = Color("3b718a")
const CORAL: Color = Color("b7523e")
const GOLD: Color = Color("98702b")
const PANEL: Color = Color("f3e9cc")
const BORDER: Color = Color("c5b587")

var game: FendaGame
var _root: Control
var _hud: Control
var _overlay: Control
var _screen: String = ""
var _settings_open: bool = false
var _health: ProgressBar
var _health_text: Label
var _dash: ProgressBar
var _dash_text: Label
var _weapon: Label
var _depth: Label
var _seed: Label
var _time: Label
var _status: Label
var _hint: Label
var _map: Control
var _boss: VBoxContainer
var _boss_health: ProgressBar
var _boss_name: Label
var _options: Array[UpgradeData] = []
var _update_time: float = 0.0
var _seed_input: LineEdit
var _xp: ProgressBar
var _level: Label
var _kills: Label
var _selected_world: int = 0
var _world_buttons: Array[Button] = []

func setup(owner_game: FendaGame) -> void:
	game = owner_game
	layer = 20
	_root = Control.new()
	_root.name = "Interface"
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.theme = _theme()
	add_child(_root)
	_build_hud()
	_overlay = Control.new()
	_overlay.name = "Telas"
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_overlay)
	refresh()

func _theme() -> Theme:
	var theme_data: Theme = Theme.new()
	theme_data.default_font_size = 16
	theme_data.set_color("font_color", "Label", INK)
	theme_data.set_color("font_color", "Button", INK)
	theme_data.set_color("font_hover_color", "Button", TEAL)
	theme_data.set_color("font_pressed_color", "Button", INK)
	theme_data.set_color("font_disabled_color", "Button", MUTED)
	theme_data.set_stylebox("disabled", "Button", _style(Color("ddd6bb"), BORDER, 1, 16))
	theme_data.set_stylebox("normal", "Button", _style(PANEL, BORDER, 1, 16))
	theme_data.set_stylebox("hover", "Button", _style(Color("e2dbbe"), TEAL, 1, 16))
	theme_data.set_stylebox("pressed", "Button", _style(Color("aac7c7"), TEAL, 1, 16))
	theme_data.set_stylebox("focus", "Button", _style(Color(0, 0, 0, 0), GOLD, 2, 16))
	theme_data.set_stylebox("normal", "LineEdit", _style(Color("fff5dd"), BORDER, 1, 12))
	theme_data.set_stylebox("focus", "LineEdit", _style(Color("fff5dd"), TEAL, 1, 12))
	theme_data.set_color("font_color", "LineEdit", INK)
	theme_data.set_color("font_placeholder_color", "LineEdit", MUTED)
	theme_data.set_color("caret_color", "LineEdit", TEAL)
	theme_data.set_color("font_color", "CheckButton", INK)
	theme_data.set_color("font_hover_color", "CheckButton", TEAL)
	theme_data.set_constant("separation", "VBoxContainer", 12)
	theme_data.set_constant("separation", "HBoxContainer", 12)
	return theme_data

func _style(fill: Color, border: Color = BORDER, thickness: int = 1, padding: int = 0) -> StyleBoxFlat:
	var box: StyleBoxFlat = StyleBoxFlat.new()
	box.bg_color = fill
	box.border_color = border
	box.set_border_width_all(thickness)
	box.corner_radius_top_left = 4
	box.corner_radius_top_right = 4
	box.corner_radius_bottom_left = 4
	box.corner_radius_bottom_right = 4
	box.content_margin_left = padding
	box.content_margin_right = padding
	box.content_margin_top = padding
	box.content_margin_bottom = padding
	return box

func _label(text_value: String, font_size: int = 16, color: Color = INK) -> Label:
	var node: Label = Label.new()
	node.text = text_value
	node.add_theme_font_size_override("font_size", font_size)
	node.add_theme_color_override("font_color", color)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return node

func _paragraph(text_value: String, font_size: int = 16, color: Color = MUTED) -> Label:
	var node: Label = _label(text_value, font_size, color)
	node.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return node

func _button(text_value: String, callback: Callable, primary: bool = false) -> Button:
	var button: Button = Button.new()
	button.text = text_value
	button.custom_minimum_size.y = 48
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	button.add_theme_font_size_override("font_size", 16)
	if primary:
		button.add_theme_stylebox_override("normal", _style(TEAL, TEAL, 1, 14))
		button.add_theme_stylebox_override("hover", _style(Color("50829a"), INK, 1, 14))
		button.add_theme_color_override("font_color", Color("fff5dc"))
		button.add_theme_color_override("font_hover_color", Color("fff5dc"))
		button.add_theme_color_override("font_focus_color", Color("fff5dc"))
	button.pressed.connect(func() -> void:
		game.play_sound("ui")
		callback.call()
	)
	return button

func _bar(color: Color, height: float) -> ProgressBar:
	var bar: ProgressBar = ProgressBar.new()
	bar.custom_minimum_size.y = height
	bar.show_percentage = false
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_theme_stylebox_override("background", _style(Color("d0c6a8"), Color.TRANSPARENT, 0))
	bar.add_theme_stylebox_override("fill", _style(color, color, 0))
	return bar

func _fill(control: Control, parent: Node) -> void:
	parent.add_child(control)
	control.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _margin(parent: Node, amount: int = 28) -> MarginContainer:
	var margin: MarginContainer = MarginContainer.new()
	margin.add_theme_constant_override("margin_left", amount)
	margin.add_theme_constant_override("margin_right", amount)
	margin.add_theme_constant_override("margin_top", amount)
	margin.add_theme_constant_override("margin_bottom", amount)
	parent.add_child(margin)
	return margin

func _build_hud() -> void:
	_hud = Control.new()
	_hud.name = "HUD"
	_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fill(_hud, _root)
	var top_panel: PanelContainer = PanelContainer.new()
	_hud.add_child(top_panel)
	top_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	top_panel.offset_left = 24
	top_panel.offset_right = -24
	top_panel.offset_top = 16
	top_panel.add_theme_stylebox_override("panel", _style(Color("f3e9ccee"), BORDER, 2, 14))
	top_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var top: HBoxContainer = HBoxContainer.new()
	top.add_theme_constant_override("separation", 28)
	top_panel.add_child(top)
	var left: VBoxContainer = VBoxContainer.new()
	left.custom_minimum_size.x = 230
	left.add_theme_constant_override("separation", 5)
	top.add_child(left)
	var health_row: HBoxContainer = HBoxContainer.new()
	left.add_child(health_row)
	var name_label: Label = _label("VITALIDADE", 11, MUTED)
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	health_row.add_child(name_label)
	_health_text = _label("100 / 100", 16)
	health_row.add_child(_health_text)
	_health = _bar(Color("c56348"), 10)
	left.add_child(_health)
	_dash_text = _label("ESPAÇO · ESQUIVA PRONTA", 10, MUTED)
	left.add_child(_dash_text)
	_dash = _bar(Color("547e9b"), 4)
	left.add_child(_dash)
	var middle: VBoxContainer = VBoxContainer.new()
	middle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	middle.add_theme_constant_override("separation", 3)
	top.add_child(middle)
	_depth = _label("", 20)
	_depth.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	middle.add_child(_depth)
	_status = _label("", 12, TEAL)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	middle.add_child(_status)
	_kills = _label("", 11, MUTED)
	_kills.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	middle.add_child(_kills)
	var path_column: VBoxContainer = VBoxContainer.new()
	path_column.custom_minimum_size.x = 172
	path_column.add_theme_constant_override("separation", 1)
	top.add_child(path_column)
	var heading: Label = _label("JORNADA DOS REINOS", 10, MUTED)
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	path_column.add_child(heading)
	_map = Minimap.new()
	_map.game = game
	path_column.add_child(_map)
	var pause: Button = _button("Ⅱ", game.toggle_pause)
	pause.tooltip_text = "Pausar · Esc"
	pause.custom_minimum_size = Vector2(42, 42)
	pause.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top.add_child(pause)
	var bottom_panel: PanelContainer = PanelContainer.new()
	_hud.add_child(bottom_panel)
	bottom_panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bottom_panel.offset_top = -112
	bottom_panel.offset_bottom = -16
	bottom_panel.offset_left = 24
	bottom_panel.offset_right = -24
	bottom_panel.add_theme_stylebox_override("panel", _style(Color("f3e9ccee"), BORDER, 2, 12))
	bottom_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var column: VBoxContainer = VBoxContainer.new()
	column.add_theme_constant_override("separation", 5)
	bottom_panel.add_child(column)
	var xp_row: HBoxContainer = HBoxContainer.new()
	column.add_child(xp_row)
	_level = _label("NÍVEL 1", 15, TEAL)
	_level.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	xp_row.add_child(_level)
	_time = _label("00:00", 14)
	xp_row.add_child(_time)
	_xp = _bar(Color("55a6b8"), 9)
	column.add_child(_xp)
	var bottom: HBoxContainer = HBoxContainer.new()
	column.add_child(bottom)
	_weapon = _label("", 11, INK)
	_weapon.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(_weapon)
	bottom.add_child(_label("WASD / SETAS  mover    ESPAÇO  esquivar    ESC  pausar", 10, MUTED))
	_seed = _label("", 9, MUTED)
	_seed.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_seed.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	bottom.add_child(_seed)
	_hint = _label("", 14, INK)
	_hud.add_child(_hint)
	_hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_hint.offset_top = -144
	_hint.offset_bottom = -119
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.add_theme_color_override("font_shadow_color", Color("fff5dd"))
	_hint.add_theme_constant_override("shadow_offset_x", 1)
	_hint.add_theme_constant_override("shadow_offset_y", 1)
	_boss = VBoxContainer.new()
	_hud.add_child(_boss)
	_boss.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_boss.offset_left = -230
	_boss.offset_right = 230
	_boss.offset_top = 124
	_boss.add_theme_constant_override("separation", 3)
	_boss_name = _label("", 12, INK)
	_boss_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_boss_name.add_theme_color_override("font_outline_color", Color("fff3d7"))
	_boss_name.add_theme_constant_override("outline_size", 4)
	_boss.add_child(_boss_name)
	_boss_health = _bar(CORAL, 8)
	_boss.add_child(_boss_health)
	_boss.hide()

func _process(delta: float) -> void:
	if game == null or _root == null:
		return
	_update_time += delta
	if _update_time >= 0.10:
		_update_time = 0.0
		_update_hud()

func _input(event: InputEvent) -> void:
	if game == null:
		return
	if _settings_open and event.is_action_pressed("pause"):
		_settings_open = false
		_screen = ""
		refresh()
		get_viewport().set_input_as_handled()
		return
	if game.state == "upgrade" and not _settings_open and event is InputEventKey and event.pressed and not event.echo:
		var key_event: InputEventKey = event as InputEventKey
		var choice: int = int(key_event.physical_keycode) - int(KEY_1)
		if choice >= 0 and choice < _options.size():
			game.choose_upgrade(_options[choice].id)
			get_viewport().set_input_as_handled()

func refresh() -> void:
	if game == null or _overlay == null:
		return
	_hud.visible = game.state not in ["menu", "loading"]
	_update_hud()
	if _settings_open:
		return
	match game.state:
		"menu":
			if _screen != "menu":
				show_menu()
		"paused":
			if _screen != "paused":
				_show_pause()
		"world_complete":
			if _screen != "world_complete":
				show_world_complete()
		"defeat", "victory":
			if _screen != game.state:
				show_end(game.state == "victory")
		"upgrade":
			if _screen != "upgrade" and not _options.is_empty():
				show_upgrade(_options)
		_:
			if _screen != "":
				_clear_overlay()
			_screen = ""

func _update_hud() -> void:
	if _health == null:
		return
	if is_instance_valid(game.player):
		var player: FendaPlayer = game.player
		_health.max_value = player.max_hp
		_health.value = player.hp
		_health_text.text = "%d / %d" % [ceili(player.hp), ceili(player.max_hp)]
		var cooldown: float = player.dash_cooldown
		_dash.max_value = maxf(0.25, player.dash_recharge * float(game.stats.get("dash_mult", 1.0)))
		_dash.value = maxf(0.0, _dash.max_value - cooldown)
		_dash_text.text = "ESPAÇO · ESQUIVA PRONTA" if cooldown <= 0.0 else "ESPAÇO · RECARGA %.1fs" % cooldown
	var weapon_names: PackedStringArray = []
	for weapon: WeaponData in game.catalog.weapons():
		if weapon.id in game.active_weapons:
			weapon_names.append(weapon.display_name)
	_weapon.text = "AUTO · " + " / ".join(weapon_names)
	_depth.text = game.world_data().display_name.to_upper()
	var remaining: float = maxf(0.0, game.world_data().duration - game.world_time)
	_status.text = "GUARDIÃO EM %s" % _format_time(remaining) if not game.boss_spawned else "DERROTE O GUARDIÃO DO REINO"
	_kills.text = "%d ELIMINAÇÕES  ·  REINO %d / %d" % [game.kills, game.world_index + 1, game.worlds.size()]
	_level.text = "NÍVEL %d  ·  %d / %d EXP" % [game.player_level, game.experience, game.experience_needed]
	_xp.max_value = game.experience_needed
	_xp.value = game.experience
	_hint.text = "Mova-se e colete cristais. Seu herói ataca sozinho." if game.world_time < 18.0 else ""
	_seed.text = "SEMENTE %d" % game.seed_value
	_time.text = _format_time(game.run_time)
	_map.queue_redraw()
	_boss.hide()
	for enemy: FendaEnemy in game.enemies:
		if is_instance_valid(enemy) and enemy.is_boss and not enemy.dead:
			_boss.show()
			_boss_health.max_value = enemy.max_hp
			_boss_health.value = enemy.hp
			_boss_name.text = game.world_data().boss_name.to_upper() + (" · FÚRIA" if enemy.hp <= enemy.max_hp * 0.5 else "")
			break

func _clear_overlay() -> void:
	for child: Node in _overlay.get_children():
		_overlay.remove_child(child)
		child.queue_free()
	_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _dim() -> void:
	var dark: ColorRect = ColorRect.new()
	dark.color = Color(0.10, 0.20, 0.22, 0.76)
	dark.mouse_filter = Control.MOUSE_FILTER_STOP
	_fill(dark, _overlay)

func _center_panel(width: float = 620.0, padding: int = 32) -> VBoxContainer:
	var center: CenterContainer = CenterContainer.new()
	_fill(center, _overlay)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size.x = width
	panel.add_theme_stylebox_override("panel", _style(PANEL, BORDER, 1, padding))
	center.add_child(panel)
	var column: VBoxContainer = VBoxContainer.new()
	column.add_theme_constant_override("separation", 16)
	panel.add_child(column)
	return column

func show_menu() -> void:
	if _overlay == null:
		return
	_clear_overlay()
	_screen = "menu"
	_settings_open = false
	_hud.hide()
	_selected_world = clampi(_selected_world, 0, game.unlocked_world)
	var art: Control = MenuArt.new()
	art.animate = not bool(game.settings.get("reduced_flashes", false))
	_fill(art, _overlay)
	var panel: PanelContainer = PanelContainer.new()
	_overlay.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	panel.position = Vector2(58, 38)
	panel.custom_minimum_size = Vector2(514, 508)
	panel.add_theme_stylebox_override("panel", _style(Color("f3e9ccef"), BORDER, 2, 28))
	var column: VBoxContainer = VBoxContainer.new()
	column.add_theme_constant_override("separation", 11)
	panel.add_child(column)
	column.add_child(_label("UM HERÓI. QUATRO REINOS. INCONTÁVEIS HORDAS.", 10, TEAL))
	column.add_child(_label("FENDA VIVA", 58, INK))
	column.add_child(_label("CRÔNICAS DOS REINOS", 20, GOLD))
	column.add_child(_paragraph("Mova-se. O herói ataca sozinho.\nColete cristais, escolha melhorias e enfrente\nos guardiões de um reino sempre diferente.", 17, INK))
	column.add_child(_paragraph("Caminhos, árvores e ruínas mudam a cada semente.\nAvance entre mundos mantendo sua evolução.", 13, MUTED))
	var spacer: Control = Control.new()
	spacer.custom_minimum_size.y = 3
	column.add_child(spacer)
	var play: Button = _button("PARTIR PARA A AVENTURA    →", _start_from_menu, true)
	column.add_child(play)
	play.grab_focus()
	var row: HBoxContainer = HBoxContainer.new()
	column.add_child(row)
	_seed_input = LineEdit.new()
	_seed_input.placeholder_text = "Semente opcional"
	_seed_input.tooltip_text = "Deixe vazio para novos mapas. Use um número para repetir a geração dos quatro reinos."
	_seed_input.max_length = 10
	_seed_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_seed_input.custom_minimum_size.y = 44
	_seed_input.text_submitted.connect(func(_entered: String) -> void: _start_from_menu())
	row.add_child(_seed_input)
	row.add_child(_button("AJUSTES", _show_settings))
	column.add_child(_label("3 ARMAS AUTOMÁTICAS  ·  12 MELHORIAS  ·  MAPAS PROCEDURAIS", 10, MUTED))
	var journey: VBoxContainer = VBoxContainer.new()
	_overlay.add_child(journey)
	journey.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	journey.offset_left = 58
	journey.offset_right = -58
	journey.offset_top = -186
	journey.offset_bottom = -46
	journey.add_theme_constant_override("separation", 10)
	journey.add_child(_label("ESCOLHA O REINO INICIAL  ·  VENÇA UM GUARDIÃO PARA DESBLOQUEAR O PRÓXIMO", 11, INK))
	var cards: HBoxContainer = HBoxContainer.new()
	journey.add_child(cards)
	_world_buttons.clear()
	for index: int in range(game.worlds.size()):
		var world: WorldData = game.worlds[index]
		var unlocked: bool = index <= game.unlocked_world
		var card: Button = _button("", _select_world.bind(index))
		card.custom_minimum_size = Vector2(0, 98)
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.disabled = not unlocked
		card.tooltip_text = world.description if unlocked else "Derrote o guardião do reino anterior para desbloquear."
		card.add_theme_font_size_override("font_size", 14)
		cards.add_child(card)
		_world_buttons.append(card)
	_update_world_cards()
	var footer: Label = _label("WASD / SETAS · MOVER     ESPAÇO · ESQUIVAR     ESC · PAUSAR     ATAQUES AUTOMÁTICOS", 10, MUTED)
	_overlay.add_child(footer)
	footer.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	footer.offset_top = -30
	footer.offset_bottom = -12
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _select_world(index: int) -> void:
	if index < 0 or index > game.unlocked_world:
		return
	_selected_world = index
	_update_world_cards()

func _update_world_cards() -> void:
	for index: int in range(_world_buttons.size()):
		var card: Button = _world_buttons[index]
		var world: WorldData = game.worlds[index]
		var unlocked: bool = index <= game.unlocked_world
		var selected: bool = index == _selected_world
		card.text = "%02d  %s\n\n%s" % [index + 1, world.display_name, "SELECIONADO" if selected else ("DISPONÍVEL" if unlocked else "BLOQUEADO")]
		card.add_theme_stylebox_override("normal", _style(Color("d2e0d3") if selected else PANEL, TEAL if selected else BORDER, 2 if selected else 1, 12))

func _start_from_menu() -> void:
	var entered: String = _seed_input.text.strip_edges()
	if not entered.is_empty() and not entered.is_valid_int():
		_seed_input.text = ""
		_seed_input.placeholder_text = "Digite apenas números"
		return
	game.start_run(maxi(0, int(entered)) if not entered.is_empty() else -1, _selected_world)

func _show_pause() -> void:
	_clear_overlay()
	_screen = "paused"
	_dim()
	var column: VBoxContainer = _center_panel(520)
	column.add_child(_label("UMA PAUSA NA JORNADA", 11, TEAL))
	column.add_child(_label("ACAMPAMENTO", 44))
	column.add_child(_paragraph("Seu herói descansa. A aventura espera por você.", 16))
	var continue_button: Button = _button("CONTINUAR    →", game.resume_run, true)
	column.add_child(continue_button)
	continue_button.grab_focus()
	column.add_child(_button("ÁUDIO E ACESSIBILIDADE", _show_settings))
	column.add_child(_button("VOLTAR AO MENU", game.go_menu))
	column.add_child(_paragraph("WASD / setas · mover    |    Espaço · esquivar\nColete cristais para evoluir. As armas atacam sozinhas.\nNível 4 · adagas    |    Nível 7 · cajado    |    Esc · continuar", 13))

func show_upgrade(options: Array[UpgradeData]) -> void:
	_options = options.duplicate()
	if _overlay == null:
		return
	_clear_overlay()
	_screen = "upgrade"
	_settings_open = false
	_dim()
	var column: VBoxContainer = _center_panel(1050, 30)
	column.add_child(_label("NÍVEL %d · SEU HERÓI EVOLUIU" % game.player_level, 11, TEAL))
	column.add_child(_label("ESCOLHA UMA MELHORIA", 34))
	column.add_child(_paragraph("Aprimore seu herói. Suas escolhas e armas acompanham você pelos próximos reinos.", 15))
	var cards: HBoxContainer = HBoxContainer.new()
	cards.add_theme_constant_override("separation", 18)
	column.add_child(cards)
	for i in range(_options.size()):
		var upgrade: UpgradeData = _options[i]
		var card: Button = _button("", game.choose_upgrade.bind(upgrade.id))
		card.custom_minimum_size = Vector2(300, 330)
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.tooltip_text = upgrade.description
		cards.add_child(card)
		if i == 0:
			card.grab_focus()
		var margin: MarginContainer = _margin(card, 22)
		margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var content: VBoxContainer = VBoxContainer.new()
		content.mouse_filter = Control.MOUSE_FILTER_IGNORE
		content.add_theme_constant_override("separation", 14)
		margin.add_child(content)
		var color: Color = GOLD if upgrade.rarity in ["rare", "raro", "rara"] else TEAL
		if upgrade.rarity in ["epic", "épico", "épica"]:
			color = Color("8b5a9e")
		var top_row: HBoxContainer = HBoxContainer.new()
		top_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		content.add_child(top_row)
		var key: Label = _label("0%d" % (i + 1), 27, color)
		key.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		top_row.add_child(key)
		if upgrade.icon != null:
			var icon: TextureRect = TextureRect.new()
			icon.texture = upgrade.icon
			icon.custom_minimum_size = Vector2(36, 36)
			icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
			top_row.add_child(icon)
		var rarity_names: Dictionary = {"common": "COMUM", "uncommon": "INCOMUM", "rare": "RARA", "epic": "ÉPICA"}
		content.add_child(_label(String(rarity_names.get(upgrade.rarity, upgrade.rarity.to_upper())), 10, color))
		var title: Label = _paragraph(upgrade.display_name, 23, INK)
		content.add_child(title)
		var desc: Label = _paragraph(upgrade.description, 15, MUTED)
		desc.size_flags_vertical = Control.SIZE_EXPAND_FILL
		content.add_child(desc)
		var count: int = int(game.stacks.get(upgrade.id, 0))
		var usage: String = "CONSUMO IMEDIATO" if upgrade.operation == "heal" else "ACÚMULO %d / %d" % [count, upgrade.max_stacks]
		content.add_child(_label(usage, 10, MUTED))
		content.add_child(_label("ESCOLHER    →", 13, color))
	column.add_child(_label("ESCOLHA COM O MOUSE OU PRESSIONE 1, 2 OU 3", 11, MUTED))

func _show_settings() -> void:
	_clear_overlay()
	_settings_open = true
	_dim()
	var column: VBoxContainer = _center_panel(640, 30)
	column.add_theme_constant_override("separation", 12)
	column.add_child(_label("AO SEU RITMO", 11, TEAL))
	column.add_child(_label("ÁUDIO E ACESSIBILIDADE", 27))
	for setting: Array in [["master", "Volume geral"], ["music", "Música"], ["effects", "Efeitos"], ["ui", "Interface"], ["shake", "Tremor de câmera"]]:
		var key: String = String(setting[0])
		var row: HBoxContainer = HBoxContainer.new()
		column.add_child(row)
		var caption: Label = _label(String(setting[1]), 15)
		caption.custom_minimum_size.x = 170
		row.add_child(caption)
		var slider: HSlider = HSlider.new()
		slider.min_value = 0.0
		slider.max_value = 1.0
		slider.step = 0.01
		slider.value = float(game.settings.get(key, 1.0))
		slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		slider.custom_minimum_size.y = 28
		row.add_child(slider)
		var percent: Label = _label("%d%%" % roundi(slider.value * 100.0), 14, MUTED)
		percent.custom_minimum_size.x = 50
		percent.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(percent)
		slider.value_changed.connect(func(value: float) -> void:
			game.set_setting(key, value)
			percent.text = "%d%%" % roundi(value * 100.0)
		)
	var flashes: CheckButton = CheckButton.new()
	flashes.text = "Reduzir flashes e animação do menu"
	flashes.button_pressed = bool(game.settings.get("reduced_flashes", false))
	flashes.toggled.connect(func(value: bool) -> void: game.set_setting("reduced_flashes", value))
	column.add_child(flashes)
	var fullscreen: CheckButton = CheckButton.new()
	fullscreen.text = "Tela cheia"
	fullscreen.button_pressed = bool(game.settings.get("fullscreen", false))
	fullscreen.toggled.connect(func(value: bool) -> void: game.set_setting("fullscreen", value))
	column.add_child(fullscreen)
	column.add_child(_paragraph("Os ajustes são salvos automaticamente. Ataques inimigos também são sinalizados por formas e marcas no chão.", 12))
	column.add_child(_button("VOLTAR", _close_settings, true))

func _close_settings() -> void:
	_settings_open = false
	_screen = ""
	refresh()

func show_end(won: bool) -> void:
	if _overlay == null:
		return
	_clear_overlay()
	_screen = "victory" if won else "defeat"
	_settings_open = false
	_dim()
	var column: VBoxContainer = _center_panel(800, 32)
	var color: Color = TEAL if won else CORAL
	column.add_child(_label("OS QUATRO REINOS AGRADECEM" if won else "UMA NOVA AVENTURA ESPERA", 11, color))
	column.add_child(_label("HERÓI DOS REINOS" if won else "FIM DA JORNADA", 34))
	column.add_child(_paragraph("Todos os guardiões foram vencidos. Os reinos estão livres!" if won else "Cada aventura traz novos caminhos. Os reinos desbloqueados continuam disponíveis.", 15))
	var stats_row: HBoxContainer = HBoxContainer.new()
	stats_row.add_theme_constant_override("separation", 28)
	column.add_child(stats_row)
	for item: Array in [[_format_time(game.run_time), "TEMPO"], [str(game.kills), "ELIMINAÇÕES"], [str(game.worlds_cleared), "REINOS VENCIDOS"], [str(game.player_level), "NÍVEL"], [str(game.upgrades_taken.size()), "MELHORIAS"]]:
		var stat_column: VBoxContainer = VBoxContainer.new()
		stat_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		stat_column.add_theme_constant_override("separation", 3)
		stats_row.add_child(stat_column)
		stat_column.add_child(_label(String(item[0]), 28, color))
		stat_column.add_child(_label(String(item[1]), 10, MUTED))
	var divider: HSeparator = HSeparator.new()
	column.add_child(divider)
	column.add_child(_label("MELHORIAS DO SEU HERÓI", 11, MUTED))
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.custom_minimum_size.y = 95
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	var taken: Dictionary = {}
	for id: String in game.upgrades_taken:
		taken[id] = int(taken.get(id, 0)) + 1
	var lines: PackedStringArray = []
	for id: String in taken:
		var upgrade: UpgradeData = game.catalog.upgrade(id)
		var display_name: String = upgrade.display_name if upgrade != null else id
		lines.append("%s  ×%d" % [display_name, int(taken[id])])
	var list: Label = _paragraph("  ·  ".join(lines) if not lines.is_empty() else "Nenhuma melhoria escolhida nesta aventura.", 15)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)
	column.add_child(_label("SEMENTE  %d  ·  Use este número no menu para repetir o mapa." % game.seed_value, 11, MUTED))
	var actions: HBoxContainer = HBoxContainer.new()
	column.add_child(actions)
	var again: Button = _button("NOVA TENTATIVA    →", func() -> void: game.start_run(), true)
	again.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(again)
	again.grab_focus()
	var menu: Button = _button("VOLTAR AO MENU", game.go_menu)
	menu.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(menu)

func _format_time(seconds: float) -> String:
	var total: int = int(seconds)
	return "%02d:%02d" % [total / 60, total % 60]

func show_world_complete() -> void:
	if _overlay == null:
		return
	_clear_overlay()
	_screen = "world_complete"
	_settings_open = false
	_dim()
	var column: VBoxContainer = _center_panel(720, 32)
	column.add_child(_label("GUARDIÃO VENCIDO · CAMINHO DESBLOQUEADO", 11, GOLD))
	column.add_child(_label("REINO CONQUISTADO", 34, INK))
	column.add_child(_paragraph("%s está livre! Você conserva seu nível, suas armas e melhorias ao avançar. Recupera 40%% da vitalidade máxima." % game.world_data().display_name, 17, INK))
	var next: WorldData = game.worlds[mini(game.world_index + 1, game.worlds.size() - 1)]
	column.add_child(_label("PRÓXIMO DESTINO · " + next.display_name.to_upper(), 20, TEAL))
	column.add_child(_paragraph(next.description, 15, MUTED))
	column.add_child(_label("NÍVEL %d  ·  %d ELIMINAÇÕES  ·  %d MELHORIAS" % [game.player_level, game.kills, game.upgrades_taken.size()], 13, GOLD))
	var advance: Button = _button("AVANÇAR PARA O PRÓXIMO REINO    →", game.advance_world, true)
	column.add_child(advance)
	advance.grab_focus()
	column.add_child(_button("VOLTAR AO MENU", game.go_menu))
	column.add_child(_paragraph("O novo reino também fica disponível no menu. Começar pelo menu inicia um herói de nível 1.", 12, MUTED))
