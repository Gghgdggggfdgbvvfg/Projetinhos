extends Control
## Four-world journey indicator; each numbered seal is a whole survival arena.

var game: FendaGame

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(172, 44)

func _draw() -> void:
	if game == null or game.worlds.is_empty():
		return
	var step: float = 42.0
	var start: float = (size.x - step * float(game.worlds.size() - 1)) * 0.5
	var center_y: float = 21.0
	draw_line(Vector2(start, center_y), Vector2(start + step * float(game.worlds.size() - 1), center_y), Color("b9aa7f"), 3)
	for index: int in range(game.worlds.size()):
		var point: Vector2 = Vector2(start + step * index, center_y)
		var current: bool = index == game.world_index
		var complete: bool = index < game.world_index
		var color: Color = Color("3b718a") if current else (Color("738b5c") if complete else Color("d6ccaa"))
		draw_rect(Rect2(point - Vector2(12, 12), Vector2(24, 24)), color)
		draw_rect(Rect2(point - Vector2(12, 12), Vector2(24, 24)), Color("b6984b"), false, 1)
		if current:
			draw_rect(Rect2(point - Vector2(15, 15), Vector2(30, 30)), Color("3b718a"), false, 1)
		var ink: Color = Color("fff5dd") if current or complete else Color("6b705f")
		draw_string(ThemeDB.fallback_font, point + Vector2(-4, 5), str(index + 1), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, ink)
