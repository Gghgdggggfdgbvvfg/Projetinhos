class_name WeaponData
extends Resource
## Configuration only; firing and projectile behaviour are shared by every weapon.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var icon: Texture2D
@export var damage: float = 18.0
@export var interval: float = 0.28
@export var projectile_speed: float = 720.0
@export var pellets: int = 1
@export var spread: float = 0.0
@export var reach: float = 780.0
@export var color: Color = Color("72ded0")
@export var sound_id: String = "shot"
