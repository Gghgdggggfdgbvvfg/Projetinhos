class_name EnemyData
extends Resource

@export var id: String = ""
@export var display_name: String = ""
@export_enum("chaser", "shooter", "charger", "tank", "boss") var kind: String = "chaser"
@export var hp: float = 50.0
@export var speed: float = 96.0
@export var damage: float = 10.0
@export var cost: int = 1
@export var color: Color = Color("df8579")
@export var radius: float = 16.0
