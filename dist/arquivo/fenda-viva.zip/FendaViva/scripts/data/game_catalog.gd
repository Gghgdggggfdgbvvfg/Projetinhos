class_name GameCatalog
extends RefCounted
## Resources are read once and never mutated while a run is active.

const WEAPON_IDS: Array[String] = ["agulha", "estilha", "pulso"]
const ENEMY_IDS: Array[String] = ["rastejante", "vigia", "ariete", "bastiao", "coracao"]
const UPGRADE_IDS: Array[String] = [
	"damage", "haste", "vitality", "heal", "speed", "dash", "multishot", "pierce",
	"critical", "poison", "explosion", "shield",
]

var _weapons: Array[WeaponData] = []
var _enemies: Array[EnemyData] = []
var _upgrades: Array[UpgradeData] = []
var _items: Dictionary = {}

func _init() -> void:
	for id: String in WEAPON_IDS:
		_weapons.append(load("res://resources/weapons/%s.tres" % id) as WeaponData)
	for id: String in ENEMY_IDS:
		_enemies.append(load("res://resources/enemies/%s.tres" % id) as EnemyData)
	for id: String in UPGRADE_IDS:
		_upgrades.append(load("res://resources/upgrades/%s.tres" % id) as UpgradeData)
	for id: String in ["recovery", "reward"]:
		_items[id] = load("res://resources/items/%s.tres" % id) as ItemData

func weapons() -> Array[WeaponData]:
	return _weapons.duplicate()

func enemies() -> Array[EnemyData]:
	return _enemies.duplicate()

func upgrades() -> Array[UpgradeData]:
	return _upgrades.duplicate()

func enemy(id: String) -> EnemyData:
	for definition: EnemyData in _enemies:
		if definition.id == id or definition.kind == id:
			return definition
	return null

func upgrade(id: String) -> UpgradeData:
	for definition: UpgradeData in _upgrades:
		if definition.id == id:
			return definition
	return null

func item(id: String) -> ItemData:
	return _items.get(id) as ItemData

static func base_stats() -> Dictionary:
	return {
		"damage_mult": 1.0, "rate_mult": 1.0, "max_hp": 100.0,
		"move_mult": 1.0, "dash_mult": 1.0, "extra_projectiles": 0.0,
		"pierce": 0.0, "crit_chance": 0.0, "poison": 0.0,
		"explosion": 0.0, "shield": 0.0,
	}

func derive_stats(stacks: Dictionary) -> Dictionary:
	var result: Dictionary = base_stats()
	var additive: Dictionary = {}
	var multiplicative: Dictionary = {}
	for definition: UpgradeData in _upgrades:
		var amount: int = clampi(int(stacks.get(definition.id, 0)), 0, definition.max_stacks)
		if amount == 0 or definition.operation == "heal":
			continue
		if definition.operation == "add":
			additive[definition.stat] = float(additive.get(definition.stat, 0.0)) + definition.value * amount
		elif definition.operation == "multiply":
			multiplicative[definition.stat] = float(multiplicative.get(definition.stat, 1.0)) * pow(definition.value, amount)
	for key: String in result:
		result[key] = (float(result[key]) + float(additive.get(key, 0.0))) * float(multiplicative.get(key, 1.0))
	result["crit_chance"] = clampf(float(result["crit_chance"]), 0.0, 0.75)
	return result

func offer(stacks: Dictionary, rng: RandomNumberGenerator, count: int = 3) -> Array[UpgradeData]:
	var candidates: Array[UpgradeData] = []
	for definition: UpgradeData in _upgrades:
		if definition.operation != "heal" and int(stacks.get(definition.id, 0)) >= definition.max_stacks:
			continue
		var eligible: bool = true
		for required: String in definition.requires:
			if int(stacks.get(required, 0)) == 0:
				eligible = false
		if eligible:
			candidates.append(definition)
	var result: Array[UpgradeData] = []
	# Weighted sampling without replacement. A consumed healing item does not add a stack.
	while not candidates.is_empty() and result.size() < count:
		var total: float = 0.0
		for definition: UpgradeData in candidates:
			total += _rarity_weight(definition.rarity)
		var roll: float = rng.randf_range(0.0, total)
		var selected: int = candidates.size() - 1
		for index: int in candidates.size():
			roll -= _rarity_weight(candidates[index].rarity)
			if roll <= 0.0:
				selected = index
				break
		result.append(candidates[selected])
		candidates.remove_at(selected)
	return result

static func _rarity_weight(rarity: String) -> float:
	match rarity:
		"raro": return 0.72
		"épico": return 0.42
		_: return 1.0
