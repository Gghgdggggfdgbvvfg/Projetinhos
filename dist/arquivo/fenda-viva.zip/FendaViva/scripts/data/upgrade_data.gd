class_name UpgradeData
extends Resource
## Stat calculation applies additive values before multiplicative factors.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export_enum("comum", "raro", "épico") var rarity: String = "comum"
@export var icon: Texture2D
@export var max_stacks: int = 3
@export var stat: String = "damage_mult"
@export_enum("add", "multiply", "heal") var operation: String = "multiply"
@export var value: float = 1.15
@export var requires: Array[String] = []
