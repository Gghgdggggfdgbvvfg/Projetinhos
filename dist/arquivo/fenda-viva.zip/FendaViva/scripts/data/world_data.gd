class_name WorldData
extends Resource
## Presentation and pacing for a world; the seed belongs to the run.

@export var id: String = ""
@export var display_name: String = ""
@export var subtitle: String = ""
@export_multiline var description: String = ""
@export var duration: float = 150.0
@export_range(0, 3) var kind: int = 0
@export var seed_offset: int = 0
@export var floor_color: Color = Color("79a24a")
@export var accent_color: Color = Color("e9c767")
@export var enemy_tint: Color = Color.WHITE
@export var boss_name: String = "Guardião"
