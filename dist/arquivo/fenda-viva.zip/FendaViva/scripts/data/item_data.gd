class_name ItemData
extends Resource
## A room interactable is a data-defined pickup, consumed once per run.

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var icon: Texture2D
@export_enum("recovery", "reward") var kind: String = "recovery"
@export var amount: float = 35.0
@export var color: Color = Color("72ded0")
