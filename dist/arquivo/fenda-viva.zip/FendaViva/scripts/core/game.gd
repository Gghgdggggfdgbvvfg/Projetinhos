class_name FendaGame
extends Node2D
signal state_changed(state: String)
signal room_changed
signal world_changed
signal level_changed
signal run_ended(won: bool)

var state: String = "menu"
var player: FendaPlayer
var room: SurvivalArena
var hud: GameHUD
var worlds: Array[WorldData] = WorldCatalog.all()
var world_index: int = 0
var world_time: float = 0.0
var worlds_cleared: int = 0
var unlocked_world: int = 0
var player_level: int = 1
var experience: int = 0
var experience_needed: int = 20
var pending_levels: int = 0
var boss_spawned: bool = false
var boss_defeated: bool = false
var world_end_pending: bool = false
var world_recorded: bool = false
var active_weapons: Array[String] = ["agulha"]
var enemies: Array[FendaEnemy] = []
var director: HordeDirector
var seed_value: int = 0
var rng := RandomNumberGenerator.new()
var visual_rng := RandomNumberGenerator.new()
var run_time: float = 0.0
var kills: int = 0
var upgrades_taken: Array[String] = []
var catalog := GameCatalog.new()
var stats: Dictionary = {}
var stacks: Dictionary = {}
var settings: Dictionary = {"shake":0.4, "reduced_flashes":false, "master":0.75, "music":0.42, "effects":0.75, "ui":0.6, "fullscreen":false}
var audio: AudioDirector
var camera: Camera2D
var shake_strength: float = 0.0
var offered: Array[UpgradeData] = []
var pickup_clock: float = 0.0
var last_text_time: int = 0

func _ready() -> void:
	get_tree().auto_accept_quit = false
	visual_rng.randomize()
	stats = GameCatalog.base_stats()
	_load_settings()
	_load_progress()
	audio = AudioDirector.new()
	add_child(audio)
	audio.set_volumes(settings)
	camera = Camera2D.new()
	camera.position = Vector2(640,400)
	camera.position_smoothing_enabled = false
	add_child(camera)
	director = HordeDirector.new(self)
	hud = GameHUD.new()
	add_child(hud)
	hud.setup(self)
	hud.show_menu()
	print("Fenda Viva: Crônicas dos Reinos | Godot ", Engine.get_version_info().string)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST and is_inside_tree():
		_quit_game()

func _quit_game() -> void:
	if state == "closing": return
	state = "closing"
	audio.stop_all()
	await get_tree().create_timer(0.2, true, false, true).timeout
	get_tree().quit()

func _process(delta: float) -> void:
	if state == "active":
		run_time += delta
		world_time += delta
		director.update(delta)
		pickup_clock -= delta
		if pickup_clock <= 0.0:
			pickup_clock = 1.0
			_consolidate_pickups()
	if is_instance_valid(player) and is_instance_valid(room):
		var half := get_viewport_rect().size * 0.5 / camera.zoom
		var camera_target := player.position
		camera_target.x = clampf(camera_target.x, room.bounds.position.x + half.x, room.bounds.end.x - half.x)
		camera_target.y = clampf(camera_target.y, room.bounds.position.y + half.y, room.bounds.end.y - half.y)
		camera.position = camera_target
	shake_strength = move_toward(shake_strength, 0.0, delta * 22.0)
	if is_instance_valid(camera):
		camera.offset = Vector2(visual_rng.randf_range(-1,1),visual_rng.randf_range(-1,1)) * shake_strength * float(settings.shake) if state == "active" else Vector2.ZERO

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		toggle_pause()
		get_viewport().set_input_as_handled()

func _set_state(next: String) -> void:
	state = next
	state_changed.emit(state)
	if is_instance_valid(hud): hud.refresh()

func world_data() -> WorldData:
	return worlds[clampi(world_index,0,worlds.size()-1)]

func start_run(seed_override: int = -1, starting_world: int = 0) -> void:
	_set_state("loading")
	_clear_run_nodes()
	stacks.clear()
	upgrades_taken.clear()
	offered.clear()
	stats = GameCatalog.base_stats()
	active_weapons = ["agulha"]
	player_level = 1
	experience = 0
	experience_needed = xp_requirement(1)
	pending_levels = 0
	worlds_cleared = 0
	seed_value = seed_override if seed_override >= 0 else int(Time.get_unix_time_from_system()*1000.0) % 2147483647
	rng.seed = seed_value ^ 0x6F3A28B
	run_time = 0.0
	kills = 0
	player = FendaPlayer.new()
	add_child(player)
	player.setup(self)
	player.died.connect(func(): _finish_run(false))
	_load_world(clampi(starting_world,0,unlocked_world))
	print("SURVIVAL seed=",seed_value," world=",world_index)

func _clear_run_nodes() -> void:
	if director: director.reset()
	enemies.clear()
	if is_instance_valid(room):
		remove_child(room)
		room.queue_free()
		room = null
	if is_instance_valid(player):
		remove_child(player)
		player.queue_free()
		player = null

func _load_world(index: int) -> void:
	_set_state("loading")
	director.reset()
	enemies.clear()
	if is_instance_valid(room):
		remove_child(room)
		room.queue_free()
	world_index = clampi(index,0,worlds.size()-1)
	world_time = 0.0
	boss_spawned = false
	boss_defeated = false
	world_end_pending = false
	world_recorded = false
	room = SurvivalArena.new()
	add_child(room)
	room.setup(self,world_data(),seed_value)
	player.reset_position(room.spawn_position)
	player.invulnerability = 1.5
	camera.position = player.position
	_set_state("active")
	world_changed.emit()
	room_changed.emit()
	play_sound("door")

func spawn_enemy(definition: EnemyData, point: Vector2, guardian: bool = false) -> FendaEnemy:
	if state != "active" or not is_instance_valid(room): return null
	var configured: EnemyData = definition.duplicate() as EnemyData
	configured.hp *= 1.0 + world_index * 0.22
	configured.damage *= 1.0 + world_index * 0.10
	configured.speed *= 1.0 + world_index * 0.045
	if guardian:
		configured.display_name = world_data().boss_name
		boss_spawned = true
	var enemy := FendaEnemy.new()
	room.add_child(enemy)
	enemy.position = point
	enemy.setup(self,configured,world_index + 1)
	enemies.append(enemy)
	return enemy

func nearest_enemy(pos: Vector2, max_range: float = 850.0) -> FendaEnemy:
	var nearest: FendaEnemy
	var best := max_range * max_range
	for enemy in enemies:
		if not is_instance_valid(enemy) or enemy.dead: continue
		var distance := pos.distance_squared_to(enemy.global_position)
		if distance < best and can_see(pos,enemy.global_position):
			best = distance
			nearest = enemy
	return nearest

func can_see(from: Vector2, to: Vector2) -> bool:
	if not is_instance_valid(player): return false
	var query := PhysicsRayQueryParameters2D.create(from,to,1)
	return player.get_world_2d().direct_space_state.intersect_ray(query).is_empty()

func enemy_defeated(enemy: FendaEnemy) -> void:
	if state != "active": return
	enemies.erase(enemy)
	kills += 1
	play_sound("kill")
	if enemy.is_boss:
		boss_defeated = true
		world_end_pending = true
		_drop_pickup(enemy.position,60 + world_index * 20,"xp")
	else:
		_drop_pickup(enemy.position,4 + enemy.data.cost * 2,"xp")
		if rng.randf() < 0.035:
			_drop_pickup(enemy.position + Vector2(13,0),10,"heal")
	if float(stats.explosion) > 0.0 and enemy.last_hit != null and enemy.last_hit.explosion_chain == 0:
		var blast := DamageData.new()
		blast.amount = float(stats.explosion) * (enemy.last_hit.critical_multiplier if enemy.last_hit.critical else 1.0)
		blast.origin = enemy.global_position
		blast.team = 1
		blast.source = player
		blast.knockback = 150.0
		blast.explosion_chain = 1
		burst(enemy.global_position,Color("f1bf61"),12)
		CombatHitbox.strike(get_tree(),enemy.global_position,100.0,blast)
	if enemy.is_boss: call_deferred("complete_world")

func _drop_pickup(point: Vector2, amount: int, kind: String) -> void:
	var pickup := ExperiencePickup.new()
	pickup.game = self
	pickup.position = point
	pickup.value = amount
	pickup.kind = kind
	room.add_child(pickup)

func _consolidate_pickups() -> void:
	# Cap loose gems without throwing experience away. Distant groups coalesce.
	var pickups := get_tree().get_nodes_in_group("pickups")
	if pickups.size() <= 180: return
	var stored: Dictionary = {}
	for node in pickups:
		var pickup := node as ExperiencePickup
		if not pickup or pickup.kind != "xp" or pickup.consumed or pickup.attracted: continue
		var cell := Vector2i(floori(pickup.position.x/160.0),floori(pickup.position.y/160.0))
		if stored.has(cell):
			var into: ExperiencePickup = stored[cell]
			into.value += pickup.value
			into.queue_redraw()
			pickup.consumed = true
			pickup.queue_free()
		else: stored[cell] = pickup

func collect_pickups_near(pos: Vector2, radius: float) -> void:
	for node in get_tree().get_nodes_in_group("pickups"):
		if node is ExperiencePickup and node.position.distance_squared_to(pos) <= radius*radius:
			node.attracted = true

static func xp_requirement(level: int) -> int:
	return 12 + level * 6 + level * level * 2

func add_experience(amount: int) -> void:
	if amount <= 0 or state in ["menu","defeat","victory","closing"]: return
	experience += amount
	while experience >= experience_needed:
		experience -= experience_needed
		player_level += 1
		pending_levels += 1
		experience_needed = xp_requirement(player_level)
		if player_level == 4: add_weapon("estilha")
		if player_level == 7: add_weapon("pulso")
	level_changed.emit()
	call_deferred("_handle_levelups")

func add_weapon(id: String) -> void:
	if active_weapons.has(id): return
	active_weapons.append(id)
	for weapon in catalog.weapons():
		if weapon.id == id:
			float_text(player.position + Vector2(0,-60),"NOVA ARMA: " + weapon.display_name,Color("e8b24a"))
	play_sound("collect")

func _handle_levelups() -> void:
	if state != "active" or world_end_pending: return
	if pending_levels > 0: _offer_upgrade()

func _offer_upgrade() -> void:
	offered = catalog.offer(stacks,rng,3)
	_set_state("upgrade")
	hud.show_upgrade(offered)
	play_sound("collect")

func choose_upgrade(id: String) -> void:
	if state != "upgrade": return
	var chosen: UpgradeData
	for option in offered:
		if option.id == id: chosen = option
	if chosen == null: return
	if chosen.operation == "heal": player.heal(chosen.value)
	else:
		stacks[id] = int(stacks.get(id,0)) + 1
		stats = catalog.derive_stats(stacks)
		player.refresh_stats()
	upgrades_taken.append(chosen.id)
	offered.clear()
	pending_levels = maxi(0,pending_levels - 1)
	play_sound("collect")
	if pending_levels > 0:
		_offer_upgrade()
	elif world_end_pending:
		_show_world_result()
	else:
		player.invulnerability = maxf(player.invulnerability,0.3)
		_set_state("active")

func complete_world() -> void:
	if not boss_defeated or world_recorded or state in ["paused","upgrade","defeat","victory"]: return
	world_recorded = true
	world_end_pending = true
	worlds_cleared += 1
	state = "loading"
	director.reset()
	for enemy in enemies:
		if is_instance_valid(enemy):
			enemy.dead = true
			enemy.queue_free()
	enemies.clear()
	for node in get_tree().get_nodes_in_group("projectiles"): node.queue_free()
	for node in get_tree().get_nodes_in_group("pickups"):
		if node is ExperiencePickup: node.collect()
	if world_index < worlds.size()-1:
		unlocked_world = maxi(unlocked_world,world_index+1)
		_save_progress()
	player.heal(player.max_hp * 0.4)
	if pending_levels > 0: _offer_upgrade()
	else: _show_world_result()

func _show_world_result() -> void:
	if world_index >= worlds.size()-1:
		_finish_run(true)
	else:
		_set_state("world_complete")
		hud.show_world_complete()
		play_sound("victory")

func advance_world() -> void:
	if state == "world_complete" and world_index + 1 < worlds.size():
		_load_world(world_index+1)

func toggle_pause() -> void:
	if state == "active": _set_state("paused")
	elif state == "paused": resume_run()

func resume_run() -> void:
	if state != "paused": return
	_set_state("active")
	if world_end_pending: call_deferred("complete_world")
	else: call_deferred("_handle_levelups")

func go_menu() -> void:
	_set_state("menu")
	_clear_run_nodes()
	hud.show_menu()

func _finish_run(won: bool) -> void:
	if state in ["defeat","victory","menu"]: return
	director.reset()
	for projectile in get_tree().get_nodes_in_group("projectiles"): projectile.queue_free()
	_set_state("victory" if won else "defeat")
	play_sound("victory" if won else "defeat")
	hud.show_end(won)
	run_ended.emit(won)

func _load_progress() -> void:
	var config := ConfigFile.new()
	if config.load("user://kingdoms.cfg") == OK:
		unlocked_world = clampi(int(config.get_value("progress","unlocked_world",0)),0,worlds.size()-1)

func _save_progress() -> void:
	var config := ConfigFile.new()
	config.set_value("progress","unlocked_world",unlocked_world)
	config.save("user://kingdoms.cfg")

func shoot(origin: Vector2, direction: Vector2, weapon: WeaponData, team: int, source: Node) -> void:
	if state != "active":
		return
	var count := weapon.pellets + (int(stats.extra_projectiles) if team == 1 else 0)
	for i in range(count):
		var offset: float = rng.randf_range(-weapon.spread * 0.5, weapon.spread * 0.5) if count == 1 else (float(i) / maxf(count - 1, 1) - 0.5) * maxf(weapon.spread, 0.18)
		var critical := rng.randf() < float(stats.crit_chance) if team == 1 else false
		var damage := weapon.damage * (float(stats.damage_mult) if team == 1 else 1.0) * (1.75 if critical else 1.0)
		spawn_projectile(origin, direction.rotated(offset), damage, weapon.projectile_speed, team, source, {"color":weapon.color, "reach":weapon.reach, "pierce":int(stats.pierce) if team == 1 else 0, "poison":float(stats.poison) if team == 1 else 0.0, "critical":critical, "critical_chance":float(stats.crit_chance) if team == 1 else 0.0, "knockback":55.0})

func spawn_projectile(origin: Vector2, direction: Vector2, damage: float, speed: float, team: int, source: Node, options: Dictionary = {}) -> void:
	if state != "active" or not is_instance_valid(room):
		return
	# Hard cap is a safeguard, not a gameplay target.
	if get_tree().get_nodes_in_group("projectiles").size() >= 260:
		return
	var projectile := FendaProjectile.new()
	projectile.game = self
	projectile.hit = DamageData.new()
	projectile.hit.amount = damage
	projectile.hit.origin = origin
	projectile.hit.direction = direction.normalized()
	projectile.hit.team = team
	projectile.hit.source = source
	projectile.hit.knockback = float(options.get("knockback", 95.0))
	projectile.hit.poison = float(options.get("poison", 0.0))
	projectile.hit.critical = bool(options.get("critical", false))
	projectile.hit.critical_chance = float(options.get("critical_chance", 0.0))
	projectile.hit.critical_multiplier = float(options.get("critical_multiplier", 1.75))
	projectile.hit.explosion_chain = int(options.get("explosion_chain", 0))
	projectile.position = origin
	projectile.direction = direction.normalized()
	projectile.speed = speed
	projectile.remaining = float(options.get("lifetime", 3.5))
	projectile.distance_left = float(options.get("reach", speed * projectile.remaining))
	projectile.pierces = int(options.get("pierce", 0))
	projectile.tint = options.get("color", Color("63ddbd") if team == 1 else Color("ff8d79"))
	room.add_child(projectile)

func burst(pos: Vector2, color: Color, amount: int = 10) -> void:
	if not is_instance_valid(room) or room.get_child_count() > 420:
		return
	var spark := FendaSpark.new()
	spark.game = self
	spark.position = pos
	spark.tint = color
	spark.count = mini(amount, 8) if bool(settings.reduced_flashes) else amount
	room.add_child(spark)

func float_text(pos: Vector2, label: String, color: Color) -> void:
	# Coalesce dense damage numbers; narrative and unlock notices always remain visible.
	if label.length() < 6:
		var now := Time.get_ticks_msec()
		if now - last_text_time < 45: return
		last_text_time = now
	if not is_instance_valid(room):
		return
	var spark := FendaSpark.new()
	spark.game = self
	spark.position = pos
	spark.tint = color
	spark.label = label
	spark.count = 0
	spark.lifetime = 0.85
	room.add_child(spark)

func play_sound(id: String) -> void:
	if is_instance_valid(audio):
		audio.play(id)

func shake(amount: float) -> void:
	shake_strength = maxf(shake_strength, minf(amount, 9.0))

func set_setting(key: String, value: Variant) -> void:
	if not settings.has(key):
		return
	settings[key] = value
	if key == "fullscreen":
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if bool(value) else DisplayServer.WINDOW_MODE_WINDOWED)
	audio.set_volumes(settings)
	var config := ConfigFile.new()
	for setting in settings:
		config.set_value("accessibility", setting, settings[setting])
	config.save("user://settings.cfg")

func _load_settings() -> void:
	var config := ConfigFile.new()
	if config.load("user://settings.cfg") == OK:
		for key in settings:
			settings[key] = config.get_value("accessibility", key, settings[key])
	if bool(settings.fullscreen):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
