class_name AudioDirector
extends Node
var streams: Dictionary = {}
var voices: Array[AudioStreamPlayer] = []
var music: AudioStreamPlayer
var voice_index: int = 0
var last_played: Dictionary = {}

func _ready() -> void:
	for id in ["needle", "scatter", "pulse", "impact", "hurt", "dash", "kill", "collect", "door", "ui", "victory", "defeat", "shield"]:
		var path := "res://assets/audio/%s.wav" % id
		if ResourceLoader.exists(path):
			streams[id] = load(path)
	for i in range(20):
		var voice := AudioStreamPlayer.new()
		voice.bus = &"Efeitos"
		add_child(voice)
		voices.append(voice)
	if ResourceLoader.exists("res://assets/audio/fortress.wav"):
		music = AudioStreamPlayer.new()
		var ambient: AudioStreamWAV = load("res://assets/audio/fortress.wav")
		ambient.loop_mode = AudioStreamWAV.LOOP_FORWARD
		ambient.loop_begin = 0
		ambient.loop_end = int(ambient.get_length() * ambient.mix_rate)
		music.stream = ambient
		music.bus = &"Música"
		add_child(music)
		music.play()

func play(id: String) -> void:
	var aliases := {"agulha":"needle", "estilha":"scatter", "pulso":"pulse", "rapid":"pulse", "shoot":"needle", "shot":"needle", "shot_scatter":"scatter", "shot_fast":"pulse", "enemy_shoot":"pulse", "enemy_shot":"pulse", "enemy_death":"kill", "hit":"impact", "death":"kill", "pickup":"collect"}
	id = str(aliases.get(id, id))
	if not streams.has(id) or voices.is_empty():
		return
	var now := Time.get_ticks_msec()
	if now - int(last_played.get(id, -1000)) < (65 if id == "impact" else 35):
		return
	last_played[id] = now
	var voice := voices[voice_index % voices.size()]
	voice_index += 1
	voice.stream = streams[id]
	voice.bus = &"Interface" if id in ["ui", "victory", "defeat"] else &"Efeitos"
	voice.volume_db = -5.0 if id == "pulse" else 0.0
	voice.play()

func set_volumes(settings: Dictionary) -> void:
	for mapping in [["master", "Master"], ["music", "Música"], ["effects", "Efeitos"], ["ui", "Interface"]]:
		var index := AudioServer.get_bus_index(mapping[1])
		if index >= 0:
			var volume := clampf(float(settings.get(mapping[0], 0.8)), 0.0, 1.0)
			AudioServer.set_bus_volume_db(index, linear_to_db(maxf(volume, 0.0001)))
			AudioServer.set_bus_mute(index, volume <= 0.001)

func stop_all() -> void:
	# Release the looping playback before AudioServer shuts down (also in headless runs).
	if is_instance_valid(music):
		music.stop()
		music.stream = null
	for voice in voices:
		if is_instance_valid(voice):
			voice.stop()
			voice.stream = null
	streams.clear()

func _exit_tree() -> void:
	stop_all()
