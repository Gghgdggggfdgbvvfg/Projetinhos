class_name Vitality
extends Node
signal changed(current: float, maximum: float)
signal depleted
var maximum: float = 100.0
var current: float = 100.0

func configure(amount: float) -> void:
	maximum = maxf(amount, 1.0)
	current = maximum
	changed.emit(current, maximum)

func damage(amount: float) -> void:
	if current <= 0.0 or amount <= 0.0:
		return
	current = maxf(0.0, current - amount)
	changed.emit(current, maximum)
	if current <= 0.0:
		depleted.emit()

func heal(amount: float) -> void:
	if current <= 0.0:
		return
	current = minf(maximum, current + maxf(amount, 0.0))
	changed.emit(current, maximum)
