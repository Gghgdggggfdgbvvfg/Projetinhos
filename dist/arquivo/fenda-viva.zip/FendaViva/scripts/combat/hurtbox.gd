class_name Hurtbox
extends Area2D
var target: Node
var team: int = 1

func setup(owner_node: Node, faction: int, radius: float) -> void:
	target = owner_node
	team = faction
	collision_layer = 8 if faction == 1 else 16
	collision_mask = 0
	monitoring = false
	monitorable = true
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = radius
	shape.shape = circle
	add_child(shape)

func receive_hit(hit: DamageData) -> void:
	if hit.team == team or not is_instance_valid(target) or target == hit.source:
		return
	if target.has_method("receive_hit"):
		target.receive_hit(hit)
