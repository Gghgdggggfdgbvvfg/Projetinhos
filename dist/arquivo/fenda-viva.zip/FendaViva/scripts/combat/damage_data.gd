class_name DamageData
extends RefCounted
## Immutable-per-hit attack envelope. Teams: 1 explorer, 2 fortress.
var amount: float = 10.0
var origin: Vector2 = Vector2.ZERO
var direction: Vector2 = Vector2.RIGHT
var knockback: float = 100.0
var team: int = 1
var source: Node
var critical: bool = false
var critical_chance: float = 0.0
var critical_multiplier: float = 1.75
var poison: float = 0.0
var explosion_chain: int = 0

func copy() -> DamageData:
	var hit := DamageData.new()
	hit.amount = amount
	hit.origin = origin
	hit.direction = direction
	hit.knockback = knockback
	hit.team = team
	# Enemy arrows may outlive their emitter; keep the hit valid after its death.
	hit.source = source if is_instance_valid(source) else null
	hit.critical = critical
	hit.critical_chance = critical_chance
	hit.critical_multiplier = critical_multiplier
	hit.poison = poison
	hit.explosion_chain = explosion_chain
	return hit
