class_name CombatHitbox
extends RefCounted
## One query per attack pulse; unique recipients avoid multi-shape double hits.
static func strike(tree: SceneTree, center: Vector2, radius: float, hit: DamageData) -> int:
	var actor: Node2D = tree.get_first_node_in_group("player") as Node2D
	if not is_instance_valid(actor):
		return 0
	var shape := CircleShape2D.new()
	shape.radius = radius
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0.0, center)
	query.collision_mask = 16 if hit.team == 1 else 8
	query.collide_with_areas = true
	query.collide_with_bodies = false
	var results := actor.get_world_2d().direct_space_state.intersect_shape(query, 64)
	var recipients: Array[Node] = []
	for result in results:
		var box := result.collider as Hurtbox
		if box and is_instance_valid(box.target) and not recipients.has(box.target):
			recipients.append(box.target)
			var individual := hit.copy()
			individual.direction = (box.global_position - center).normalized()
			box.receive_hit(individual)
	return recipients.size()
