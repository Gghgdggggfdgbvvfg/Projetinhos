class_name FendaProjectile
extends Node2D
var game: FendaGame
var hit: DamageData
var direction: Vector2 = Vector2.RIGHT
var speed: float = 700.0
var remaining: float = 1.1
var pierces: int = 0
var tint: Color = Color("5be6c2")
var trail: Array[Vector2] = []
var excluded: Array[RID] = []
var spent: bool = false
var distance_left: float = 800.0

func _ready() -> void:
	z_index = 15
	add_to_group("projectiles")
	if is_instance_valid(hit.source) and hit.source is CollisionObject2D:
		excluded.append(hit.source.get_rid())
	queue_redraw()

func _physics_process(delta: float) -> void:
	if spent or game.state != "active":
		return
	remaining -= delta
	if remaining <= 0.0 or distance_left <= 0.0:
		queue_free()
		return
	var start := global_position
	var step_length := minf(speed * delta, distance_left)
	var finish := start + direction * step_length
	var query := PhysicsRayQueryParameters2D.create(start, finish, 17 if hit.team == 1 else 9, excluded)
	query.collide_with_areas = true
	query.collide_with_bodies = true
	query.hit_from_inside = true
	# Ray sweep prevents tunneling; piercing continues inside this frame, with a hard cap.
	for _iteration in range(8):
		var collision := get_world_2d().direct_space_state.intersect_ray(query)
		if collision.is_empty():
			break
		var box := collision.collider as Hurtbox
		var impact: Vector2 = collision.position
		game.burst(impact, tint, 4)
		if box:
			box.receive_hit(hit.copy())
			if pierces > 0:
				pierces -= 1
				excluded.append(box.get_rid())
				query.exclude = excluded
				query.from = impact + direction * 0.5
				continue
		spent = true
		global_position = impact
		queue_free()
		return
	global_position = finish
	distance_left -= step_length
	queue_redraw()

func _draw() -> void:
	var tail := -direction * (18.0 if hit.team == 1 else 10.0)
	draw_line(tail, Vector2.ZERO, Color(tint, 0.25), 7.0, true)
	if hit.team == 1:
		draw_line(tail * 0.65, direction * 3.0, tint, 3.0, true)
		draw_circle(Vector2.ZERO, 2.2, Color("edfff5"))
	else:
		draw_circle(Vector2.ZERO, 5.5, Color("2c1823"))
		draw_arc(Vector2.ZERO, 5.5, 0.0, TAU, 12, tint, 2.0, true)
		draw_circle(Vector2.ZERO, 2.0, Color("ffd3a2"))
