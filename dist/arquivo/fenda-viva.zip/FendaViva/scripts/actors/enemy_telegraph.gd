class_name EnemyTelegraph
extends Node2D
## World-space attack geometry. It stays fixed after an enemy commits to an attack.

var kind: String = ""
var origin: Vector2 = Vector2.ZERO
var direction: Vector2 = Vector2.RIGHT
var distance: float = 300.0
var radius: float = 48.0
var spread: float = 0.65
var targets: Array[Vector2] = []
var progress: float = 0.0
var striking: bool = false
var tint: Color = Color("ee8877")

func _ready() -> void:
	z_as_relative = false
	z_index = 3

func clear() -> void:
	kind = ""
	targets.clear()
	queue_redraw()

func _draw() -> void:
	if kind.is_empty():
		return
	var fill: Color = Color(tint, 0.10 + progress * 0.12)
	var edge: Color = Color(tint, 0.68 + progress * 0.30)
	if striking:
		fill.a = 0.25
		edge = Color("ffe5bb")
	if kind == "circle":
		for target: Vector2 in targets:
			var center: Vector2 = to_local(target)
			draw_circle(center, radius, fill)
			draw_arc(center, radius, 0.0, TAU, 56, edge, 2.0, true)
			draw_arc(center, radius * clampf(progress, 0.04, 1.0), 0.0, TAU, 44, Color(tint, 0.45), 1.5, true)
			for index: int in range(8):
				var ray: Vector2 = Vector2.from_angle(index * TAU / 8.0)
				draw_line(center + ray * (radius - 8.0), center + ray * (radius + 4.0), edge, 2.0, true)
			draw_line(center + Vector2(-6, -6), center + Vector2(6, 6), edge, 2.0, true)
			draw_line(center + Vector2(-6, 6), center + Vector2(6, -6), edge, 2.0, true)
	elif kind == "charge":
		var side: Vector2 = direction.orthogonal() * radius
		var finish: Vector2 = origin + direction * distance
		var polygon := PackedVector2Array([to_local(origin - side), to_local(finish - side), to_local(finish + side), to_local(origin + side)])
		draw_colored_polygon(polygon, fill)
		draw_line(to_local(origin - side), to_local(finish - side), edge, 2.0, true)
		draw_line(to_local(origin + side), to_local(finish + side), edge, 2.0, true)
		for index: int in range(1, int(distance / 44.0)):
			var tip: Vector2 = origin + direction * index * 44.0
			draw_polyline(PackedVector2Array([to_local(tip - direction * 11.0 - side * 0.35), to_local(tip), to_local(tip - direction * 11.0 + side * 0.35)]), edge, 2.0, true)
	elif kind == "fan":
		var polygon := PackedVector2Array([to_local(origin)])
		for index: int in range(21):
			polygon.append(to_local(origin + direction.rotated(lerpf(-spread, spread, index / 20.0)) * distance))
		draw_colored_polygon(polygon, Color(tint, 0.06 + 0.06 * progress))
		for angle: float in [-spread, 0.0, spread]:
			draw_dashed_line(to_local(origin), to_local(origin + direction.rotated(angle) * distance), edge, 1.5, 11.0, true, true)
	else:
		var finish: Vector2 = origin + direction * distance
		draw_line(to_local(origin), to_local(finish), Color(tint, 0.12), 9.0, true)
		draw_dashed_line(to_local(origin), to_local(finish), edge, 2.0, 12.0, true, true)
		var tip: Vector2 = to_local(finish)
		draw_circle(tip, 4.0 + progress * 3.0, edge, false, 1.5, true)
