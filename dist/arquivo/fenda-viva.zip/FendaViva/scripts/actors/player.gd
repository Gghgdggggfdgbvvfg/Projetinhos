class_name FendaPlayer
extends CharacterBody2D
signal health_changed(current: float, maximum: float)
signal died

@export var base_speed: float = 265.0
@export var acceleration: float = 1900.0
@export var deceleration: float = 2400.0
@export var dash_speed: float = 770.0
@export var dash_time: float = 0.19
@export var dash_recharge: float = 1.15
@export var dash_invulnerability: float = 0.16
@export var damage_invulnerability: float = 0.8
var game: FendaGame
var vitality := Vitality.new()
var hp: float:
	get: return vitality.current
var max_hp: float:
	get: return vitality.maximum
var dash_cooldown: float = 0.0
var dash_duration_left: float = 0.0
var shield_ready: bool = false
var shield_timer: float = 0.0
var weapon_index: int = 0
var weapons: Array[WeaponData] = []
var aim_direction := Vector2.RIGHT
var last_direction := Vector2.DOWN
var dash_direction := Vector2.DOWN
var invulnerability: float = 0.0
var attack_cooldown: float = 0.3
var recoil: float = 0.0
var foot_phase: float = 0.0
var knockback_velocity := Vector2.ZERO
var dead: bool = false
var trail_clock: float = 0.0
var visual_state: String = "idle"
var weapon_timers: Dictionary = {}
var weapon_targets: Dictionary = {}
var target_refresh: float = 0.0
var current_target: FendaEnemy
var _sprite: Texture2D

func setup(owner_game: FendaGame) -> void:
	game = owner_game
	weapons = game.catalog.weapons()
	_sprite = PixelActor.texture("knight")
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(vitality)
	vitality.configure(float(game.stats.max_hp))
	vitality.changed.connect(func(current: float, maximum: float): health_changed.emit(current, maximum))
	vitality.depleted.connect(_die)
	var body_shape := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 12.0
	body_shape.shape = shape
	add_child(body_shape)
	var hurt := Hurtbox.new()
	hurt.setup(self, 1, 13.0)
	add_child(hurt)
	collision_layer = 2
	collision_mask = 1
	z_index = 10
	add_to_group("player")
	refresh_stats()

func _physics_process(delta: float) -> void:
	if not is_instance_valid(game) or game.state != "active" or dead:
		return
	dash_cooldown = maxf(0.0, dash_cooldown - delta)
	invulnerability = maxf(0.0, invulnerability - delta)
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	for id: String in weapon_timers.keys():
		weapon_timers[id] = maxf(0.0, float(weapon_timers[id]) - delta)
	target_refresh -= delta
	if target_refresh <= 0.0:
		target_refresh = 0.125
		_refresh_targets()
	recoil = move_toward(recoil, 0.0, delta * 26.0)
	if float(game.stats.shield) > 0.0 and not shield_ready:
		shield_timer = maxf(0.0, shield_timer - delta)
		if shield_timer <= 0.0:
			shield_ready = true
			game.burst(global_position, Color("96b9ff"), 10)
	var input_vector := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if input_vector.length_squared() > 0.01:
		last_direction = input_vector.normalized()
	if is_instance_valid(current_target) and not current_target.dead:
		aim_direction = global_position.direction_to(current_target.global_position)
	elif input_vector.length_squared() > 0.01:
		aim_direction = last_direction
	if Input.is_action_just_pressed("dash") and dash_cooldown <= 0.0 and dash_duration_left <= 0.0:
		dash_direction = input_vector.normalized() if input_vector.length_squared() > 0.01 else last_direction
		dash_duration_left = dash_time
		dash_cooldown = dash_recharge * float(game.stats.dash_mult)
		invulnerability = maxf(invulnerability, dash_invulnerability)
		game.play_sound("dash")
	if dash_duration_left > 0.0:
		dash_duration_left = maxf(0.0, dash_duration_left - delta)
		velocity = dash_direction * dash_speed
		visual_state = "dash"
		trail_clock -= delta
		if trail_clock <= 0.0:
			trail_clock = 0.045
			game.burst(global_position, Color("4ca88e"), 3)
	else:
		var desired := input_vector * base_speed * float(game.stats.move_mult)
		velocity = velocity.move_toward(desired, (acceleration if input_vector != Vector2.ZERO else deceleration) * delta)
		visual_state = "moving" if velocity.length_squared() > 100.0 else "idle"
		_auto_fire()
	knockback_velocity = knockback_velocity.move_toward(Vector2.ZERO, 900.0 * delta)
	velocity += knockback_velocity
	move_and_slide()
	velocity -= knockback_velocity
	foot_phase += delta * velocity.length() * 0.05
	queue_redraw()

func _refresh_targets() -> void:
	current_target = null
	for weapon: WeaponData in weapons:
		if weapon.id not in game.active_weapons:
			continue
		var target: FendaEnemy = game.nearest_enemy(global_position, weapon.reach)
		weapon_targets[weapon.id] = target
		if not is_instance_valid(current_target) and is_instance_valid(target):
			current_target = target

func _auto_fire() -> void:
	for weapon: WeaponData in weapons:
		if weapon.id not in game.active_weapons:
			continue
		if float(weapon_timers.get(weapon.id, 0.0)) > 0.0:
			continue
		if weapon.id == get_weapon().id and attack_cooldown > 0.0:
			continue
		var cached_target: Variant = weapon_targets.get(weapon.id)
		if not is_instance_valid(cached_target):
			target_refresh = 0.0
			continue
		var target: FendaEnemy = cached_target
		if target.dead:
			target_refresh = 0.0
			continue
		if global_position.distance_squared_to(target.global_position) > weapon.reach * weapon.reach:
			target_refresh = 0.0
			continue
		if not game.can_see(global_position, target.global_position):
			target_refresh = 0.0
			continue
		_fire(weapon, target)

func _fire(weapon: WeaponData = null, target: FendaEnemy = null) -> void:
	if weapon == null:
		weapon = get_weapon()
	var direction: Vector2 = aim_direction
	if is_instance_valid(target):
		direction = global_position.direction_to(target.global_position)
	weapon_timers[weapon.id] = weapon.interval / maxf(0.1, float(game.stats.rate_mult))
	if weapon.id == get_weapon().id:
		attack_cooldown = float(weapon_timers[weapon.id])
		aim_direction = direction
	recoil = 4.5
	# Every acquired weapon keeps its own cadence, including while moving.
	game.shoot(global_position, direction, weapon, 1, self)
	game.play_sound(weapon.sound_id)

func get_weapon() -> WeaponData:
	return weapons[weapon_index]

func switch_weapon() -> void:
	# Retained for old callers: automatic weapons no longer require cycling.
	pass

func receive_hit(hit: DamageData) -> void:
	if dead or game.state != "active" or invulnerability > 0.0 or hit.team == 1:
		return
	if shield_ready:
		shield_ready = false
		shield_timer = 12.0
		invulnerability = 0.3
		game.burst(global_position, Color("96b9ff"), 12)
		game.float_text(global_position, "BLOQUEADO", Color("96b9ff"))
		game.play_sound("shield")
		return
	invulnerability = damage_invulnerability
	knockback_velocity = hit.direction.normalized() * hit.knockback
	visual_state = "hurt"
	game.shake(5.0)
	game.burst(global_position, Color("ef786d"), 8)
	game.float_text(global_position, "−%d" % ceili(hit.amount), Color("ffb19a"))
	game.play_sound("hurt")
	vitality.damage(hit.amount)

func heal(amount: float) -> void:
	var before := hp
	vitality.heal(amount)
	if hp > before:
		game.float_text(global_position, "+%d VIDA" % ceili(hp - before), Color("9cdeb1"))

func refresh_stats() -> void:
	var difference := float(game.stats.max_hp) - vitality.maximum
	vitality.maximum = float(game.stats.max_hp)
	vitality.current = clampf(vitality.current + maxf(difference, 0.0), 0.0, vitality.maximum)
	if float(game.stats.shield) > 0.0 and shield_timer <= 0.0:
		shield_ready = true
	health_changed.emit(hp, max_hp)

func reset_position(pos: Vector2) -> void:
	global_position = pos
	velocity = Vector2.ZERO
	knockback_velocity = Vector2.ZERO
	dash_duration_left = 0.0
	target_refresh = 0.0
	current_target = null
	weapon_targets.clear()
	attack_cooldown = maxf(attack_cooldown, 0.3)
	invulnerability = maxf(invulnerability, 0.65)

func _die() -> void:
	if dead:
		return
	dead = true
	visual_state = "dead"
	velocity = Vector2.ZERO
	game.burst(global_position, Color("81d8bb"), 24)
	died.emit()

func _draw() -> void:
	if not is_instance_valid(game):
		return
	if invulnerability > 0.0:
		draw_arc(Vector2.ZERO, 23.0, 0.0, TAU * 0.85, 24, Color("fff1bd"), 2.0)
	if shield_ready:
		draw_arc(Vector2.ZERO, 27.0, 0.0, TAU, 8, Color("78ceff"), 2.0)
	draw_ellipse_shadow()
	var bob: float = -2.0 if visual_state == "moving" and sin(foot_phase) > 0.0 else 0.0
	var facing: float = -1.0 if aim_direction.x < -0.1 else 1.0
	draw_set_transform(Vector2(0, bob), 0, Vector2(facing, 1))
	if _sprite != null:
		draw_texture_rect(_sprite, Rect2(-18, -28, 36, 44), false)
	draw_set_transform(Vector2.ZERO)
	# A wooden crossbow and silver bolt follow automatic aim.
	var base: Vector2 = (aim_direction * (13.0 - recoil) + Vector2(0, 1)).round()
	draw_set_transform(base, aim_direction.angle())
	draw_rect(Rect2(-3, -3, 18, 6), Color("25313b"))
	draw_rect(Rect2(-2, -2, 15, 4), Color("9b673d"))
	draw_rect(Rect2(6, -10, 4, 20), Color("25313b"))
	draw_rect(Rect2(7, -8, 2, 16), Color("d7b467"))
	draw_line(Vector2(2, -8), Vector2(-1, 0), Color("e9dbb3"), 1.0)
	draw_line(Vector2(-1, 0), Vector2(2, 8), Color("e9dbb3"), 1.0)
	draw_rect(Rect2(0, -1, 17, 2), Color("e6eeee"))
	draw_set_transform(Vector2.ZERO)
	if "estilha" in game.active_weapons:
		draw_rect(Rect2(-18, 0, 3, 12), Color("e2c272"))
	if "pulso" in game.active_weapons:
		draw_rect(Rect2(16, -16, 2, 26), Color("98663a"))
		draw_rect(Rect2(13, -21, 8, 8), Color("3b547b"))
		draw_rect(Rect2(15, -19, 4, 4), Color("b5ecff"))

func draw_ellipse_shadow() -> void:
	draw_rect(Rect2(-14, 11, 28, 7), Color(0.12, 0.22, 0.14, 0.28))
	draw_rect(Rect2(-19, 13, 38, 3), Color(0.12, 0.22, 0.14, 0.18))
