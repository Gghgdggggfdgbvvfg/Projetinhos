class_name PixelActor
extends RefCounted
## Original miniature sprites, authored as pixels and cached once per palette.
## Transparent dots, dark silhouettes, warm metal and bright heraldic cloth.

static var _textures: Dictionary = {}

static func texture(kind: String, tint: Color = Color.WHITE) -> Texture2D:
	var key: String = kind + tint.to_html()
	if _textures.has(key):
		return _textures[key]
	var rows: Array[String] = _pixels(kind)
	var palette: Dictionary = {
		"X": Color("25313b"), "s": Color("597184"), "S": Color("a8bdc6"),
		"H": Color("e7eef0"), "b": Color("245583"), "B": Color("438bc2"),
		"G": Color("e5ba58"), "g": Color("9a6a35"), "w": Color("fff1c9"),
		"f": Color("e5b47c"), "h": Color("9f6845"), "r": Color("b6533e"),
		"R": Color("e57c52"), "t": Color("6b432e"), "T": Color("a77543"),
		"v": Color("3d7651"), "V": Color("85ba64"), "L": Color("bfda81"),
		"p": Color("6e5191"), "P": Color("ac7cba"), "n": Color("edcf9b")
	}
	# World accents affect cloth and skin slightly; recognizable silhouettes remain.
	if kind != "knight":
		for symbol: String in ["v", "V", "L", "r", "R", "p", "P"]:
			var original: Color = palette[symbol]
			palette[symbol] = original.lerp(tint, 0.16)
	var width: int = 0
	for row: String in rows:
		width = maxi(width, row.length())
	var bitmap: Image = Image.create(width, rows.size(), false, Image.FORMAT_RGBA8)
	bitmap.fill(Color.TRANSPARENT)
	for y: int in range(rows.size()):
		for x: int in range(rows[y].length()):
			var symbol: String = rows[y].substr(x, 1)
			if palette.has(symbol):
				bitmap.set_pixel(x, y, palette[symbol])
	var result: ImageTexture = ImageTexture.create_from_image(bitmap)
	_textures[key] = result
	return result

static func _pixels(kind: String) -> Array[String]:
	match kind:
		"knight":
			return [
				".......XXX........", "......XGGGX.......", ".....XGSSSGX......",
				"....XSSHHHSSX.....", "....XSHHHHHSSX....", "....XSSSSSSSSX....",
				"....XbXXwXXbSX....", ".....XsffffsX.....", "....XXSSSSSXX.....",
				"...XbXGSSSGXbX....", "..XBBXSHHSSXBBX...", ".XBBXSXSSSXSSBBX..",
				".XbXSSXSGSXSSXbX..", ".XbXfXXSGSXXfXbX..", ".XbXXXGGGGGXXXbX..",
				".XbBXSSXSXSSXBBX..", ".XBBXSSXSXSSXBBX..", "..XbXssXXXssXbX...",
				"...XXssX.XssXX....", "....XssX.XssX.....", "...XgggX.XgggX....",
				"...XXXXX.XXXXX...."
			]
		"chaser":
			return [
				".....XXXX.......", "....XVVVVX......", "...XVVLLVVX.....",
				"XX.XVVVVVVX.XX..", "XVXXVXXVXXVXXVX.", ".XVXVwXVwVXVX...",
				"..XXVVVVVVXX....", "...XVVXnXVVX....", "....XVVVVVX.....",
				"...XXrXXrXXX....", "..XVXrRrrXVVX...", ".XVVXrRrrXVXTX..",
				"..XXXTGGTTXXTX..", "...XrrXXrrX.XSX.", "...XVVXXVVX.XHX.",
				"...XVVX.XVX..X..", "..XtttX.XttX....", "..XXXXX.XXXX...."
			]
		"shooter":
			return [
				".......XXX........", "......XvvvX.......", ".....XvVVVvX......",
				"....XvVVLVVvX.....", "....XvXXXXvvX.....", "....XvfXXfXvX.....",
				"....XvfwffXvX.....", ".....XffffXX......", "....XXvXXvXX......",
				"...XvXVvvVXvX.....", "..XvVXVvvVXfX..XT.", "..XfXVTttTX..XT.X.",
				"...XXVTGGTVX.XT.X.", "...XvVTttTVvXTX.X.", "...XvVVvVVVvXTX.X.",
				"..XvVVVvVVVvXTX.X.", "..XvvVvXvVvvX.XTX.", "...XXvvXvvXX...XT.",
				"....XttXttX.......", "....XttXttX.......", "...XgggXgggX......",
				"...XXXXXXXXX......"
			]
		"charger":
			return [
				"......XXXXXX..............", "....XXttttttXX............", "...XtTTTTTTTTtXX..XX......",
				"..XtTTTTTTTTTTttXXTtX.....", "..XtTTTtTTTTTTTTtTTtX.....", ".XtTTttttTTTTTTTTTTtX.....",
				".XtTTtSStTTTTTTTTTTTtXX...", ".XtTTtSStTTTTTTTTwXTtttX..", ".XttTtSStTTTTTTTTTXTThhX..",
				"..XtTTttTTTTTTTTTTTTThhX..", "..XtTTTTTTTTTTTnXTTTTttX..", "...XtTTTTTTTTTTnXTTXXX....",
				"....XttXXXttXXnnXXX.......", "....XtX...XtX.............", "...XttX..XttX.............",
				"...XXXX..XXXX............."
			]
		"tank":
			return [
				"........XXXXXXX.........", ".......XVVVVVVVX........", "......XVLLLVLLVVX.......",
				".....XVVVVVVVVVVVX......", ".....XVXXVVVVXXVVX......", ".....XVwXVVVVwXVVX......",
				"......XVVVVVVVVVX.......", "......XVVnXXnVVVX.......", ".......XVVVVVVVX........",
				"....XXXXSSSSSSXXXX......", "...XSSSSSHHHHSSSSSX.....", "..XSSSXSSHHHHSSXSSSX....",
				".XVVVSXSSHHHSSSXVVVVX...", ".XVVVSXSSSSSSSSXVVVVX...", ".XVVVXXSSSGSSSSXXVVVX...",
				"..XVVXSSSSGSSSSXVVVX....", "..XVVXGGGGGGGGGXVVVX....", "...XXXrrrXrrrrXXVVX.....",
				"...XrrrRrXrrRrrXTTX.....", "...XrrrrrXrrrrrXTTX.....", "....XVVVX.XVVVX.TTX.....",
				"....XVVVX.XVVVX.TTX.....", "...XttttX.XttttXXTTX....", "...XXXXXX.XXXXXXGGGX....",
				"................XTTX...."
			]
		_:
			return [
				"..............X...X...X.............", ".............XGX.XGX.XGX............", ".............XGGGGGGGGGX............",
				"..............XGGGGGGGX.............", ".............XXSSSSSSSXX............", "............XSSHHHHHHHSSX...........",
				"............XSHHHHHHHHSSX...........", "............XSSSSSSSSSSSX...........", "............XSXXwXXXwXXSX...........",
				"............XSSSSXSSSSSSX...........", ".............XSSSXSSSSSX............", "......XXXXXXXXSSSSSSSSSXXXXXXXX.....",
				".....XrRRRRrXSGSSSSSSSGSXrRRRRrX....", "....XrRRRRrXSSGHHHHHHHGSSXrRRRRrX...", "...XrRRRRrXSSSGSSSSSSSGSSSXrRRRRrX..",
				"...XrRRRrXSSSSSGGGGGGGSSSSSXrRRRrX..", "...XrRRrXSSXSSSSSSSSSSSSXSSSXrRRrX..", "...XrRrXSSSXSSSSSGSSSSSSXSSSSXrRrX..",
				"...XrrXSSSSXSSSSGGGSSSSSXSSSSSXrrX..", "...XrrXSSSSXSSSSSGSSSSSSXSSSSSXrrX..", "...XrrXSSSSXSSSSSSSSSSSSXSSSSSXrrX..",
				"...XrrXffXXXGGGGGGGGGGGGXXXffXXrrX..", "...XrrXXXXXXrrrRrXXrRrrrrXXXXXXrrX..", "...XrrRRRRXrrrRrrXXrrRrrrXRRRRrrX..",
				"...XrrRRRXrrrRrrrXXrrrRrrrXRRRrrX..", "...XrrRRXrrrRrrrrXXrrrrRrrrXRRrrrX..", "...XrrRRXrrrrrrrXXXXrrrrrrrXRRrrrX..",
				"...XrrRRXSSSSSSX....XSSSSSSXRRrrrX..", "....XrrrXSSSSSSX....XSSSSSSXrrrXX...", ".....XXXXSSSSSSX....XSSSSSSXXXX.....",
				"........XSSSSSSX....XSSSSSSX........", "........XssssssX....XssssssX........", ".......XgggggggX....XgggggggX.......",
				".......XXXXXXXXX....XXXXXXXXX......."
			]
