class_name FendaEnemy
extends CharacterBody2D
## Explicit attack states keep every damaging action preceded by a readable tell.

signal defeated(enemy: FendaEnemy)

const DANGER := Color("e45d37")
const INK := Color("171d28")
const PALE := Color("f0dfb6")
const POISON := Color("b4ca85")
const STEER_INTERVAL: float = 0.18
const NEIGHBOR_CELL: float = 80.0
static var _neighbor_grid: Dictionary = {}
static var _neighbor_frame: int = -1
static var _neighbor_game: int = -1

var game: FendaGame
var data: EnemyData
var hp: float = 1.0
var max_hp: float = 1.0
var dead: bool = false
var is_boss: bool = false
var last_hit: DamageData
var vitality: Vitality
var hurtbox: Hurtbox
var telegraph: EnemyTelegraph
var state: String = "spawn"
var phase: int = 1

var _state_time: float = 0.0
var _state_length: float = 0.0
var _cooldown: float = 0.9
var _clock: float = 0.0
var _flash: float = 0.0
var _steer_timer: float = 0.0
var _steer: Vector2 = Vector2.ZERO
var _push: Vector2 = Vector2.ZERO
var _facing: Vector2 = Vector2.DOWN
var _aim: Vector2 = Vector2.DOWN
var _attack: String = ""
var _attack_damage: float = 1.0
var _charge_hit: bool = false
var _charge_origin: Vector2 = Vector2.ZERO
var _charge_distance: float = 300.0
var _boss_pattern: int = 0
var _volley_timer: float = 0.0
var _volleys: int = 0
var _poison_time: float = 0.0
var _poison_tick: float = 0.0
var _poison_strength: float = 0.0
var _poison_source: Node
var _orbit_sign: float = 1.0
var _sprite: Texture2D

func setup(owner_game: FendaGame, definition: EnemyData, level: int = 1) -> void:
	game = owner_game
	data = definition
	is_boss = data.kind == "boss"
	_sprite = PixelActor.texture(data.kind, game.world_data().enemy_tint)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	max_hp = data.hp * (1.0 + minf(maxi(level - 1, 0), 8) * 0.045)
	hp = max_hp
	_attack_damage = data.damage * (1.0 + minf(maxi(level - 1, 0), 8) * 0.025)
	_orbit_sign = -1.0 if game.rng.randf() < 0.5 else 1.0
	_cooldown = game.rng.randf_range(0.7, 1.35)
	_steer_timer = game.rng.randf_range(0.0, STEER_INTERVAL)
	collision_layer = 4
	collision_mask = 1
	z_index = 10
	add_to_group("enemies")
	var circle := CircleShape2D.new()
	circle.radius = data.radius
	var body_shape := CollisionShape2D.new()
	body_shape.shape = circle
	add_child(body_shape)
	vitality = Vitality.new()
	vitality.name = "Vitality"
	add_child(vitality)
	vitality.changed.connect(_on_health_changed)
	vitality.depleted.connect(_die)
	vitality.configure(max_hp)
	hurtbox = Hurtbox.new()
	hurtbox.name = "Hurtbox"
	add_child(hurtbox)
	hurtbox.setup(self, 2, data.radius + 2.0)
	telegraph = EnemyTelegraph.new()
	telegraph.name = "AttackAnticipation"
	# Clip danger indicators to the arena so they cannot cover the interface.
	var clip := Control.new()
	clip.name = "ArenaClip"
	clip.top_level = true
	clip.position = game.room.bounds.position
	clip.size = game.room.bounds.size
	clip.clip_contents = true
	clip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(clip)
	clip.add_child(telegraph)
	_set_state("spawn", 1.65 if is_boss else 0.7)
	if is_boss:
		game.float_text(global_position + Vector2(0, -70), game.world_data().boss_name.to_upper(), Color("ffe19b"))
	queue_redraw()

func _physics_process(delta: float) -> void:
	if dead or game == null or game.state != "active" or not is_instance_valid(game.player):
		return
	_clock += delta
	_flash = maxf(0.0, _flash - delta)
	_cooldown = maxf(0.0, _cooldown - delta)
	_state_time -= delta
	_push = _push.move_toward(Vector2.ZERO, 650.0 * delta)
	_update_poison(delta)
	if dead:
		return
	var offset: Vector2 = game.player.global_position - global_position
	var distance_to_player: float = offset.length()
	if state == "pursuit" or state == "spawn" or state == "recover":
		_facing = offset.normalized() if distance_to_player > 0.01 else Vector2.DOWN
	match state:
		"spawn":
			velocity = Vector2.ZERO
			if _state_time <= 0.0:
				_set_state("pursuit")
		"pursuit":
			_pursue(delta, distance_to_player)
		"warmup":
			velocity = Vector2.ZERO
			telegraph.progress = clampf(1.0 - _state_time / maxf(_state_length, 0.01), 0.0, 1.0)
			telegraph.queue_redraw()
			if _state_time <= 0.0:
				_begin_attack()
		"active":
			_update_attack(delta)
		"recover":
			velocity = Vector2.ZERO
			if _state_time <= 0.0:
				_set_state("pursuit")
	if state != "active" or _attack != "charge":
		velocity += _push
	move_and_slide()
	if state == "active" and _attack == "charge" and get_slide_collision_count() > 0:
		game.burst(global_position + _aim * data.radius, data.color, 7)
		_finish_attack(1.25)
	if is_boss and phase == 1 and hp <= max_hp * 0.5 and state != "warmup" and state != "active":
		phase = 2
		telegraph.clear()
		_set_state("recover", 1.7)
		game.float_text(global_position + Vector2(0, -65), "O GUARDIÃO REÚNE FORÇAS!", Color("ffe19b"))
		game.burst(global_position, Color("e9b455"), 18)
	queue_redraw()

func _pursue(delta: float, distance_to_player: float) -> void:
	var desired: Vector2 = _facing
	if is_boss:
		# Guardians enter from the edge of a large field, then fight at mid-range.
		# Full pursuit speed prevents them spending most of the encounter offscreen.
		desired *= 1.0 if distance_to_player > 340.0 else (-0.15 if distance_to_player < 190.0 else 0.12)
	elif data.kind == "shooter":
		if distance_to_player < 230.0:
			desired = -_facing + _facing.orthogonal() * _orbit_sign * 0.45
		elif distance_to_player < 340.0:
			desired = _facing.orthogonal() * _orbit_sign * 0.5
	_steer_timer -= delta
	if _steer_timer <= 0.0:
		_steer_timer = STEER_INTERVAL
		_steer = _find_steering(desired)
	velocity = velocity.move_toward(_steer * data.speed, 600.0 * delta)
	if _cooldown > 0.0:
		return
	if is_boss:
		if distance_to_player < 620.0 and _has_sight():
			# A short charge is useful only when it can actually reach its target.
			if _boss_pattern == 2 and distance_to_player > 430.0:
				_boss_pattern = 0
			_prepare_boss()
	elif data.kind == "chaser" and distance_to_player < data.radius + 42.0:
		_prepare("bite", 0.46)
		_mark_circles([global_position + _aim * (data.radius + 15.0)], 35.0)
	elif data.kind == "shooter" and distance_to_player < 550.0 and _has_sight():
		_prepare("shot", 0.78)
		_mark_direction("line", 560.0)
	elif data.kind == "charger" and distance_to_player < 490.0 and distance_to_player > 76.0 and _has_sight():
		_prepare_charge(0.85, 350.0)
	elif data.kind == "tank" and distance_to_player < 144.0:
		_prepare("slam", 1.05)
		_mark_circles([global_position], 112.0)

func _prepare(attack: String, duration: float) -> void:
	_attack = attack
	_aim = _facing
	velocity = Vector2.ZERO
	telegraph.clear()
	telegraph.striking = false
	telegraph.progress = 0.0
	telegraph.tint = DANGER
	_set_state("warmup", duration)

func _prepare_charge(duration: float, length: float) -> void:
	_prepare("charge", duration)
	_charge_hit = false
	_charge_origin = global_position
	_charge_distance = length
	var obstacle: Dictionary = _world_ray(global_position, global_position + _aim * length)
	if not obstacle.is_empty():
		_charge_distance = maxf(24.0, global_position.distance_to(obstacle["position"]) - data.radius)
	_mark_direction("charge", _charge_distance)
	telegraph.radius = data.radius * 0.95

func _prepare_boss() -> void:
	match _boss_pattern:
		0:
			_prepare("fan", 1.0 if phase == 1 else 0.9)
			_mark_direction("fan", 650.0)
			telegraph.spread = 0.69
		1:
			_prepare("eruption", 1.25 if phase == 1 else 1.12)
			var target: Vector2 = game.player.global_position
			var side: Vector2 = _aim.orthogonal() * 178.0
			var marks: Array[Vector2] = [target]
			for point: Vector2 in [target + side, target - side]:
				if game.room != null and game.room.is_safe(point, 72.0):
					marks.append(point)
			_mark_circles(marks, 68.0 if phase == 1 else 78.0)
		2:
			_prepare_charge(1.05 if phase == 1 else 0.9, 365.0)
	_boss_pattern = (_boss_pattern + 1) % 3

func _mark_circles(points: Array[Vector2], area_radius: float) -> void:
	telegraph.kind = "circle"
	telegraph.targets = points
	telegraph.radius = area_radius
	telegraph.queue_redraw()

func _mark_direction(kind: String, length: float) -> void:
	telegraph.kind = kind
	telegraph.origin = global_position
	telegraph.direction = _aim
	telegraph.distance = length
	telegraph.queue_redraw()

func _begin_attack() -> void:
	telegraph.striking = true
	telegraph.progress = 1.0
	telegraph.queue_redraw()
	match _attack:
		"bite", "slam", "eruption":
			for point: Vector2 in telegraph.targets:
				_strike(point, telegraph.radius, _attack_damage, 190.0 if _attack != "bite" else 115.0)
				game.burst(point, DANGER, 12 if is_boss else 7)
			game.play_sound("impact")
			_set_state("active", 0.22)
		"shot":
			_fire_projectile(_aim, 285.0, 650.0)
			_set_state("active", 0.12)
		"fan":
			_volleys = 0
			_volley_timer = 0.0
			telegraph.clear()
			_set_state("active", 0.7 if phase == 1 else 0.95)
		"charge":
			_set_state("active", 0.75)
			game.play_sound("dash")

func _update_attack(delta: float) -> void:
	if _attack == "charge":
		velocity = _aim * (590.0 if is_boss else 525.0)
		if not _charge_hit and global_position.distance_to(game.player.global_position) < data.radius + 22.0:
			_charge_hit = true
			_strike(global_position, data.radius + 16.0, _attack_damage, 240.0)
		if global_position.distance_to(_charge_origin) >= _charge_distance:
			_finish_attack(1.3 if is_boss else 1.15)
	elif _attack == "fan":
		velocity = Vector2.ZERO
		_volley_timer -= delta
		var volley_limit: int = 2 if phase == 1 else 3
		if _volley_timer <= 0.0 and _volleys < volley_limit:
			_volley_timer = 0.32
			var pellet_count: int = 7 if phase == 1 else 9
			for index: int in range(pellet_count):
				var angle: float = lerpf(-0.69, 0.69, float(index) / (pellet_count - 1))
				_fire_projectile(_aim.rotated(angle + (0.035 if _volleys % 2 == 1 else -0.035)), 215.0, 650.0)
			_volleys += 1
	else:
		velocity = Vector2.ZERO
	if _state_time <= 0.0 and state == "active":
		_finish_attack(1.65 if _attack == "fan" else (1.05 if is_boss or data.kind == "tank" else 0.6))

func _finish_attack(recovery: float) -> void:
	telegraph.clear()
	velocity = Vector2.ZERO
	_cooldown = 0.2 if is_boss else (1.1 if data.kind == "shooter" else 0.8)
	_set_state("recover", recovery)

func _set_state(next: String, duration: float = 0.0) -> void:
	state = next
	_state_time = duration
	_state_length = duration

func _fire_projectile(direction: Vector2, speed: float, reach: float) -> void:
	var muzzle: Vector2 = global_position + direction * (data.radius + 8.0)
	if not _world_ray(global_position, muzzle).is_empty():
		return
	game.spawn_projectile(global_position, direction, _attack_damage, speed, 2, self, {
		"color": DANGER, "radius": 5.0 if is_boss else 4.5, "lifetime": reach / speed, "reach": reach, "knockback": 100.0
	})
	game.burst(global_position + direction * data.radius, DANGER, 3)
	game.play_sound("enemy_shot")

func _strike(center: Vector2, radius: float, amount: float, force: float) -> void:
	var hit := DamageData.new()
	hit.amount = amount
	hit.origin = center
	hit.direction = (game.player.global_position - center).normalized()
	if hit.direction.length_squared() < 0.01:
		hit.direction = _aim
	hit.knockback = force
	hit.team = 2
	hit.source = self
	CombatHitbox.strike(get_tree(), center, radius, hit)

func _has_sight() -> bool:
	return _world_ray(global_position, game.player.global_position).is_empty()

func _world_ray(from: Vector2, to: Vector2) -> Dictionary:
	var query := PhysicsRayQueryParameters2D.create(from, to, 1)
	query.exclude = [get_rid()]
	return get_world_2d().direct_space_state.intersect_ray(query)

func _find_steering(desired: Vector2) -> Vector2:
	var motion: Vector2 = desired.normalized()
	var weight: float = minf(1.0, desired.length())
	var probe: float = data.radius + 66.0
	if not _world_ray(global_position, global_position + motion * probe).is_empty():
		var best_score: float = -100.0
		var chosen: Vector2 = Vector2.ZERO
		for turn: float in [0.8, -0.8, 1.45, -1.45, 2.0, -2.0]:
			var candidate: Vector2 = motion.rotated(turn * _orbit_sign)
			if _world_ray(global_position, global_position + candidate * probe).is_empty():
				var score: float = candidate.dot(motion) + (0.09 if turn > 0.0 else 0.0)
				if score > best_score:
					best_score = score
					chosen = candidate
		motion = chosen
	var separation: Vector2 = Vector2.ZERO
	var neighbors: int = 0
	# Rebuild once per physics frame from the director's cached population.
	# Each actor only checks nearby cells, never the full scene/group registry.
	_update_neighbor_grid()
	var cell: Vector2i = Vector2i(floori(global_position.x / NEIGHBOR_CELL), floori(global_position.y / NEIGHBOR_CELL))
	var checked: int = 0
	for y: int in range(-1, 2):
		for x: int in range(-1, 2):
			var bucket: Array = _neighbor_grid.get(cell + Vector2i(x, y), [])
			for candidate: Variant in bucket:
				if checked >= 36 or neighbors >= 12:
					break
				if not is_instance_valid(candidate) or candidate == self:
					continue
				var other: FendaEnemy = candidate
				if other.dead:
					continue
				checked += 1
				var displacement: Vector2 = global_position - other.global_position
				var distance_sq: float = displacement.length_squared()
				var clearance: float = data.radius + other.data.radius + 10.0
				if distance_sq < clearance * clearance and distance_sq > 0.001:
					var distance: float = sqrt(distance_sq)
					separation += displacement / distance * (1.0 - distance / clearance)
					neighbors += 1
	return (motion * weight + separation * 1.2).limit_length(1.0)

func _update_neighbor_grid() -> void:
	var physics_frame: int = Engine.get_physics_frames()
	if physics_frame == _neighbor_frame and _neighbor_game == game.get_instance_id():
		return
	_neighbor_frame = physics_frame
	_neighbor_game = game.get_instance_id()
	_neighbor_grid.clear()
	for enemy: FendaEnemy in game.enemies:
		if not is_instance_valid(enemy) or enemy.dead:
			continue
		var cell: Vector2i = Vector2i(floori(enemy.global_position.x / NEIGHBOR_CELL), floori(enemy.global_position.y / NEIGHBOR_CELL))
		if not _neighbor_grid.has(cell):
			_neighbor_grid[cell] = []
		(_neighbor_grid[cell] as Array).append(enemy)

func receive_hit(hit: DamageData) -> void:
	if dead or hit.team == 2 or hit.amount <= 0.0:
		return
	last_hit = hit.copy()
	_flash = 0.13
	_push += hit.direction * hit.knockback * (0.14 if is_boss else (0.4 if data.kind == "tank" else 1.0))
	if hit.poison > 0.0:
		if _poison_time <= 0.0:
			_poison_tick = 0.5
		_poison_time = 3.0
		# Three capped doses reward rapid hits; refresh without unbounded stacking.
		_poison_strength = minf(maxf(_poison_strength, 0.0) + hit.poison, hit.poison * 3.0)
		_poison_source = hit.source
	game.float_text(global_position + Vector2(0, -data.radius - 8), str(ceili(hit.amount)) + ("!" if hit.critical else ""), PALE if hit.critical else data.color)
	vitality.damage(hit.amount)
	queue_redraw()

func _update_poison(delta: float) -> void:
	if _poison_time <= 0.0:
		return
	_poison_time -= delta
	_poison_tick -= delta
	if _poison_tick <= 0.0:
		_poison_tick = 0.5
		var tick := DamageData.new()
		tick.amount = _poison_strength * 0.5
		tick.origin = global_position
		tick.team = 1
		tick.source = _poison_source if is_instance_valid(_poison_source) else null
		last_hit = tick
		game.float_text(global_position + Vector2(0, -data.radius), str(ceili(tick.amount)), POISON)
		vitality.damage(tick.amount)
	if _poison_time <= 0.0:
		_poison_strength = 0.0

func _on_health_changed(current: float, maximum: float) -> void:
	hp = current
	max_hp = maximum

func _die() -> void:
	if dead:
		return
	dead = true
	state = "dead"
	velocity = Vector2.ZERO
	telegraph.clear()
	game.burst(global_position, data.color, 24 if is_boss else 12)
	game.play_sound("enemy_death")
	defeated.emit(self)
	game.enemy_defeated(self)
	queue_free()

func _draw() -> void:
	if data == null or dead or _sprite == null:
		return
	var radius: float = data.radius
	var face: Vector2 = _aim if state == "warmup" or state == "active" else _facing
	var facing: float = -1.0 if face.x < -0.05 else 1.0
	var moving: bool = velocity.length_squared() > 60.0
	var bob: float = -2.0 if moving and sin(_clock * (10.0 if data.kind == "charger" else 8.0)) > 0.0 else 0.0
	var scale_factor: float = 2.0
	var extent: Vector2 = _sprite.get_size() * scale_factor
	var tint: Color = Color.WHITE
	if _flash > 0.0 and not bool(game.settings.get("reduced_flashes", false)):
		tint = Color(1.25, 1.25, 1.15)
	if state == "recover":
		tint = Color(0.88, 0.88, 0.88)
	draw_rect(Rect2(-radius, radius * 0.5, radius * 2.0, 8), Color(0.09, 0.18, 0.11, 0.3))
	draw_rect(Rect2(-radius - 4.0, radius * 0.5 + 2.0, radius * 2.0 + 8.0, 4), Color(0.09, 0.18, 0.11, 0.2))
	draw_set_transform(Vector2(0, bob), 0.0, Vector2(facing, 1.0))
	draw_texture_rect(_sprite, Rect2(Vector2(-extent.x * 0.5, radius * 0.6 - extent.y), extent), false, tint)
	if is_boss:
		# The broad cape, crown, tower shield and sword distinguish the guardian.
		var steel: Color = Color("a8bdc6")
		var gold: Color = Color("e5ba58")
		draw_rect(Rect2(-38, -19, 16, 27), Color("25313b"))
		draw_rect(Rect2(-36, -17, 12, 23), gold)
		draw_rect(Rect2(-34, -15, 8, 17), Color("366b9c"))
		draw_rect(Rect2(-31, -12, 2, 11), Color("fff1c9"))
		draw_rect(Rect2(-34, -9, 8, 2), Color("fff1c9"))
		draw_rect(Rect2(28, -41, 6, 46), Color("25313b"))
		draw_rect(Rect2(30, -39, 2, 31), steel)
		draw_rect(Rect2(25, -7, 12, 4), gold)
		draw_rect(Rect2(30, -3, 2, 7), Color("98663a"))
	draw_set_transform(Vector2.ZERO)
	if is_boss and phase == 2:
		draw_arc(Vector2.ZERO, radius + 9.0, -_clock * 0.35, -_clock * 0.35 + TAU * 0.8, 32, Color("f1b94c"), 2.0)
	if _poison_time > 0.0:
		draw_arc(Vector2.ZERO, radius + 5.0, _clock, _clock + TAU * 0.76, 24, POISON, 2.0)
	if state == "spawn":
		var progress: float = clampf(_state_time / maxf(_state_length, 0.01), 0.0, 1.0)
		draw_arc(Vector2.ZERO, radius + progress * 22.0, 0.0, TAU, 24, Color("fff1c9"), 2.0)
	if state == "warmup":
		draw_arc(Vector2.ZERO, radius + 6.0, -PI / 2.0, -PI / 2.0 + TAU * telegraph.progress, 28, DANGER, 3.0)
		# A fixed exclamation marker remains visible above dense groups.
		draw_rect(Rect2(-2, -extent.y + radius * 0.6 - 12, 4, 7), Color("ffe8b5"))
		draw_rect(Rect2(-2, -extent.y + radius * 0.6 - 3, 4, 3), DANGER)
	if not is_boss and hp < max_hp:
		var bar: Rect2 = Rect2(Vector2(-radius, -extent.y + radius * 0.6 - 5), Vector2(radius * 2.0, 3.0))
		draw_rect(bar.grow(1), INK)
		bar.size.x *= clampf(hp / max_hp, 0.0, 1.0)
		draw_rect(bar, Color("dba351"))
