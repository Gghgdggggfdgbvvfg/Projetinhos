class_name SpawnMarker
extends Node2D
var game: FendaGame
var time_left: float = 1.2
var total: float = 1.2
var tint := Color("ef9a77")

func _process(delta: float) -> void:
	if game.state != "active":
		return
	time_left -= delta
	if time_left <= 0.0:
		queue_free()
	queue_redraw()

func _draw() -> void:
	var radius := 16.0 + 14.0 * maxf(0.0, time_left / total)
	draw_arc(Vector2.ZERO, radius, 0, TAU, 6, Color(tint, 0.65), 1.5, true)
	draw_line(Vector2(-7,-7), Vector2(7,7), tint, 1.5)
	draw_line(Vector2(7,-7), Vector2(-7,7), tint, 1.5)
