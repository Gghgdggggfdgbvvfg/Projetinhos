class_name FendaSpark
extends Node2D
var game: FendaGame
var tint: Color = Color.WHITE
var count: int = 10
var age: float = 0.0
var lifetime: float = 0.42
var vectors: Array[Vector2] = []
var label: String = ""

func _ready() -> void:
	z_index = 25
	for i in range(count):
		vectors.append(Vector2.from_angle(float(i) * TAU / maxi(count, 1) + 0.4) * (36.0 + float(i % 3) * 25.0))

func _process(delta: float) -> void:
	if is_instance_valid(game) and game.state == "paused":
		return
	age += delta
	if age >= lifetime:
		queue_free()
		return
	queue_redraw()

func _draw() -> void:
	var fade := 1.0 - age / lifetime
	if not label.is_empty():
		var font := ThemeDB.fallback_font
		var size := font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, 17)
		draw_string(font, Vector2(-size.x * 0.5, -age * 48.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color(tint, fade))
		return
	for vector in vectors:
		var p := vector * age
		draw_line(p, p + vector.normalized() * 5.0 * fade, Color(tint, fade), 2.0, true)
