class_name DungeonGenerator
extends RefCounted
## A bounded self-avoiding spine plus branches. Only explicit graph edges are doors.
## This RNG is private: combat activity cannot change the layout for a seed.

const DIRECTIONS: Array[Vector2i] = [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]
const MAX_ATTEMPTS: int = 160

func generate(seed_value: int) -> Array[Dictionary]:
	var rng: RandomNumberGenerator = RandomNumberGenerator.new()
	rng.seed = seed_value
	var count: int = rng.randi_range(8, 12)
	var rooms: Array[Dictionary] = []
	var occupied: Dictionary = {}
	_append_room(rooms, occupied, Vector2i.ZERO, -1, rng)
	var spine_length: int = rng.randi_range(5, 6)
	var cursor: int = 0
	var attempts: int = 0
	while rooms.size() <= spine_length and attempts < MAX_ATTEMPTS:
		attempts += 1
		var next_grid: Vector2i = rooms[cursor]["grid"] + DIRECTIONS[rng.randi_range(0, 3)]
		if occupied.has(next_grid):
			continue
		cursor = _append_room(rooms, occupied, next_grid, cursor, rng)
	# A blocked spine is rebuilt by the deterministic safe fallback, never an endless retry.
	if rooms.size() <= spine_length:
		rooms = _fallback_layout(count, rng)
	else:
		attempts = 0
		while rooms.size() < count and attempts < MAX_ATTEMPTS:
			attempts += 1
			var parent_id: int = rng.randi_range(1, rooms.size() - 2)
			var next_grid: Vector2i = rooms[parent_id]["grid"] + DIRECTIONS[rng.randi_range(0, 3)]
			if occupied.has(next_grid):
				continue
			_append_room(rooms, occupied, next_grid, parent_id, rng)
		if rooms.size() < count:
			rooms = _fallback_layout(count, rng)
	_assign_depths(rooms)
	_assign_specials(rooms, rng)
	return rooms

func _append_room(rooms: Array[Dictionary], occupied: Dictionary, grid: Vector2i, parent_id: int, rng: RandomNumberGenerator) -> int:
	var index: int = rooms.size()
	var room: Dictionary = {
		"id": index, "grid": grid, "kind": "combat", "depth": 0,
		"neighbors": {}, "visited": false, "cleared": false,
		"reward_claimed": false, "template": rng.randi_range(1, 4),
	}
	rooms.append(room)
	occupied[grid] = index
	if parent_id >= 0:
		var direction: Vector2i = grid - Vector2i(rooms[parent_id]["grid"])
		rooms[parent_id]["neighbors"][direction] = index
		room["neighbors"][-direction] = parent_id
	return index

func _fallback_layout(count: int, rng: RandomNumberGenerator) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var occupied: Dictionary = {}
	# A bent corridor always supplies a valid connected graph and a distant final room.
	for index: int in count:
		var grid: Vector2i = Vector2i(index, 0) if index < 5 else Vector2i(4, index - 4)
		_append_room(result, occupied, grid, index - 1, rng)
	return result

func _assign_depths(rooms: Array[Dictionary]) -> void:
	var queue: Array[int] = [0]
	var seen: Dictionary = {0: true}
	rooms[0]["depth"] = 0
	while not queue.is_empty():
		var index: int = queue.pop_front()
		for neighbor: int in rooms[index]["neighbors"].values():
			if seen.has(neighbor):
				continue
			seen[neighbor] = true
			rooms[neighbor]["depth"] = int(rooms[index]["depth"]) + 1
			queue.append(neighbor)

func _assign_specials(rooms: Array[Dictionary], rng: RandomNumberGenerator) -> void:
	rooms[0]["kind"] = "start"
	rooms[0]["template"] = 0
	rooms[0]["cleared"] = true
	rooms[0]["reward_claimed"] = true
	var boss_id: int = 1
	for index: int in range(1, rooms.size()):
		if int(rooms[index]["depth"]) > int(rooms[boss_id]["depth"]):
			boss_id = index
	rooms[boss_id]["kind"] = "boss"
	rooms[boss_id]["template"] = 0
	var candidates: Array[int] = []
	for index: int in range(1, rooms.size()):
		if index != boss_id and int(rooms[index]["depth"]) >= 2:
			candidates.append(index)
	# Both resources are guaranteed, distinct, and outside the safe starting room.
	for special: String in ["reward", "recovery"]:
		var selection: int = rng.randi_range(0, candidates.size() - 1)
		var index: int = candidates[selection]
		candidates.remove_at(selection)
		rooms[index]["kind"] = special
		rooms[index]["template"] = 0
		rooms[index]["cleared"] = true

func encounter(room_data: Dictionary, rng: RandomNumberGenerator, catalog: GameCatalog) -> Array[EnemyData]:
	var result: Array[EnemyData] = []
	if room_data["kind"] == "boss":
		result.append(catalog.enemy("boss"))
		return result
	if room_data["kind"] != "combat":
		return result
	var depth: int = int(room_data["depth"])
	var budget: int = mini(18, 4 + depth * 2)
	var pool: Array[EnemyData] = [catalog.enemy("chaser")]
	if depth >= 2:
		pool.append(catalog.enemy("shooter"))
	if depth >= 3:
		pool.append(catalog.enemy("charger"))
	if depth >= 4:
		pool.append(catalog.enemy("tank"))
	# Introduce a newly available archetype deliberately, then vary the composition.
	if pool.size() > 1:
		var featured: EnemyData = pool[pool.size() - 1]
		result.append(featured)
		budget -= featured.cost
	while budget > 0 and result.size() < 8:
		var affordable: Array[EnemyData] = []
		for definition: EnemyData in pool:
			if definition.cost <= budget:
				affordable.append(definition)
		if affordable.is_empty():
			break
		var selected: EnemyData = affordable[rng.randi_range(0, affordable.size() - 1)]
		result.append(selected)
		budget -= selected.cost
	return result
