class_name WorldGenerator
extends RefCounted
## Bounded jittered placement keeps every obstacle isolated. Wide crossing
## roads and a clear spawn circle provide dependable escape routes.

const BOUNDS := Rect2(0, 0, 2560, 1920)
const SAFE_RADIUS: float = 180.0
const ROAD_CLEARANCE: float = 80.0

func generate(run_seed: int, definition: WorldData) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = run_seed + definition.seed_offset
	var center := BOUNDS.get_center()
	var paths: Array[PackedVector2Array] = []
	var horizontal := PackedVector2Array()
	var vertical := PackedVector2Array()
	for i in range(9):
		var x := float(i) * 320.0
		var shift := rng.randf_range(-110.0, 110.0) if i != 4 else 0.0
		horizontal.append(Vector2(x, center.y + shift))
	for i in range(7):
		var y := float(i) * 320.0
		var shift := rng.randf_range(-110.0, 110.0) if i != 3 else 0.0
		vertical.append(Vector2(center.x + shift, y))
	paths.append(horizontal)
	paths.append(vertical)
	var obstacles: Array[Rect2] = []
	var decorations: Array[Dictionary] = []
	var candidates: Array[Vector2] = []
	for gy in range(1, 9):
		for gx in range(1, 12):
			candidates.append(Vector2(gx * 210.0 + rng.randf_range(-42, 42), gy * 206.0 + rng.randf_range(-42, 42)))
	# Explicit Fisher-Yates uses this local RNG, never the global random stream.
	for i in range(candidates.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var swap := candidates[i]
		candidates[i] = candidates[j]
		candidates[j] = swap
	var target_count: int = [38, 48, 40, 36][definition.kind]
	for p in candidates:
		if obstacles.size() >= target_count:
			break
		var type := _obstacle_type(definition.kind, rng)
		var size := Vector2(42, 32)
		match type:
			"tent": size = Vector2(72, 42)
			"ruin": size = Vector2(76, 34)
			"hedge": size = Vector2(70, 38)
			"statue": size = Vector2(42, 36)
			"column": size = Vector2(36, 30)
			"rock": size = Vector2(44, 28)
		var rect := Rect2((p - size * 0.5).snapped(Vector2(2, 2)), size)
		if not BOUNDS.grow(-90.0).encloses(rect.grow(50.0)):
			continue
		if rect.grow(SAFE_RADIUS).has_point(center) or path_distance(p, paths) < ROAD_CLEARANCE + size.length() * 0.5:
			continue
		var spaced := true
		for other in obstacles:
			if rect.grow(64.0).intersects(other.grow(64.0)):
				spaced = false
				break
		if not spaced:
			continue
		obstacles.append(rect)
		decorations.append({"kind": type, "position": rect.get_center(), "variant": rng.randi_range(0, 2), "solid": true})
	# Ground marks deliberately have no collision and cannot enclose the hero.
	for i in range(1550):
		var p := Vector2(rng.randf_range(28, BOUNDS.size.x - 28), rng.randf_range(28, BOUNDS.size.y - 28)).snapped(Vector2(2, 2))
		var near_road := path_distance(p, paths) < 48.0
		var type := "grass"
		var roll := rng.randf()
		if near_road:
			if roll > 0.28: continue
			type = "pebbles"
		elif definition.kind == 2:
			type = "pebbles" if roll < 0.52 else ("grass" if roll < 0.86 else "flowers")
		elif definition.kind == 3:
			if roll > 0.38: continue
			type = "pebbles" if roll < 0.29 else "grass"
		else:
			type = "grass" if roll < 0.7 else ("flowers" if roll < 0.94 else "mushrooms")
		decorations.append({"kind": type, "position": p, "variant": rng.randi_range(0, 2), "solid": false})
	# Two small heraldic standards mark the starting crossroads.
	for dx in [-126.0, 126.0]:
		decorations.append({"kind": "banner", "position": center + Vector2(dx, -70), "variant": definition.kind % 3, "solid": false})
	decorations.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a.position.y < b.position.y)
	# Describe the playable geometry itself: including the input seed would
	# make two identical maps appear distinct and conceal generation regressions.
	var signature := str([BOUNDS, center, obstacles, paths]).sha256_text()
	return {"bounds": BOUNDS, "spawn": center, "obstacles": obstacles, "decorations": decorations, "paths": paths, "seed": run_seed + definition.seed_offset, "signature": signature}

static func path_distance(point: Vector2, paths: Array[PackedVector2Array]) -> float:
	var result := INF
	for path in paths:
		for i in range(path.size() - 1):
			result = minf(result, point.distance_to(Geometry2D.get_closest_point_to_segment(point, path[i], path[i + 1])))
	return result

func _obstacle_type(kind: int, rng: RandomNumberGenerator) -> String:
	var roll := rng.randf()
	match kind:
		0: return "tree" if roll < 0.6 else ("rock" if roll < 0.83 else "tent")
		1: return "tree" if roll < 0.68 else ("pine" if roll < 0.91 else "rock")
		2: return "ruin" if roll < 0.42 else ("column" if roll < 0.72 else ("rock" if roll < 0.9 else "tree"))
		3: return "hedge" if roll < 0.4 else ("statue" if roll < 0.64 else ("tree" if roll < 0.83 else "tent"))
	return "rock"
