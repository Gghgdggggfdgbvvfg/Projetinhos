class_name SurvivalArena
extends Node2D
## One continuous, seeded battlefield. Rendering is submitted once and cached
## by CanvasItem; scenery textures are shared across all four kingdoms.

var game: FendaGame
var definition: WorldData
var bounds := Rect2(0, 0, 2560, 1920)
var layout: Dictionary = {}
var obstacles: Array[Rect2] = []
var spawn_position := Vector2(1280, 960)
var _scenery: Array[Dictionary] = []
var _ground_scenery: Array[Dictionary] = []
var _patches: Array[Dictionary] = []
var _road_stones: Array[Rect2] = []
var _walls: StaticBody2D

func setup(owner_game: FendaGame, world: WorldData, run_seed: int) -> void:
	game = owner_game
	definition = world
	layout = WorldGenerator.new().generate(run_seed, definition)
	bounds = layout.bounds
	obstacles = layout.obstacles
	spawn_position = layout.spawn
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_prepare_art()
	_build_collision()
	queue_redraw()

func is_safe(point: Vector2, radius: float = 20.0) -> bool:
	if not point.is_finite() or radius < 0.0:
		return false
	if not bounds.grow(-radius - 2.0).has_point(point):
		return false
	for obstacle in obstacles:
		if obstacle.grow(radius + 2.0).has_point(point):
			return false
	return true

func find_spawn(center: Vector2, min_distance: float, max_distance: float, rng: RandomNumberGenerator, radius: float = 20.0) -> Vector2:
	if not center.is_finite() or min_distance < 0.0 or max_distance < min_distance:
		return Vector2.INF
	for attempt in range(48):
		var angle := rng.randf_range(0.0, TAU)
		var distance := rng.randf_range(min_distance, max_distance)
		var candidate := center + Vector2.from_angle(angle) * distance
		if is_safe(candidate, radius):
			return candidate
	# Near a corner only a small arc can remain inside the arena. Exhaust that
	# arc at several radii without silently violating the requested distance.
	var offset := rng.randf_range(0.0, TAU)
	for ring in range(5):
		var distance := lerpf(min_distance, max_distance, float(ring) / 4.0)
		for step in range(96):
			var candidate := center + Vector2.from_angle(offset + TAU * float(step) / 96.0) * distance
			if is_safe(candidate, radius):
				return candidate
	return Vector2.INF

func _build_collision() -> void:
	if is_instance_valid(_walls):
		remove_child(_walls)
		_walls.queue_free()
	_walls = StaticBody2D.new()
	_walls.name = "LimitesEObstaculos"
	_walls.collision_layer = 1
	_walls.collision_mask = 0
	add_child(_walls)
	for rectangle in obstacles:
		_add_shape(rectangle)
	# Bodies extend outward. Every visible point inside the border is usable.
	_add_shape(Rect2(bounds.position - Vector2(64, 64), Vector2(bounds.size.x + 128, 64)))
	_add_shape(Rect2(Vector2(bounds.position.x - 64, bounds.end.y), Vector2(bounds.size.x + 128, 64)))
	_add_shape(Rect2(Vector2(bounds.position.x - 64, bounds.position.y), Vector2(64, bounds.size.y)))
	_add_shape(Rect2(Vector2(bounds.end.x, bounds.position.y), Vector2(64, bounds.size.y)))

func _add_shape(rectangle: Rect2) -> void:
	var collider := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = rectangle.size
	collider.shape = shape
	collider.position = rectangle.get_center()
	_walls.add_child(collider)

func _prepare_art() -> void:
	_scenery.clear()
	_ground_scenery.clear()
	_patches.clear()
	_road_stones.clear()
	var rng := RandomNumberGenerator.new()
	rng.seed = int(layout.seed) ^ 0x38F29A
	for decoration: Dictionary in layout.decorations:
		var sprite := PixelScenery.sprite(str(decoration.kind), definition.kind, int(decoration.variant))
		var sprite_scale := 1.5 if bool(decoration.solid) or decoration.kind == "banner" else 1.0
		var prepared := {"texture": sprite.texture, "rect": Rect2(decoration.position - sprite.origin * sprite_scale, sprite.size * sprite_scale), "batch": str(decoration.kind) + str(decoration.variant)}
		if bool(decoration.solid) or decoration.kind == "banner":
			_scenery.append(prepared)
		else:
			_ground_scenery.append(prepared)
	# Ground details do not overlap actors or one another meaningfully. Grouping
	# them by texture keeps a thousand flower/grass tufts in a handful of batches.
	_ground_scenery.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a.batch < b.batch)
	for i in range(210):
		var position := Vector2(rng.randf_range(20, bounds.size.x - 100), rng.randf_range(20, bounds.size.y - 80)).snapped(Vector2(8, 8))
		var size := Vector2(rng.randi_range(5, 20) * 8, rng.randi_range(3, 10) * 8)
		var shade := definition.floor_color.lightened(rng.randf_range(0.015, 0.065)) if i % 2 == 0 else definition.floor_color.darkened(rng.randf_range(0.015, 0.045))
		_patches.append({"rect": Rect2(position, size), "color": shade})
	var paths: Array[PackedVector2Array] = layout.paths
	for path in paths:
		for segment in range(path.size() - 1):
			var a := path[segment]
			var b := path[segment + 1]
			var tangent := (b - a).normalized()
			var perpendicular := tangent.orthogonal()
			for step in range(0, int(a.distance_to(b)), 24):
				var p := a + tangent * float(step) + perpendicular * rng.randf_range(-24, 24)
				_road_stones.append(Rect2(p.snapped(Vector2(2, 2)), Vector2(rng.randi_range(2, 6) * 2, 4)))

func _draw() -> void:
	if definition == null or layout.is_empty():
		return
	draw_rect(bounds, definition.floor_color)
	for patch in _patches:
		draw_rect(patch.rect, patch.color)
	if definition.kind == 3:
		_draw_courtyard()
	elif definition.kind == 2:
		_draw_mosaics()
	_draw_paths()
	for scenery in _ground_scenery:
		draw_texture_rect(scenery.texture, scenery.rect, false)
	_draw_start_seal()
	for scenery in _scenery:
		draw_texture_rect(scenery.texture, scenery.rect, false)
	_draw_boundary()

func _draw_paths() -> void:
	var edge: Color = [Color("899549"), Color("507d49"), Color("ad965f"), Color("8b9a86")][definition.kind]
	var base: Color = [Color("b6ae71"), Color("a3a16a"), Color("d5bf82"), Color("c7c8ac")][definition.kind]
	var light := base.lightened(0.10)
	for path: PackedVector2Array in layout.paths:
		draw_polyline(path, edge, 106.0, false)
		draw_polyline(path, base, 92.0, false)
		draw_polyline(path, light, 62.0, false)
	for stone in _road_stones:
		draw_rect(stone, base.darkened(0.10))
		draw_rect(Rect2(stone.position, Vector2(stone.size.x, 2)), light.lightened(0.08))

func _draw_start_seal() -> void:
	# An old crossroads mosaic makes the safe initial clearing recognizable.
	var p := spawn_position
	var stone := Color("d8cb93") if definition.kind != 3 else Color("d7d9bf")
	draw_rect(Rect2(p - Vector2(49, 39), Vector2(98, 78)), stone.darkened(0.16))
	draw_rect(Rect2(p - Vector2(45, 35), Vector2(90, 70)), stone)
	draw_rect(Rect2(p - Vector2(33, 25), Vector2(66, 50)), stone.darkened(0.08))
	draw_rect(Rect2(p - Vector2(7, 22), Vector2(14, 44)), Color(definition.accent_color, 0.72))
	draw_rect(Rect2(p - Vector2(24, 6), Vector2(48, 12)), Color(definition.accent_color, 0.72))
	for x in [-39, 35]:
		for y in [-29, 25]:
			draw_rect(Rect2(p + Vector2(x, y), Vector2(4, 4)), stone.darkened(0.24))

func _draw_courtyard() -> void:
	# Quiet, broad paving leaves projectiles, crystals and enemies legible.
	var grout := definition.floor_color.darkened(0.07)
	for y in range(0, int(bounds.size.y), 64):
		for x in range(0, int(bounds.size.x), 96):
			var offset := 48 if (y / 64) % 2 else 0
			var p := Vector2(x + offset, y)
			draw_line(p, p + Vector2(90, 0), grout, 2)
			draw_line(p, p + Vector2(0, 58), grout, 2)

func _draw_mosaics() -> void:
	for i in range(9):
		var p := Vector2(290 + (i % 3) * 840, 270 + (i / 3) * 680)
		draw_rect(Rect2(p, Vector2(92, 60)), Color("b29d65"), false, 4)
		draw_rect(Rect2(p + Vector2(8, 8), Vector2(76, 44)), Color("cab67a"), false, 2)
		draw_rect(Rect2(p + Vector2(38, 17), Vector2(16, 26)), Color("85a793"))
		draw_rect(Rect2(p + Vector2(31, 24), Vector2(30, 12)), Color("85a793"))

func _draw_boundary() -> void:
	if definition.kind == 3 or definition.kind == 2:
		var stone := Color("b9bea8") if definition.kind == 3 else Color("c0a66e")
		draw_rect(bounds.grow(5), stone.darkened(0.26), false, 16)
		draw_rect(bounds.grow(-5), stone, false, 10)
		for x in range(24, int(bounds.size.x), 48):
			for y in [0.0, bounds.size.y - 18.0]:
				draw_rect(Rect2(x, y, 28, 18), stone.lightened(0.16))
		for y in range(24, int(bounds.size.y), 48):
			for x in [0.0, bounds.size.x - 18.0]:
				draw_rect(Rect2(x, y, 18, 28), stone.lightened(0.16))
		if definition.kind == 3:
			for p in [Vector2(24, 24), Vector2(bounds.size.x - 24, 24), Vector2(24, bounds.size.y - 24), bounds.size - Vector2(24, 24)]:
				_draw_tower(p)
	else:
		var wood := Color("8b7650")
		draw_rect(bounds.grow(2), definition.floor_color.darkened(0.22), false, 16)
		draw_rect(bounds.grow(-8), wood, false, 4)
		for x in range(16, int(bounds.size.x), 80):
			for y in [4.0, bounds.size.y - 12.0]:
				draw_rect(Rect2(x, y, 8, 12), Color("c5aa70"))
		for y in range(16, int(bounds.size.y), 80):
			for x in [4.0, bounds.size.x - 12.0]:
				draw_rect(Rect2(x, y, 8, 12), Color("c5aa70"))

func _draw_tower(p: Vector2) -> void:
	draw_rect(Rect2(p - Vector2(24, 20), Vector2(48, 48)), Color("7e9794"))
	draw_rect(Rect2(p - Vector2(20, 18), Vector2(40, 42)), Color("cbd1b7"))
	draw_rect(Rect2(p - Vector2(8, 6), Vector2(16, 20)), Color("558293"))
	for step in range(5):
		var width := 56 - step * 10
		draw_rect(Rect2(p + Vector2(-width * 0.5, -28 - step * 7), Vector2(width, 8)), Color("3e7f9e"))
		draw_rect(Rect2(p + Vector2(-width * 0.5, -28 - step * 7), Vector2(width * 0.5, 3)), Color("72afc3"))
	draw_rect(Rect2(p - Vector2(2, 67), Vector2(4, 13)), Color("e6bd61"))
