class_name PixelScenery
extends RefCounted
## Original, code-authored pixel illustrations. Textures are shared by every
## instance and generated only once; landscape drawing remains cached.

static var _cache: Dictionary = {}

static func sprite(kind: String, world: int, variant: int) -> Dictionary:
	var key := "%s:%d:%d" % [kind, world, variant]
	if _cache.has(key):
		return _cache[key]
	var small := kind in ["grass", "flowers", "pebbles", "mushrooms"]
	var img := Image.create(16 if small else 64, 16 if small else 72, false, Image.FORMAT_RGBA8)
	img.fill(Color.TRANSPARENT)
	match kind:
		"tree": _tree(img, world, variant)
		"pine": _pine(img, variant)
		"rock": _rock(img, world, variant)
		"tent": _tent(img, variant)
		"ruin": _ruin(img, variant)
		"column": _column(img, variant)
		"hedge": _hedge(img, variant)
		"statue": _statue(img)
		"banner": _banner(img, variant)
		_: _ground(img, kind, world, variant)
	var result := {"texture": ImageTexture.create_from_image(img), "origin": Vector2(8, 10) if small else Vector2(32, 64), "size": Vector2(img.get_width(), img.get_height())}
	_cache[key] = result
	return result

static func _r(img: Image, x: int, y: int, w: int, h: int, color: String) -> void:
	img.fill_rect(Rect2i(x, y, w, h), Color(color))

static func _shadow(img: Image, width: int = 38) -> void:
	_r(img, 32 - width / 2, 61, width, 7, "29453735")
	_r(img, 36 - width / 2, 59, width - 8, 11, "29453725")

static func _tree(img: Image, world: int, variant: int) -> void:
	var greens: Array = [
		["35583c", "447444", "5b8d48", "75a34e", "9dbb61"],
		["244f44", "326c4b", "478655", "69a466", "91be7b"],
		["636242", "7c803e", "9b9b49", "b7b45b", "d0c777"],
		["3b604e", "4c7c58", "6b995e", "8ab26a", "b1c985"],
	][world]
	_shadow(img, 48)
	_r(img, 26, 40, 12, 25, "5b4838")
	_r(img, 30, 43, 6, 20, "967347")
	_r(img, 34, 46, 3, 14, "b28c51")
	_r(img, 22, 60, 7, 4, "5b4838")
	_r(img, 36, 60, 7, 4, "5b4838")
	_r(img, 19, 34, 7, 15, "5b4838")
	_r(img, 23, 39, 7, 7, "967347")
	_r(img, 37, 30, 6, 20, "5b4838")
	# Block-shaped lobes give the canopy a hand-pixelled silhouette.
	_r(img, 18, 7, 25, 10, greens[0])
	_r(img, 9, 15, 44, 24, greens[0])
	_r(img, 4, 25, 54, 15, greens[0])
	_r(img, 11, 39, 41, 9, greens[0])
	_r(img, 19, 46, 27, 4, greens[0])
	_r(img, 19, 9, 23, 29, greens[2])
	_r(img, 11, 17, 41, 21, greens[1])
	_r(img, 6, 27, 49, 10, greens[1])
	_r(img, 15, 37, 34, 8, greens[1])
	_r(img, 14, 17, 31, 17, greens[2])
	_r(img, 21, 11, 19, 14, greens[3])
	_r(img, 9, 28, 15, 7, greens[2])
	_r(img, 29, 31, 18, 9, greens[2])
	_r(img, 17, 19, 14, 7, greens[3])
	_r(img, 36, 22, 12, 6, greens[3])
	_r(img, 22, 12, 10, 3, greens[4])
	_r(img, 16, 20, 8, 3, greens[4])
	_r(img, 10, 29, 7, 2, greens[3])
	_r(img, 30, 35, 9, 3, greens[3])
	_r(img, 43, 29, 5, 3, greens[0])
	_r(img, 20, 39, 5, 3, greens[0])
	if variant == 1:
		_r(img, 19, 30, 3, 3, "dfa54d")
		_r(img, 38, 19, 3, 3, "e9bc5e")
		_r(img, 34, 40, 3, 3, "d39643")
	elif variant == 2:
		_r(img, 15, 33, 3, 3, "c37855")
		_r(img, 39, 32, 3, 3, "db9663")
		_r(img, 28, 20, 3, 3, "d78b57")
	_r(img, 18, 64, 8, 2, greens[1])
	_r(img, 39, 63, 8, 3, greens[2])

static func _pine(img: Image, variant: int) -> void:
	_shadow(img, 38)
	_r(img, 28, 42, 9, 23, "5b493b")
	_r(img, 32, 43, 3, 20, "a1804e")
	var dark := "285749"
	var mid := "387458"
	var light := "60966a"
	for i in range(5):
		var y := 7 + i * 9
		var half := 4 + i * 4
		_r(img, 32 - half, y, half * 2, 11, dark)
		_r(img, 32 - half + 2, y + 1, half * 2 - 5, 7, mid)
		_r(img, 32 - half + 3, y + 1, half - 1, 3, light)
	_r(img, 31, 4, 3, 6, light)
	if variant == 2:
		_r(img, 26, 29, 3, 4, "c79b5d")
		_r(img, 39, 44, 3, 4, "ad8450")

static func _rock(img: Image, world: int, variant: int) -> void:
	_shadow(img)
	var edge := "6e786b" if world != 2 else "a38a5a"
	var mid := "8e9a81" if world != 2 else "c0aa74"
	var top := "b9c0a3" if world != 2 else "e1c98c"
	_r(img, 15, 53, 36, 12, edge)
	_r(img, 19, 46, 28, 12, edge)
	_r(img, 23, 43, 17, 4, edge)
	_r(img, 17, 54, 31, 7, mid)
	_r(img, 21, 48, 23, 9, mid)
	_r(img, 24, 45, 16, 5, top)
	_r(img, 21, 50, 11, 3, top)
	_r(img, 39, 54, 5, 7, edge)
	_r(img, 10, 62, 8, 4, mid)
	_r(img, 49, 58, 5, 6, top)
	if variant != 1:
		_r(img, 17, 60, 10, 4, "699150")
		_r(img, 22, 57, 5, 3, "86a15b")
	_r(img, 34, 49, 2, 5, edge)
	_r(img, 36, 53, 4, 2, edge)

static func _tent(img: Image, variant: int) -> void:
	_shadow(img, 52)
	var color: String = ["407b9c", "ba694f", "4e8d75"][variant]
	var highlight: String = ["74adc1", "df9970", "82b397"][variant]
	_r(img, 9, 59, 46, 7, "674e3a")
	_r(img, 11, 40, 42, 21, color)
	_r(img, 18, 31, 28, 10, color)
	_r(img, 25, 24, 14, 8, color)
	_r(img, 30, 21, 5, 4, "e3c882")
	_r(img, 13, 40, 14, 20, highlight)
	_r(img, 20, 32, 9, 8, highlight)
	_r(img, 27, 26, 4, 8, "f0dfaa")
	_r(img, 26, 34, 7, 10, "f0dfaa")
	_r(img, 24, 44, 11, 17, "e7d29b")
	_r(img, 29, 46, 5, 15, "504738")
	_r(img, 11, 39, 42, 3, "e8ce88")
	_r(img, 10, 60, 45, 3, "d5b67a")
	_r(img, 7, 48, 2, 17, "9a7b4d")
	_r(img, 55, 48, 2, 17, "9a7b4d")
	_r(img, 32, 9, 2, 14, "735b3f")
	_r(img, 34, 10, 10, 5, "edc35d")
	_r(img, 34, 15, 7, 3, "e1ad49")
	# A tiny supply chest by the entrance.
	_r(img, 43, 57, 11, 8, "715239")
	_r(img, 44, 55, 9, 5, "b38349")
	_r(img, 48, 56, 2, 8, "e0b965")

static func _ruin(img: Image, variant: int) -> void:
	_shadow(img, 52)
	_r(img, 8, 60, 49, 6, "9c855a")
	_r(img, 11, 28, 12, 34, "a88d59")
	_r(img, 44, 27, 11, 35, "a88d59")
	_r(img, 13, 29, 8, 30, "dec98e")
	_r(img, 45, 29, 7, 31, "cbb178")
	_r(img, 15, 20, 36, 10, "a88d59")
	_r(img, 20, 15, 25, 7, "bda36c")
	_r(img, 17, 21, 32, 6, "e3cc90")
	_r(img, 23, 16, 19, 5, "efdb9f")
	_r(img, 29, 14, 8, 14, "cbb178")
	_r(img, 30, 15, 5, 11, "f0dba1")
	for y in [35, 46, 56]:
		_r(img, 12, y, 11, 1, "a48a5a")
		_r(img, 44, y - 3, 10, 1, "99835a")
	_r(img, 16, 38, 1, 8, "a48a5a")
	_r(img, 49, 44, 1, 9, "99835a")
	_r(img, 9, 59, 16, 4, "ddc387")
	_r(img, 43, 59, 14, 4, "ddc387")
	_r(img, 24, 63, 8, 4, "c7ad75")
	_r(img, 36, 61, 5, 4, "d8bf86")
	_r(img, 13, 51, 3, 8, "8b9953")
	_r(img, 11, 56, 7, 3, "a3ae69")
	if variant == 1:
		_r(img, 40, 18, 11, 9, "00000000")
		_r(img, 43, 25, 10, 4, "d5bb80")
	elif variant == 2:
		_r(img, 21, 17, 5, 4, "83a06b")
		_r(img, 25, 20, 3, 5, "779461")

static func _column(img: Image, variant: int) -> void:
	_shadow(img, 30)
	_r(img, 20, 59, 26, 7, "a08c64")
	_r(img, 22, 55, 22, 7, "e2cc92")
	_r(img, 26, 28, 15, 28, "b9a372")
	_r(img, 27, 29, 6, 27, "e6d09b")
	_r(img, 35, 28, 2, 27, "ccb784")
	_r(img, 22, 23, 22, 8, "c8ad76")
	_r(img, 23, 23, 20, 3, "f0dba5")
	_r(img, 25, 20, 5, 4, "cbb480")
	_r(img, 37, 20, 5, 4, "ddc692")
	_r(img, 32, 35, 2, 8, "a58e60")
	_r(img, 34, 42, 5, 2, "a58e60")
	_r(img, 20, 63, 8, 3, "899b59")
	if variant == 2:
		_r(img, 37, 25, 5, 13, "4d99a3")
		_r(img, 38, 27, 3, 8, "8fbdb3")

static func _hedge(img: Image, variant: int) -> void:
	_shadow(img, 52)
	_r(img, 8, 55, 48, 10, "7f8b75")
	_r(img, 9, 56, 46, 4, "c9c9a5")
	_r(img, 12, 39, 40, 17, "3e7053")
	_r(img, 15, 34, 34, 7, "3e7053")
	_r(img, 14, 40, 36, 13, "598e5d")
	_r(img, 17, 36, 30, 6, "8bb575")
	_r(img, 19, 42, 7, 3, "76a76b")
	_r(img, 35, 45, 9, 3, "76a76b")
	var bloom: String = ["e0a5a1", "eedb93", "b5cbe0"][variant]
	for p in [Vector2i(21, 40), Vector2i(39, 39), Vector2i(30, 48)]:
		_r(img, p.x - 1, p.y, 5, 3, bloom)
		_r(img, p.x, p.y - 1, 3, 5, bloom)
		_r(img, p.x + 1, p.y + 1, 1, 1, "f4e8bc")
	for x in [19, 31, 43]: _r(img, x, 60, 1, 4, "9caa91")

static func _statue(img: Image) -> void:
	_shadow(img, 36)
	_r(img, 17, 60, 31, 6, "85938c")
	_r(img, 20, 55, 25, 6, "d5d6ba")
	_r(img, 24, 47, 17, 8, "a9b9ac")
	_r(img, 25, 30, 15, 18, "829e9d")
	_r(img, 29, 29, 10, 17, "bbcdc1")
	_r(img, 21, 32, 5, 12, "b8c5b5")
	_r(img, 40, 31, 5, 10, "728d90")
	_r(img, 27, 18, 12, 12, "78908e")
	_r(img, 29, 19, 9, 5, "c3d1c0")
	_r(img, 29, 25, 10, 2, "5f797c")
	_r(img, 27, 16, 13, 4, "dbbd71")
	_r(img, 27, 13, 3, 5, "edd798")
	_r(img, 33, 12, 3, 5, "edd798")
	_r(img, 38, 13, 3, 5, "edd798")
	_r(img, 45, 20, 2, 36, "b2a16c")
	_r(img, 44, 17, 4, 7, "d4ded0")
	_r(img, 29, 47, 3, 8, "748f8d")
	_r(img, 36, 47, 3, 8, "748f8d")
	_r(img, 31, 59, 6, 2, "c7a961")

static func _banner(img: Image, variant: int) -> void:
	_shadow(img, 18)
	var blue: String = ["3c7d9e", "457c67", "bd8153"][variant]
	var light: String = ["68b1ca", "81b294", "e4b36b"][variant]
	_r(img, 30, 15, 3, 49, "735c40")
	_r(img, 31, 17, 1, 46, "d0b676")
	_r(img, 29, 12, 5, 5, "efd38b")
	_r(img, 32, 19, 20, 24, blue)
	_r(img, 32, 19, 20, 3, "e7cd8a")
	_r(img, 34, 23, 3, 17, light)
	_r(img, 32, 42, 8, 5, blue)
	_r(img, 45, 42, 7, 5, blue)
	_r(img, 41, 26, 3, 11, "f4df9d")
	_r(img, 38, 30, 9, 3, "f4df9d")
	_r(img, 26, 63, 11, 3, "8f8c6a")

static func _ground(img: Image, kind: String, world: int, variant: int) -> void:
	var dark: String = ["68913e", "3e8050", "a4a05b", "879c74"][world]
	var light: String = ["9ab75e", "71aa70", "c9b77b", "bac69b"][world]
	match kind:
		"grass":
			_r(img, 4, 8, 2, 5, dark)
			_r(img, 3, 6, 2, 3, dark)
			_r(img, 7, 5, 2, 8, light)
			_r(img, 10, 8, 2, 5, dark)
			_r(img, 11, 6, 2, 3, light)
			if variant == 2: _r(img, 6, 12, 6, 2, dark)
		"flowers":
			var petals: String = ["f2de9b", "d6ddec", "e9b0a1"][variant]
			for p in [Vector2i(4, 7), Vector2i(11, 4), Vector2i(9, 11)]:
				_r(img, p.x, p.y, 1, 4, dark)
				_r(img, p.x - 1, p.y - 1, 3, 3, petals)
				_r(img, p.x, p.y, 1, 1, "d1a14f")
		"pebbles":
			var stone: String = ["b5b18a", "8ca582", "d8c68e", "c1cab2"][world]
			_r(img, 2, 8, 4, 2, stone)
			_r(img, 9, 5, 3, 2, stone)
			if variant != 0: _r(img, 10, 12, 3, 2, stone)
		"mushrooms":
			_r(img, 5, 9, 2, 4, "d9cc9a")
			_r(img, 3, 7, 6, 3, "c58b55")
			_r(img, 4, 6, 4, 2, "e3ba72")
			_r(img, 11, 11, 1, 3, "d9cc9a")
			_r(img, 10, 9, 4, 3, "c58b55")
			_r(img, 11, 9, 2, 1, "e3ba72")
