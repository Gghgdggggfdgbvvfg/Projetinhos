class_name WorldCatalog
extends RefCounted

static func all() -> Array[WorldData]:
	return [
		preload("res://resources/worlds/meadow.tres") as WorldData,
		preload("res://resources/worlds/forest.tres") as WorldData,
		preload("res://resources/worlds/ruins.tres") as WorldData,
		preload("res://resources/worlds/castle.tres") as WorldData,
	]
