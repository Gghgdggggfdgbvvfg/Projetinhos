class_name HordeDirector
extends RefCounted
## The spawn clock advances only while active. All randomness belongs to combat.
const MAX_ENEMIES: int = 100
const RETIRE_DISTANCE: float = 1300.0
var game: FendaGame
var spawn_clock: float = 0.25
var retirement_clock: float = 1.0
var pending: Array[Dictionary] = []
var guardian_requested: bool = false

func _init(owner_game: FendaGame) -> void:
	game = owner_game

func reset() -> void:
	spawn_clock = 0.25
	retirement_clock = 1.0
	pending.clear()
	guardian_requested = false

func update(delta: float) -> void:
	if game.state != "active":
		return
	retirement_clock -= delta
	if retirement_clock <= 0.0:
		retirement_clock = 1.0
		_retire_distant_enemies()
	for index in range(pending.size() - 1, -1, -1):
		pending[index].delay -= delta
		if float(pending[index].delay) > 0.0:
			continue
		var spawn: Dictionary = pending[index]
		pending.remove_at(index)
		var point: Vector2 = spawn.position
		if point.distance_to(game.player.position) < 155.0 or not game.room.is_safe(point, spawn.definition.radius + 3.0):
			point = game.room.find_spawn(game.player.position, 470, 850, game.rng, spawn.definition.radius + 4.0)
		if point.is_finite():
			game.spawn_enemy(spawn.definition, point, bool(spawn.boss))
		elif bool(spawn.boss):
			guardian_requested = false
	if game.world_time >= game.world_data().duration and not guardian_requested:
		request_guardian()
	spawn_clock -= delta
	if spawn_clock > 0.0:
		return
	var progress := minf(game.world_time / game.world_data().duration, 1.0)
	spawn_clock = lerpf(2.0, 0.68, progress) / (1.0 + game.world_index * 0.09)
	if game.boss_spawned:
		spawn_clock = 3.0
	var count := 2 + int(progress * 5.0) + game.world_index
	if game.boss_spawned:
		count = 2
	for i in count:
		if game.enemies.size() + pending.size() >= (52 if game.boss_spawned else MAX_ENEMIES):
			break
		var kind := "chaser"
		var roll := game.rng.randf()
		if game.world_time > 30.0 and roll < 0.12 + game.world_index * 0.03:
			kind = "shooter"
		elif game.world_time > 55.0 and roll < 0.25 + game.world_index * 0.03:
			kind = "charger"
		elif game.world_time > 85.0 and roll > 0.90 - game.world_index * 0.025:
			kind = "tank"
		_queue_spawn(game.catalog.enemy(kind), false)

func _retire_distant_enemies() -> void:
	# A moving hero must not fill the population cap with an abandoned horde.
	# Retire only ordinary actors beyond both pursuit range and the actual view.
	# This also works when the camera is clamped to a map edge or zoomed out.
	var viewport := game.get_viewport_rect()
	var canvas_to_world := game.get_viewport().get_canvas_transform().affine_inverse()
	var visible := Rect2(canvas_to_world * viewport.position, Vector2.ZERO)
	for corner: Vector2 in [Vector2(viewport.end.x, viewport.position.y), viewport.end, Vector2(viewport.position.x, viewport.end.y)]:
		visible = visible.expand(canvas_to_world * corner)
	for index in range(game.enemies.size() - 1, -1, -1):
		var enemy: FendaEnemy = game.enemies[index]
		if not is_instance_valid(enemy):
			game.enemies.remove_at(index)
			continue
		if enemy.is_boss or enemy.dead:
			continue
		if enemy.global_position.distance_squared_to(game.player.global_position) <= RETIRE_DISTANCE * RETIRE_DISTANCE:
			continue
		if visible.grow(160.0 + enemy.data.radius).has_point(enemy.global_position):
			continue
		# Despawning is not a defeat: no rewards, explosions or progression events.
		enemy.dead = true
		game.enemies.remove_at(index)
		enemy.queue_free()

func request_guardian() -> void:
	if guardian_requested or game.boss_spawned:
		return
	guardian_requested = _queue_spawn(game.catalog.enemy("boss"), true)
	if guardian_requested:
		game.float_text(game.player.position + Vector2(0,-70), "O GUARDIÃO CHEGOU!", Color("c47333"))
		game.play_sound("door")

func _queue_spawn(definition: EnemyData, boss: bool) -> bool:
	var point := game.room.find_spawn(game.player.position, 550.0 if not boss else 430.0, 850.0, game.rng, definition.radius + 5.0)
	if not point.is_finite():
		return false
	var delay := 1.4 if boss else 0.65
	pending.append({"position":point,"definition":definition,"delay":delay,"boss":boss})
	var marker := SpawnMarker.new()
	marker.game = game
	marker.position = point
	marker.tint = Color("db914c") if boss else Color("cf7250")
	marker.time_left = delay
	marker.total = delay
	game.room.add_child(marker)
	return true
