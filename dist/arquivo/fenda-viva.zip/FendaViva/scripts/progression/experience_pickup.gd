class_name ExperiencePickup
extends Node2D
## A small physical reward. Attraction uses distance checks, not hundreds of Areas.
var game: FendaGame
var value: int = 5
var kind: String = "xp"
var attracted: bool = false
var age: float = 0.0
var speed: float = 0.0
var consumed: bool = false

func _ready() -> void:
	add_to_group("pickups")
	z_index = 4
	queue_redraw()

func _physics_process(delta: float) -> void:
	if consumed or game.state != "active" or not is_instance_valid(game.player):
		return
	age += delta
	var offset := game.player.global_position - global_position
	if offset.length_squared() < 92.0 * 92.0:
		attracted = true
	if attracted:
		speed = minf(680.0, speed + delta * 1000.0)
		global_position = global_position.move_toward(game.player.global_position, speed * delta)
		if global_position.distance_squared_to(game.player.global_position) < 19.0 * 19.0:
			collect()

func collect() -> void:
	if consumed:
		return
	consumed = true
	if kind == "heal":
		game.player.heal(value)
		game.play_sound("collect")
	else:
		game.add_experience(value)
		game.play_sound("ui")
	queue_free()

func _draw() -> void:
	draw_rect(Rect2(-6, 5, 12, 3), Color(0.12, 0.18, 0.1, 0.25))
	if kind == "heal":
		draw_rect(Rect2(-5, -4, 10, 10), Color("933f35"))
		draw_rect(Rect2(-4, -5, 8, 8), Color("ed6b52"))
		draw_rect(Rect2(-2, -7, 3, 3), Color("4d713e"))
		draw_rect(Rect2(-3, -3, 2, 3), Color("ffc69a"))
	else:
		var tint := Color("44bfe5") if value < 14 else Color("e9b743")
		draw_colored_polygon(PackedVector2Array([Vector2(0,-8),Vector2(6,0),Vector2(0,7),Vector2(-6,0)]), Color("204969"))
		draw_rect(Rect2(-3, -4, 6, 8), tint)
		draw_rect(Rect2(-1, -6, 2, 12), tint)
		draw_rect(Rect2(-2, -3, 2, 4), Color("dbfbf2"))
