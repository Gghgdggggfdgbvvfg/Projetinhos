@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Jogar.ps1"
if errorlevel 1 pause
