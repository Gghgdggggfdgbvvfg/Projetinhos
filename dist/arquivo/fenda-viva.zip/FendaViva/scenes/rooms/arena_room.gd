class_name ArenaRoom
extends Node2D
## A room is a small handmade arena selected by the generated graph.
## Only this scene owns walls, gates, safe entrances and room interactables.

signal door_entered(direction: Vector2i)

const BOUNDS: Rect2 = Rect2(64, 128, 1152, 576)
const CENTER: Vector2 = Vector2(640, 416)
const DOOR_HALF: float = 48.0
const FLOOR: Color = Color("19282c")
const LINE: Color = Color("304349")
const TEAL: Color = Color("72ded0")
const GOLD: Color = Color("dfb779")
const INK: Color = Color("101a20")
const DIRECTIONS: Array[Vector2i] = [Vector2i.UP, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.LEFT]

var game: FendaGame
var data: Dictionary = {}
var locked: bool = false
var _obstacles: Array[Rect2] = []
var _gates: Array[CollisionShape2D] = []
var _entry_cooldown: float = 0.7
var _animation_time: float = 0.0
var _floor_marks: Array[Vector2] = []
var _item: ItemData

func setup(owner_game: FendaGame, room_data: Dictionary) -> void:
	game = owner_game
	data = room_data
	_obstacles = obstacle_rects(int(data.get("template", 0)))
	if game != null:
		_item = game.catalog.item(str(data.get("kind", "")))
	var decorations: RandomNumberGenerator = RandomNumberGenerator.new()
	decorations.seed = int(data.get("id", 0)) * 16411 + int(data.get("template", 0)) * 127 + 548
	for index: int in 64:
		_floor_marks.append(Vector2(decorations.randf_range(88, 1192), decorations.randf_range(148, 684)))
	_build_walls()
	for obstacle: Rect2 in _obstacles:
		_add_solid(obstacle)
	queue_redraw()

func set_locked(value: bool) -> void:
	locked = value
	for gate: CollisionShape2D in _gates:
		gate.set_deferred("disabled", not locked)
	queue_redraw()

func entry_position(from_dir: Vector2i) -> Vector2:
	match from_dir:
		Vector2i.UP: return Vector2(640, 188)
		Vector2i.RIGHT: return Vector2(1156, 416)
		Vector2i.DOWN: return Vector2(640, 644)
		Vector2i.LEFT: return Vector2(124, 416)
		_: return CENTER

func spawn_points() -> Array[Vector2]:
	var candidates: Array[Vector2] = [
		Vector2(204, 224), Vector2(432, 224), Vector2(640, 224), Vector2(848, 224), Vector2(1076, 224),
		Vector2(204, 320), Vector2(490, 320), Vector2(790, 320), Vector2(1076, 320),
		Vector2(220, 416), Vector2(440, 416), Vector2(840, 416), Vector2(1060, 416),
		Vector2(204, 512), Vector2(490, 512), Vector2(790, 512), Vector2(1076, 512),
		Vector2(204, 608), Vector2(432, 608), Vector2(640, 608), Vector2(848, 608), Vector2(1076, 608),
	]
	var result: Array[Vector2] = []
	for point: Vector2 in candidates:
		if is_safe(point, 36.0):
			result.append(point)
	return result

func is_safe(pos: Vector2, radius: float = 20.0) -> bool:
	if not BOUNDS.grow(-radius - 4.0).has_point(pos):
		return false
	for obstacle: Rect2 in _obstacles:
		if obstacle.grow(radius + 3.0).has_point(pos):
			return false
	return true

func check_interaction(player_pos: Vector2) -> String:
	if bool(data.get("reward_claimed", false)) or locked:
		return ""
	var kind: String = str(data.get("kind", ""))
	if kind in ["reward", "recovery"] and player_pos.distance_to(CENTER) <= 92.0:
		return kind
	return ""

static func obstacle_rects(template: int) -> Array[Rect2]:
	match template:
		1:
			return [Rect2(300, 248, 60, 74), Rect2(920, 248, 60, 74), Rect2(300, 510, 60, 74), Rect2(920, 510, 60, 74)]
		2:
			return [Rect2(300, 265, 150, 42), Rect2(830, 265, 150, 42), Rect2(300, 525, 150, 42), Rect2(830, 525, 150, 42)]
		3:
			return [Rect2(380, 235, 52, 116), Rect2(848, 235, 52, 116), Rect2(380, 481, 52, 116), Rect2(848, 481, 52, 116)]
		4:
			return [Rect2(240, 285, 90, 50), Rect2(950, 285, 90, 50), Rect2(240, 497, 90, 50), Rect2(950, 497, 90, 50)]
		_: return []

func _process(delta: float) -> void:
	if game == null:
		return
	if game.state == "active":
		_animation_time += delta
		_entry_cooldown = maxf(0.0, _entry_cooldown - delta)
		_check_doors()
	queue_redraw()

func _check_doors() -> void:
	if locked or _entry_cooldown > 0.0 or not is_instance_valid(game.player):
		return
	var pos: Vector2 = to_local(game.player.global_position)
	for direction: Vector2i in data.get("neighbors", {}):
		var reached: bool = false
		match direction:
			Vector2i.UP: reached = pos.y < 152 and absf(pos.x - CENTER.x) < 40.0
			Vector2i.RIGHT: reached = pos.x > 1192 and absf(pos.y - CENTER.y) < 40.0
			Vector2i.DOWN: reached = pos.y > 680 and absf(pos.x - CENTER.x) < 40.0
			Vector2i.LEFT: reached = pos.x < 88 and absf(pos.y - CENTER.y) < 40.0
		if reached:
			_entry_cooldown = 999.0
			door_entered.emit(direction)
			return

func _build_walls() -> void:
	for direction: Vector2i in DIRECTIONS:
		var has_door: bool = data.get("neighbors", {}).has(direction)
		if direction == Vector2i.UP or direction == Vector2i.DOWN:
			var y: float = 112.0 if direction == Vector2i.UP else 704.0
			if has_door:
				_add_solid(Rect2(48, y, 544, 16))
				_add_solid(Rect2(688, y, 544, 16))
				_gates.append(_add_solid(Rect2(592, y, 96, 16), true))
			else:
				_add_solid(Rect2(48, y, 1184, 16))
		else:
			var x: float = 48.0 if direction == Vector2i.LEFT else 1216.0
			if has_door:
				_add_solid(Rect2(x, 128, 16, 240))
				_add_solid(Rect2(x, 464, 16, 240))
				_gates.append(_add_solid(Rect2(x, 368, 16, 96), true))
			else:
				_add_solid(Rect2(x, 128, 16, 576))

func _add_solid(rect: Rect2, is_gate: bool = false) -> CollisionShape2D:
	var body: StaticBody2D = StaticBody2D.new()
	body.name = "Gate" if is_gate else "Architecture"
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = rect.get_center()
	var collision: CollisionShape2D = CollisionShape2D.new()
	var shape: RectangleShape2D = RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	collision.disabled = is_gate and not locked
	body.add_child(collision)
	add_child(body)
	return collision

func _draw() -> void:
	if data.is_empty():
		return
	draw_rect(Rect2(0, 0, 1280, 800), Color("10191f"))
	# Layered structural frame; the shadow falls down and right consistently.
	draw_rect(Rect2(BOUNDS.position + Vector2(5, 7), BOUNDS.size).grow(22), Color("0c151a"))
	draw_rect(BOUNDS.grow(16), Color("24353a"))
	draw_rect(BOUNDS.grow(9), Color("0f1c22"))
	draw_rect(BOUNDS, FLOOR)
	_draw_floor()
	_draw_structure()
	for direction: Vector2i in DIRECTIONS:
		if data.get("neighbors", {}).has(direction):
			_draw_door(direction)
	for obstacle: Rect2 in _obstacles:
		_draw_obstacle(obstacle)
	_draw_room_center()
	_draw_corner_labels()

func _draw_floor() -> void:
	var tile: int = 64
	for x: int in range(96, 1216, tile):
		draw_line(Vector2(x, 128), Vector2(x, 704), Color(0.20, 0.28, 0.30, 0.25), 1.0)
	for y: int in range(160, 704, tile):
		draw_line(Vector2(64, y), Vector2(1216, y), Color(0.20, 0.28, 0.30, 0.25), 1.0)
	for mark: Vector2 in _floor_marks:
		draw_line(mark, mark + Vector2(6, -2), Color(0.34, 0.42, 0.43, 0.10), 1.0)
	# A quiet cross-shaped route remains free of collisions in every handmade template.
	draw_rect(Rect2(594, 144, 92, 544), Color(0.14, 0.23, 0.25, 0.18))
	draw_rect(Rect2(80, 370, 1120, 92), Color(0.14, 0.23, 0.25, 0.18))
	draw_arc(CENTER, 128.0, 0, TAU, 80, Color(0.32, 0.48, 0.48, 0.10), 1.0, true)
	draw_arc(CENTER, 134.0, 0, TAU, 80, Color(0.32, 0.48, 0.48, 0.06), 1.0, true)
	for direction: Vector2i in DIRECTIONS:
		var origin: Vector2 = CENTER + Vector2(direction) * 128.0
		draw_line(origin - Vector2(direction) * 8.0, origin + Vector2(direction) * 8.0, LINE, 2.0)

func _draw_structure() -> void:
	# Inner rim and narrow brass rails sit above the floor, below actors.
	draw_rect(BOUNDS.grow(-3.0), Color("3d5054"), false, 1.0)
	draw_rect(BOUNDS.grow(-10.0), Color("273c40"), false, 1.0)
	for x: float in [88.0, 1192.0]:
		for y: float in [152.0, 680.0]:
			draw_rect(Rect2(Vector2(x, y) - Vector2(7, 7), Vector2(14, 14)), Color("b39867"))
			draw_rect(Rect2(Vector2(x, y) - Vector2(3, 3), Vector2(6, 6)), INK)
	for x: int in range(144, 1184, 80):
		draw_line(Vector2(x, 117), Vector2(x + 26, 117), Color("496062"), 2.0)
		draw_line(Vector2(x, 715), Vector2(x + 26, 715), Color("3a4f53"), 2.0)
	for y: int in range(176, 680, 64):
		draw_line(Vector2(54, y), Vector2(54, y + 20), Color("496062"), 2.0)
		draw_line(Vector2(1226, y), Vector2(1226, y + 20), Color("3a4f53"), 2.0)

func _draw_door(direction: Vector2i) -> void:
	var pos: Vector2 = CENTER
	if direction == Vector2i.UP: pos = Vector2(640, 128)
	elif direction == Vector2i.RIGHT: pos = Vector2(1216, 416)
	elif direction == Vector2i.DOWN: pos = Vector2(640, 704)
	else: pos = Vector2(64, 416)
	var forward: Vector2 = Vector2(direction)
	var across: Vector2 = forward.orthogonal()
	var color: Color = Color("b66e63") if locked else TEAL
	var corners: PackedVector2Array = PackedVector2Array([
		pos - across * 46.0 - forward * 15.0, pos + across * 46.0 - forward * 15.0,
		pos + across * 46.0 + forward * 17.0, pos - across * 46.0 + forward * 17.0,
	])
	draw_colored_polygon(corners, Color("17282c"))
	for side: float in [-1.0, 1.0]:
		var edge: Vector2 = pos + across * 48.0 * side
		draw_line(edge - forward * 18.0, edge + forward * 18.0, Color("627372"), 7.0)
		draw_line(edge - forward * 12.0, edge + forward * 11.0, color, 2.0)
	if locked:
		for offset: int in range(-32, 40, 16):
			draw_line(pos + across * offset - forward * 8.0, pos + across * (offset + 12) + forward * 8.0, color.darkened(0.3), 3.0)
		draw_line(pos - across * 42.0, pos + across * 42.0, color, 2.0)
	else:
		var pulse: float = 0.50 + sin(_animation_time * 2.0) * 0.12
		color.a = pulse
		for step: int in 2:
			var arrow: Vector2 = pos - forward * float(20 + step * 12)
			draw_line(arrow - across * 7.0 - forward * 5.0, arrow, color, 2.0)
			draw_line(arrow + across * 7.0 - forward * 5.0, arrow, color, 2.0)

func _draw_obstacle(rect: Rect2) -> void:
	draw_rect(Rect2(rect.position + Vector2(6, 8), rect.size).grow(3.0), Color(0.02, 0.06, 0.08, 0.55))
	draw_rect(rect, Color("152329"))
	draw_rect(rect.grow(-3.0), Color("34454a"))
	draw_rect(Rect2(rect.position + Vector2(4, 4), Vector2(rect.size.x - 8, 8)), Color("516164"))
	draw_rect(rect.grow(-11.0), Color("25363c"))
	draw_line(rect.position + Vector2(10, rect.size.y - 8), rect.end - Vector2(10, 8), Color("ae9466"), 2.0)
	for x: float in [rect.position.x + 8.0, rect.end.x - 8.0]:
		draw_circle(Vector2(x, rect.position.y + 8.0), 1.6, Color("a4ada5"))

func _draw_room_center() -> void:
	var kind: String = str(data.get("kind", ""))
	if kind == "start":
		_draw_start()
		return
	if kind == "boss":
		for radius: float in [65.0, 81.0, 87.0]:
			draw_arc(CENTER, radius, 0, TAU, 64, Color(0.60, 0.39, 0.56, 0.17), 2.0, true)
		return
	if _item == null:
		return
	var claimed: bool = bool(data.get("reward_claimed", false))
	var color: Color = _item.color.darkened(0.6) if claimed else _item.color
	draw_circle(CENTER + Vector2(0, 7), 40.0, Color("0e1c22"))
	draw_arc(CENTER, 37.0, 0, TAU, 48, color.darkened(0.5), 2.0, true)
	if claimed:
		_draw_centered("NÚCLEO EXAURIDO", CENTER + Vector2(0, 63), 13, Color("778887"))
		return
	var lift: float = sin(_animation_time * 2.0) * 3.0
	var icon_rect: Rect2 = Rect2(CENTER + Vector2(-24, -31 + lift), Vector2(48, 48))
	if _item.icon != null:
		draw_texture_rect(_item.icon, icon_rect, false, color)
	_draw_centered(_item.display_name.to_upper(), CENTER + Vector2(0, 68), 18, color)
	var nearby: bool = is_instance_valid(game) and is_instance_valid(game.player) and game.player.global_position.distance_to(to_global(CENTER)) <= 92.0
	if nearby:
		_draw_centered("[E]  " + _item.description, CENTER + Vector2(0, 94), 14, Color("d6dfd6"))
	else:
		_draw_centered("Aproxime-se para interagir", CENTER + Vector2(0, 91), 13, Color("7a9292"))

func _draw_start() -> void:
	draw_arc(CENTER, 35.0, 0, TAU, 48, Color("3e6967"), 2.0, true)
	_draw_centered("VOCÊ DESPERTOU ENTRE AS PEDRAS.", Vector2(640, 275), 18, Color("cbd5ca"))
	_draw_centered("O coração move a fortaleza. Encontre-o e abra uma saída.", Vector2(640, 303), 15, Color("829a99"))
	var controls: Array[String] = ["WASD  /  SETAS     mover", "MOUSE     mirar + disparar", "ESPAÇO     esquivar", "Q     trocar arma"]
	for index: int in controls.size():
		_draw_centered(controls[index], Vector2(640, 501 + index * 25), 14, Color("94aaa6"))

func _draw_corner_labels() -> void:
	var names: Dictionary = {"start": "VESTÍBULO", "combat": "CÂMARA", "reward": "RELICÁRIO", "recovery": "CISTERNA", "boss": "CORAÇÃO"}
	var label: String = "%02d  /  %s" % [int(data.get("id", 0)) + 1, names.get(data.get("kind", "combat"), "CÂMARA")]
	draw_string(ThemeDB.fallback_font, Vector2(91, 167), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("6b8281"))
	draw_string(ThemeDB.fallback_font, Vector2(91, 681), "F V   /   ARQUITETURA VIVA", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("49615f"))

func _draw_centered(label: String, pos: Vector2, size: int, color: Color) -> void:
	var font: Font = ThemeDB.fallback_font
	var width: float = font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	draw_string(font, pos - Vector2(width * 0.5, 0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
