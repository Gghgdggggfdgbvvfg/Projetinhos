extends SceneTree
## Real state, reward and progression integration for the medieval survival mode.
var game: FendaGame
var failures: int = 0
var checks: int = 0
var original_unlock: int = 0

func _initialize() -> void:
	call_deferred("_run")

func check(value: bool, label: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error("FAIL " + label)

func frames(amount: int = 3) -> void:
	for i in amount:
		await physics_frame
		await process_frame

func choose_all() -> void:
	for i in 40:
		await frames(2)
		if game.state != "upgrade": break
		check(not game.offered.is_empty(),"level offers at least one eligible reward")
		game.choose_upgrade(game.offered[0].id)

func freeze_spawns() -> void:
	game.director.spawn_clock = 9999.0
	game.director.pending.clear()
	game.director.guardian_requested = true

func check_horde_retirement() -> void:
	var original_position := game.player.position
	game.player.set_physics_process(false)
	game.player.position = Vector2(300,300)
	game.camera.position = game.player.position
	game.camera.force_update_scroll()
	for index in HordeDirector.MAX_ENEMIES - 2:
		var distant := game.spawn_enemy(game.catalog.enemy("chaser"),Vector2(2200,1500))
		distant.set_physics_process(false)
	var nearby := game.spawn_enemy(game.catalog.enemy("chaser"),game.player.position + Vector2(180,0))
	nearby.set_physics_process(false)
	var guardian := game.spawn_enemy(game.catalog.enemy("boss"),Vector2(2200,1500))
	guardian.set_physics_process(false)
	check(game.enemies.size()==HordeDirector.MAX_ENEMIES,"retirement fixture fills the enemy cap")
	var kills_before := game.kills
	var xp_before := game.experience
	game.director._retire_distant_enemies()
	check(game.enemies.size()==2 and game.enemies.has(nearby) and game.enemies.has(guardian),"abandoned ordinary horde retires while visible enemies and guardian remain")
	check(game.kills==kills_before and game.experience==xp_before and get_nodes_in_group("pickups").is_empty(),"retirement grants no kills or experience")
	game.director.spawn_clock = 0.0
	game.director.update(0.01)
	check(not game.director.pending.is_empty(),"retiring a distant capped horde allows fresh enemies to spawn")
	game.camera.zoom = Vector2(0.25,0.25)
	game.camera.force_update_scroll()
	var visible_far := game.spawn_enemy(game.catalog.enemy("chaser"),Vector2(2200,1500))
	visible_far.set_physics_process(false)
	game.director._retire_distant_enemies()
	check(game.enemies.has(visible_far),"zoomed-out visible enemies are never retired")
	for enemy in game.enemies:
		enemy.dead = true
		enemy.queue_free()
	game.enemies.clear()
	game.director.reset()
	freeze_spawns()
	game.camera.zoom = Vector2.ONE
	game.player.reset_position(original_position)
	game.camera.position = original_position
	game.camera.force_update_scroll()
	game.player.set_physics_process(true)
	await frames(2)

func _run() -> void:
	game = FendaGame.new()
	root.add_child(game)
	await frames()
	original_unlock = game.unlocked_world
	game.unlocked_world = 0
	check(game.worlds.size()==4 and game.state=="menu","four worlds and initial menu")
	game.start_run(20261019,3)
	await frames()
	freeze_spawns()
	check(game.world_index==0,"locked world cannot be started")
	check(game.player.hp==100 and game.room.is_safe(game.player.position),"safe fresh player")
	check(game.active_weapons==["agulha"],"single starting automatic weapon")
	await check_horde_retirement()
	var emitter:=Node2D.new()
	game.room.add_child(emitter)
	game.player.invulnerability=0
	game.spawn_projectile(game.player.position+Vector2(100,0),Vector2.LEFT,2,700,2,emitter)
	emitter.queue_free()
	await frames(14)
	check(game.player.hp==98,"enemy projectile still deals damage after emitter is freed")
	var signature: String = game.room.layout.signature
	check(game.room.bounds.size.x>1280 and game.room.bounds.size.y>800,"large continuous arena")
	var before_pos := game.player.position
	Input.action_press("move_right")
	await frames(15)
	Input.action_release("move_right")
	check(game.player.position.x>before_pos.x+20,"player movement remains responsive")
	var frozen_time := game.world_time
	var frozen_run := game.run_time
	game.toggle_pause()
	await frames(6)
	check(game.world_time==frozen_time and game.run_time==frozen_run,"pause freezes both timers")
	game.resume_run()
	game.add_experience(60)
	await frames()
	check(game.state=="upgrade" and game.player_level>=3,"XP grants queued levels")
	await choose_all()
	check(game.pending_levels==0 and game.state=="active","multiple level choices all resolve")
	while game.player_level<7:
		game.add_experience(game.experience_needed-game.experience)
		await frames()
		await choose_all()
	check(game.active_weapons.size()==3,"levels4 and7 unlock concurrent weapons")
	var pickup := ExperiencePickup.new()
	pickup.game = game
	pickup.position = game.player.position+Vector2(30,0)
	pickup.value = 1
	game.room.add_child(pickup)
	var before_xp := game.experience
	await frames(20)
	check(game.experience==before_xp+1 and not is_instance_valid(pickup),"nearby XP gem magnet and collection")
	game.player.vitality.current=40
	var apple := ExperiencePickup.new()
	apple.game=game
	apple.position=game.player.position
	apple.kind="heal"
	apple.value=10
	game.room.add_child(apple)
	await frames(3)
	check(game.player.hp==50,"apple restores real health")
	game.director.reset()
	game.world_time=80
	await frames(75)
	check(game.enemies.size()>0,"continuous director spawns actual enemies")
	check(game.enemies.size()<=HordeDirector.MAX_ENEMIES,"enemy population bounded")
	game.player.invulnerability=999
	game.world_time=game.world_data().duration
	game.director.guardian_requested=false
	await frames(100)
	check(game.boss_spawned,"timer summons guardian")
	var boss: FendaEnemy
	for enemy in game.enemies:
		if enemy.is_boss: boss=enemy
	check(is_instance_valid(boss),"guardian is a live boss")
	var lethal := DamageData.new()
	lethal.team=1
	lethal.source=game.player
	lethal.amount=100000
	if boss: boss.receive_hit(lethal)
	game.toggle_pause()
	await frames()
	check(game.state=="paused" and game.world_end_pending,"last-hit pause retains world completion")
	game.resume_run()
	await frames()
	await choose_all()
	check(game.state=="world_complete" and game.worlds_cleared==1,"guardian death reaches next-world choice")
	check(game.unlocked_world==1,"next kingdom permanently unlocked")
	var persisted := ConfigFile.new()
	persisted.load("user://kingdoms.cfg")
	check(int(persisted.get_value("progress","unlocked_world",-1))==1,"unlock stored on disk")
	game.unlocked_world=0
	game._load_progress()
	check(game.unlocked_world==1,"saved unlock survives a progress reload")
	game.complete_world()
	check(game.worlds_cleared==1,"repeated world completion cannot duplicate rewards")
	var old_level := game.player_level
	var old_build := game.stacks.duplicate()
	game.advance_world()
	await frames()
	freeze_spawns()
	check(game.world_index==1 and game.world_time<1,"next arena resets world clock")
	check(game.player_level==old_level and game.stacks==old_build,"build carries between worlds")
	check(game.room.layout.signature!=signature,"next world has different procedural layout")
	check(get_nodes_in_group("projectiles").is_empty() and game.enemies.is_empty(),"world transition clears combat")
	for index in range(1,4):
		var guardian := game.spawn_enemy(game.catalog.enemy("boss"),game.player.position+Vector2(200,0),true)
		guardian.receive_hit(lethal)
		# XP and the killing blow in one frame must record the world before choices.
		game.add_experience(game.experience_needed-game.experience)
		await frames()
		check(game.world_recorded and game.worlds_cleared==index+1,"guardian with queued level-up records completed world exactly once")
		await choose_all()
		check(game.unlocked_world==mini(index+1,3),"each guardian unlocks the following kingdom")
		if index<3:
			check(game.state=="world_complete","intermediate guardian offers next kingdom")
			game.advance_world()
			await frames()
			freeze_spawns()
	check(game.state=="victory","final world closes the run with victory")
	game.start_run(111)
	freeze_spawns()
	game.player.invulnerability=0
	var damage := DamageData.new()
	damage.team=2
	damage.amount=100000
	game.player.receive_hit(damage)
	check(game.state=="defeat","death stops survival")
	game.start_run(20261019)
	await frames()
	freeze_spawns()
	check(game.player_level==1 and game.active_weapons.size()==1 and game.kills==0,"retry resets run build")
	check(game.room.layout.signature==signature,"same seed reproduces first world")
	game.go_menu()
	await frames()
	check(not is_instance_valid(game.player) and not is_instance_valid(game.room),"menu removes arena and actors")
	game.unlocked_world=original_unlock
	game._save_progress()
	game.queue_free()
	await frames()
	await create_timer(.2,true,false,true).timeout
	print("SURVIVAL: %d checks; %d failures"%[checks,failures])
	quit(1 if failures else 0)
