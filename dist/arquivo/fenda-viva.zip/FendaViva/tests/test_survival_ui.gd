extends SceneTree
## UI integration: menu lock gates, selected seed/world, live HUD and state screens.

var failures: int = 0
var game: FendaGame

func _initialize() -> void:
	call_deferred("_run")

func _check(condition: bool, description: String) -> void:
	if not condition:
		failures += 1
		push_error(description)

func _run() -> void:
	root.size = Vector2i(1280, 800)
	game = load("res://scenes/main/main.tscn").instantiate() as FendaGame
	root.add_child(game)
	await process_frame
	game.unlocked_world = 0
	game.hud.show_menu()
	await process_frame
	await process_frame
	_check(game.hud._world_buttons.size() == 4, "Menu offers four worlds")
	_check(not game.hud._world_buttons[0].disabled, "First world available")
	_check(game.hud._world_buttons[1].disabled and game.hud._world_buttons[3].disabled, "Later worlds locked")
	game.hud._select_world(3)
	_check(game.hud._selected_world == 0, "Locked world cannot be selected")
	game.hud._seed_input.text = "not a seed"
	game.hud._start_from_menu()
	_check(game.state == "menu", "Invalid seed stays on menu")
	game.unlocked_world = 1
	game.hud.show_menu()
	game.hud._world_buttons[1].pressed.emit()
	game.hud._seed_input.text = "234567"
	game.hud._start_from_menu()
	await process_frame
	_check(game.state == "active" and game.world_index == 1, "Menu starts selected unlocked world")
	_check(game.seed_value == 234567, "Menu forwards procedural seed")
	game.state = "paused"
	game.player_level = 7
	game.experience = 8
	game.experience_needed = 42
	game.kills = 123
	game.active_weapons = ["agulha", "estilha", "pulso"]
	game.hud.refresh()
	_check(game.hud._level.text == "NÍVEL 7  ·  8 / 42 EXP", "HUD exposes level and experience")
	_check(game.hud._xp.value == 8 and game.hud._xp.max_value == 42, "Experience bar matches progression")
	_check("123" in game.hud._kills.text, "HUD kill count updates")
	_check("Q" not in game.hud._weapon.text, "Weapon HUD does not request manual switching")
	_check(game.hud._screen == "paused", "Pause menu appears")
	game.hud._show_settings()
	_check(game.hud._settings_open, "Settings open")
	game.hud._close_settings()
	_check(game.hud._screen == "paused", "Settings return to current screen")
	game.state = "upgrade"
	game.hud.show_upgrade(game.catalog.offer({}, game.rng))
	_check(game.hud._options.size() == 3 and game.hud._screen == "upgrade", "Level choice has three upgrades")
	game.state = "world_complete"
	game.hud.refresh()
	_check(game.hud._screen == "world_complete", "World completion has its own overlay")
	var advance: Button = _find_button(game.hud._overlay, "AVANÇAR PARA O PRÓXIMO REINO")
	_check(advance != null, "World completion has advance action")
	if advance != null:
		advance.pressed.emit()
	_check(game.world_index == 2 and game.state == "active", "Advance button loads next world")
	_check(game.player_level == 7, "Advancing preserves character level")
	game.state = "defeat"
	game.hud.refresh()
	_check(game.hud._screen == "defeat", "Defeat overlay renders")
	game.state = "victory"
	game.hud.refresh()
	_check(game.hud._screen == "victory", "Victory overlay renders")
	game.go_menu()
	_check(game.hud._screen == "menu" and not game.hud._hud.visible, "Return to menu hides battle HUD")
	game.audio.stop_all()
	game.queue_free()
	await process_frame
	await process_frame
	# Audio playback releases on its worker thread, after the scene nodes exit.
	await create_timer(0.2, true, false, true).timeout
	print("SURVIVAL UI: ", "PASS" if failures == 0 else "FAIL", " (", failures, " failures)")
	quit(0 if failures == 0 else 1)

func _find_button(node: Node, prefix: String) -> Button:
	if node is Button and (node as Button).text.begins_with(prefix):
		return node as Button
	for child: Node in node.get_children():
		var found: Button = _find_button(child, prefix)
		if found != null:
			return found
	return null
