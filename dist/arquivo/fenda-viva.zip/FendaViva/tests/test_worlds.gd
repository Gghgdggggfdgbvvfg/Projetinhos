extends SceneTree
## Run: godot --headless --path . --script tests/test_worlds.gd

const CELL := 40
const GRID := Vector2i(64, 48)
var failures: int = 0
var checks: int = 0

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var generator := WorldGenerator.new()
	var arena := SurvivalArena.new()
	var total_obstacles := 0
	for world in WorldCatalog.all():
		var signatures: Dictionary = {}
		for seed_number in range(100):
			var seed_value := seed_number * 7919 + 12345
			var layout := generator.generate(seed_value, world)
			var repeated := generator.generate(seed_value, world)
			_check(str(layout) == str(repeated), "Non-deterministic world %s seed %d" % [world.id, seed_value])
			_check(not signatures.has(layout.signature), "Distinct seeds produced the same signature")
			signatures[layout.signature] = true
			arena.bounds = layout.bounds
			arena.obstacles = layout.obstacles
			arena.spawn_position = layout.spawn
			_check(arena.is_safe(layout.spawn, 160.0), "Unsafe initial clearing")
			_check(arena.obstacles.size() >= 25, "Sparse generator failed its intended density")
			total_obstacles += arena.obstacles.size()
			for obstacle in arena.obstacles:
				_check(arena.bounds.encloses(obstacle), "Obstacle escaped arena")
			_check(_connected(arena), "Walkable floor disconnected: %s seed %d" % [world.id, seed_value])
			for path: PackedVector2Array in layout.paths:
				for segment in range(path.size() - 1):
					for step in range(1, 10):
						var point := path[segment].lerp(path[segment + 1], float(step) / 10.0)
						if arena.bounds.grow(-40).has_point(point):
							_check(arena.is_safe(point, 35.0), "Blocked main road")
			var rng := RandomNumberGenerator.new()
			rng.seed = seed_value
			var centers: Array[Vector2] = [layout.spawn, Vector2(32,32), Vector2(2528,32), Vector2(32,1888), Vector2(2528,1888), Vector2(1280,32), Vector2(32,960)]
			for center in centers:
				var candidate := arena.find_spawn(center, 550.0, 850.0, rng, 30.0)
				_check(candidate.is_finite(), "Failed to find an available spawn")
				if candidate.is_finite():
					_check(arena.is_safe(candidate, 30.0), "Spawn overlaps collision")
					var distance := candidate.distance_to(center)
					_check(distance >= 549.99 and distance <= 850.01, "Spawn distance contract violated")
			_check(arena.find_spawn(Vector2(-10000,-10000), 10.0, 20.0, rng) == Vector2.INF, "Impossible spawn must be explicit")
		print("WORLD PASS: ", world.display_name, " / 100 seeds / paths + connected floor + edge spawning")
	# Exercise real static bodies and the shared pixel-texture cache once/world.
	root.add_child(arena)
	for world in WorldCatalog.all():
		arena.setup(null, world, 20261019)
		_check(arena._walls.get_child_count() == arena.obstacles.size() + 4, "Missing collision shapes")
		_check(arena.is_safe(arena.spawn_position), "Setup changed safe start")
		await process_frame
	arena.queue_free()
	await process_frame
	print("WORLD RESULT: ", checks, " checks / 400 seeded layouts / ", total_obstacles, " obstacles / ", failures, " failures")
	quit(1 if failures > 0 else 0)

func _check(condition: bool, description: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		if failures <= 20:
			push_error(description)

func _connected(arena: SurvivalArena) -> bool:
	# Rasterize conservative 20px player clearance, then flood every free cell.
	var blocked := PackedByteArray()
	blocked.resize(GRID.x * GRID.y)
	for obstacle in arena.obstacles:
		var inflated := obstacle.grow(22.0)
		var low := Vector2i(floori((inflated.position.x - 20.0) / CELL), floori((inflated.position.y - 20.0) / CELL))
		var high := Vector2i(ceili((inflated.end.x - 20.0) / CELL), ceili((inflated.end.y - 20.0) / CELL))
		for y in range(maxi(low.y,0), mini(high.y + 1,GRID.y)):
			for x in range(maxi(low.x,0), mini(high.x + 1,GRID.x)):
				if inflated.has_point(Vector2(x * CELL + 20, y * CELL + 20)):
					blocked[y * GRID.x + x] = 1
	var visited := PackedByteArray()
	visited.resize(blocked.size())
	var start := Vector2i(32, 24)
	var queue: Array[Vector2i] = [start]
	visited[start.y * GRID.x + start.x] = 1
	var cursor := 0
	var directions: Array[Vector2i] = [Vector2i.UP, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT]
	while cursor < queue.size():
		var current := queue[cursor]
		cursor += 1
		for direction in directions:
			var next := current + direction
			if next.x < 0 or next.y < 0 or next.x >= GRID.x or next.y >= GRID.y:
				continue
			var index := next.y * GRID.x + next.x
			if blocked[index] == 0 and visited[index] == 0:
				visited[index] = 1
				queue.append(next)
	for index in range(blocked.size()):
		if blocked[index] == 0 and visited[index] == 0:
			return false
	return true
