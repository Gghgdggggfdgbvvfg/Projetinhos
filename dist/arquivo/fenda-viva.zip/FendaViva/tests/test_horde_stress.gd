extends SceneTree
## Accelerated survival soak with real movement, automatic weapons and XP.
## Invulnerability isolates stability; this does not measure human difficulty.
var game: FendaGame
var clock: float=0
var failures: int=0
var max_enemies: int=0
var max_projectiles: int=0
var guardian_seen: bool=false

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	Engine.time_scale=8.0
	Engine.physics_ticks_per_second=120
	game=FendaGame.new()
	root.add_child(game)
	game.start_run(987654)
	game.player.invulnerability=10000
	var previous_time:=0.0
	while clock<180.0:
		await physics_frame
		await process_frame
		if game.state=="upgrade":
			var selected: String=game.offered[0].id
			for choice in game.offered:
				if choice.id in ["damage","multishot","pierce","haste"]: selected=choice.id
			game.choose_upgrade(selected)
			continue
		if game.state in ["world_complete","victory"]: break
		clock=game.run_time
		if clock<previous_time: failures+=1
		previous_time=clock
		max_enemies=maxi(max_enemies,game.enemies.size())
		max_projectiles=maxi(max_projectiles,get_nodes_in_group("projectiles").size())
		guardian_seen=guardian_seen or game.boss_spawned
		var target:=game.room.spawn_position+Vector2.from_angle(clock*.18)*260.0
		var nearest:=999999.0
		for node in get_nodes_in_group("pickups"):
			if node is ExperiencePickup:
				var distance: float=node.position.distance_squared_to(game.player.position)
				if distance<nearest:
					nearest=distance
					target=node.position
		var motion:=game.player.position.direction_to(target)
		Input.action_press("move_right",maxf(0,motion.x))
		Input.action_press("move_left",maxf(0,-motion.x))
		Input.action_press("move_down",maxf(0,motion.y))
		Input.action_press("move_up",maxf(0,-motion.y))
	for action in ["move_right","move_left","move_up","move_down"]: Input.action_release(action)
	if game.kills<25: failures+=1
	if game.player_level<4: failures+=1
	if max_enemies>101 or max_projectiles>260: failures+=1
	if not guardian_seen: failures+=1
	print("HORDE SOAK: %.1fs simulated, kills=%d level=%d max_enemies=%d max_projectiles=%d guardian=%s failures=%d"%[clock,game.kills,game.player_level,max_enemies,max_projectiles,str(guardian_seen),failures])
	game.go_menu()
	game.queue_free()
	await create_timer(.25,true,false,true).timeout
	quit(1 if failures else 0)
