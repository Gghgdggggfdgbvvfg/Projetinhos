extends SceneTree
var game: FendaGame
var directory: String

func _initialize() -> void:
	call_deferred("_run")

func capture(id: String) -> void:
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(directory.path_join(id+".png"))
	print("CAPTURE ",id)

func _run() -> void:
	directory=ProjectSettings.globalize_path("res://../../work/survival-captures")
	DirAccess.make_dir_recursive_absolute(directory)
	game=FendaGame.new()
	root.add_child(game)
	await create_timer(.3).timeout
	await capture("01-menu")
	game.hud._show_settings()
	await capture("10-settings")
	game.hud._close_settings()
	game.start_run(481516)
	game.director.spawn_clock=9999
	game.player.invulnerability=9999
	for world in range(4):
		game._load_world(world)
		game.director.spawn_clock=9999
		game.player.invulnerability=9999
		game.world_time=62
		var kinds: Array[String]=["chaser","chaser","chaser","shooter","charger","tank"]
		for i in range(26):
			var pos:=game.room.find_spawn(game.player.position,140,480,game.rng,28)
			if pos.is_finite():
				game.spawn_enemy(game.catalog.enemy(kinds[i%kinds.size()]),pos)
		for i in range(15):
			game._drop_pickup(game.player.position+Vector2.from_angle(i*.66)*game.rng.randf_range(100,240),6,"xp")
		await create_timer(.85).timeout
		await capture("0%d-world-%d"%[world+2,world+1])
	game.add_experience(30)
	await create_timer(.1).timeout
	await capture("06-level-up")
	for i in 15:
		if game.state=="upgrade": game.choose_upgrade(game.offered[0].id)
	game.toggle_pause()
	await capture("07-pause")
	game.resume_run()
	game._load_world(0)
	game.director.spawn_clock=9999
	game.boss_defeated=true
	game.complete_world()
	await process_frame
	await capture("08-next-world")
	game.go_menu()
	root.size=Vector2i(1600,900)
	await create_timer(.15).timeout
	await capture("09-widescreen")
	root.size=Vector2i(1280,800)
	game.start_run(481516)
	game.player.invulnerability=9999
	game.director.spawn_clock=9999
	game.director.guardian_requested=true
	game.world_time=151
	game.run_time=151
	game.player_level=7
	game.active_weapons=["agulha","estilha","pulso"]
	var guardian_position:=game.room.find_spawn(game.player.position,220,300,game.rng,44)
	game.spawn_enemy(game.catalog.enemy("boss"),guardian_position,true)
	for i in range(36):
		var point:=game.room.find_spawn(game.player.position,190,510,game.rng,28)
		if point.is_finite(): game.spawn_enemy(game.catalog.enemy(["chaser","shooter","charger","tank"][i%4]),point)
	await create_timer(.5).timeout
	await capture("11-guardian")
	game._finish_run(false)
	await capture("12-defeat")
	game.start_run(481516)
	game._load_world(3)
	game.worlds_cleared=4
	game._finish_run(true)
	await capture("13-victory")
	game.start_run(481517)
	game.director.spawn_clock=9999
	await capture("14-alternate-seed")
	game.queue_free()
	await create_timer(.2,true,false,true).timeout
	quit()
