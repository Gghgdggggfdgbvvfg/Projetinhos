extends SceneTree
## Real physics-space regression coverage for autonomous attacks and actor safety.

class CombatGame extends FendaGame:
	var shots: Array[Dictionary] = []
	func _ready() -> void:
		stats = GameCatalog.base_stats()
		state = "active"
		set_process(false)
		set_process_unhandled_input(false)
	func shoot(origin: Vector2, direction: Vector2, weapon: WeaponData, team: int, source: Node) -> void:
		shots.append({"id":weapon.id,"origin":origin,"direction":direction,"team":team,"source":source})
	func burst(_pos: Vector2, _color: Color, _amount: int = 10) -> void:
		pass
	func float_text(_pos: Vector2, _label: String, _color: Color) -> void:
		pass
	func play_sound(_id: String) -> void:
		pass
	func shake(_amount: float) -> void:
		pass
	func enemy_defeated(enemy: FendaEnemy) -> void:
		enemies.erase(enemy)

var game: CombatGame
var failures: int = 0
var checks: int = 0

func _initialize() -> void:
	_run.call_deferred()

func _check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("AUTO COMBAT: " + label)

func _frames(count: int) -> void:
	for frame in count:
		await physics_frame

func _enemy(kind: String, point: Vector2) -> FendaEnemy:
	var enemy := FendaEnemy.new()
	game.room.add_child(enemy)
	enemy.position = point
	enemy.setup(game,game.catalog.enemy(kind))
	enemy.set_physics_process(false)
	game.enemies.append(enemy)
	return enemy

func _count(id: String) -> int:
	var result := 0
	for shot in game.shots:
		if shot.id == id: result += 1
	return result

func _reset_fire() -> void:
	game.shots.clear()
	game.player.weapon_timers.clear()
	game.player.attack_cooldown = 0.0
	game.player.target_refresh = 0.0
	game.player.weapon_targets.clear()
	game.player.current_target = null

func _wall(point: Vector2) -> StaticBody2D:
	var body := StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var collision := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size = Vector2(18,90)
	collision.shape = rectangle
	body.add_child(collision)
	game.room.add_child(body)
	body.position = point
	return body

func _run() -> void:
	game = CombatGame.new()
	root.add_child(game)
	game.room = SurvivalArena.new()
	game.room.bounds = Rect2(0,0,2560,1920)
	game.add_child(game.room)
	game.player = FendaPlayer.new()
	game.add_child(game.player)
	game.player.setup(game)
	game.player.position = Vector2(1000,900)
	game.player.set_physics_process(false)
	var target := _enemy("chaser",Vector2(1100,900))
	await _frames(3)

	# No mouse or attack action is ever pressed by this test.
	_reset_fire()
	game.player._physics_process(0.02)
	_check(game.shots.size() == 1,"primary weapon fires without any attack input")
	_check(game.shots[0].direction.dot(Vector2.RIGHT) > 0.99,"automatic aim points at the enemy")
	game.active_weapons = ["agulha","estilha","pulso"]
	_reset_fire()
	for step in 200:
		game.player._physics_process(0.01)
	_check(_count("agulha") >= 6 and _count("agulha") <= 7,"crossbow keeps its 0.30 second cadence")
	_check(_count("estilha") >= 3 and _count("estilha") <= 4,"dagger volley fires concurrently at its own cadence")
	_check(_count("pulso") >= 16 and _count("pulso") <= 17,"staff fires concurrently at its own cadence")

	var before := game.shots.size()
	var remaining: Dictionary = game.player.weapon_timers.duplicate()
	game.state = "paused"
	game.player._physics_process(0.5)
	_check(game.shots.size() == before and game.player.weapon_timers == remaining,"pause freezes shots and all weapon timers")
	game.state = "upgrade"
	game.player._physics_process(0.5)
	_check(game.shots.size() == before,"level-up selection freezes automatic attacks")
	game.state = "active"
	_reset_fire()
	game.player.dash_duration_left = 0.1
	game.player.dash_direction = Vector2.DOWN
	game.player._physics_process(0.01)
	_check(game.shots.is_empty(),"dash suspends all automatic weapons")
	game.player.dash_duration_left = 0.0
	game.player.velocity = Vector2.ZERO
	game.player.position = Vector2(1000,900)

	# Obscured nearest enemy must not starve a slightly farther visible enemy.
	var visible := _enemy("shooter",Vector2(1000,1040))
	var blocker := _wall(Vector2(1050,900))
	await _frames(3)
	_reset_fire()
	game.player._physics_process(0.02)
	_check(game.player.current_target == visible,"nearest target selection rejects a blocked enemy")
	_check(game.shots.size() == 3,"all weapons can select a visible alternate target")
	for shot in game.shots:
		_check(shot.direction.dot(Vector2.DOWN) > 0.99,"weapon aims through the clear line of sight")
	blocker.queue_free()
	await _frames(3)
	_reset_fire()
	game.player._physics_process(0.02)
	_check(game.player.current_target == target,"closer visible enemy takes priority")

	# A queued/freed object may still be present in both cached target references.
	game.player.target_refresh = 1.0
	target.free()
	game.player.weapon_timers.clear()
	game.player.attack_cooldown = 0.0
	game.shots.clear()
	game.player._physics_process(0.02)
	_check(game.shots.is_empty(),"freed cached targets are skipped without accessing them")
	game.player._physics_process(0.02)
	_check(game.player.current_target == visible and game.shots.size() == 3,"a valid target is reacquired after deletion")
	visible.dead = true
	_reset_fire()
	game.player._physics_process(0.02)
	_check(game.shots.is_empty(),"dead targets are not attacked")
	visible.dead = false
	visible.position = Vector2(1500,900)
	await _frames(2)
	_reset_fire()
	game.player._physics_process(0.02)
	_check(_count("agulha") == 1 and _count("pulso") == 1 and _count("estilha") == 0,"each weapon obeys its own reach")
	visible.position = Vector2(2100,900)
	await _frames(2)
	_reset_fire()
	game.player._physics_process(0.02)
	_check(game.shots.is_empty(),"no weapon fires without an enemy in range")

	var boss := _enemy("boss",Vector2(1800,900))
	boss._set_state("pursuit")
	boss._cooldown = 0.0
	boss._steer_timer = 0.0
	boss._physics_process(0.2)
	_check(boss.velocity.length() >= boss.data.speed * 0.9,"distant guardian approaches at full walking speed")
	_check(boss.state == "pursuit","guardian does not start attacks outside combat range")
	var health := boss.hp
	game.state = "paused"
	var boss_position := boss.position
	boss._physics_process(1.0)
	_check(boss.position == boss_position and boss.hp == health,"paused guardian freezes movement and damage-over-time")
	game.state = "active"
	boss._prepare("fan",1.0)
	_check(boss.state == "warmup" and not boss.telegraph.striking,"guardian attack begins with readable anticipation")
	_check(PixelActor.texture("knight") == PixelActor.texture("knight"),"pixel art textures are cached")
	for enemy in game.enemies:
		if is_instance_valid(enemy): enemy.queue_free()
	game.enemies.clear()
	await _frames(2)
	# Real timed attack resolution, using the same Hurtboxes and projectiles as play.
	Engine.time_scale = 5.0
	Engine.physics_ticks_per_second = 120
	game.player.vitality.configure(2000.0)
	for kind: String in ["chaser","shooter","charger","tank"]:
		await _test_archetype(kind)
	await _test_charge_wall()
	await _test_steering()
	await _test_poison_death()
	await _test_boss_patterns()
	game.queue_free()
	await process_frame
	await process_frame
	print("AUTO COMBAT: ",checks," checks; ",failures," failures")
	quit(0 if failures == 0 else 1)

func _advance(seconds: float) -> void:
	await create_timer(seconds,true,true).timeout

func _clear_shots() -> void:
	for projectile in get_nodes_in_group("projectiles"):
		projectile.queue_free()

func _test_archetype(kind: String) -> void:
	var enemy := _enemy(kind,Vector2(1000,900))
	enemy.set_physics_process(true)
	var offset: float = {"chaser":50.0,"shooter":290.0,"charger":260.0,"tank":100.0}[kind]
	game.player.position = enemy.position + Vector2(offset,0)
	game.player.invulnerability = 0.0
	var before := game.player.hp
	enemy._set_state("pursuit")
	enemy._cooldown = 0.0
	await _advance(0.10)
	_check(enemy.state == "warmup",kind + ": attack enters anticipation before dealing damage")
	_check(not enemy.telegraph.kind.is_empty(),kind + ": has visible attack geometry")
	var timer := enemy._state_time
	var point := enemy.position
	game.state = "paused"
	await _advance(0.25)
	_check(is_equal_approx(enemy._state_time,timer) and enemy.position.is_equal_approx(point),kind + ": pause freezes AI")
	game.state = "active"
	await _advance(2.3)
	_check(game.player.hp < before,kind + ": attack deals real Hurtbox damage")
	enemy.queue_free()
	_clear_shots()
	await _frames(2)

func _test_charge_wall() -> void:
	var wall := _wall(Vector2(1200,900))
	var enemy := _enemy("charger",Vector2(1050,900))
	enemy.set_physics_process(true)
	game.player.position = Vector2(1400,900)
	game.player.invulnerability = 100.0
	await _frames(2)
	enemy._facing = Vector2.RIGHT
	enemy._prepare_charge(0.3,350.0)
	_check(enemy.telegraph.distance < 150.0,"charge anticipation ends at an obstacle")
	await _advance(0.7)
	_check(enemy.position.x <= 1191.0 - enemy.data.radius + 1.0,"charger body cannot cross an obstacle")
	_check(enemy.state == "recover","blocked charge opens a recovery window")
	enemy.queue_free()
	wall.queue_free()
	await _frames(2)

func _test_steering() -> void:
	var wall := _wall(Vector2(1200,900))
	var enemy := _enemy("chaser",Vector2(1060,900))
	enemy.set_physics_process(true)
	game.player.position = Vector2(1360,900)
	game.player.invulnerability = 100.0
	enemy._set_state("pursuit")
	enemy._cooldown = 999.0
	await _advance(6.0)
	_check(enemy.position.x > 1240.0 and enemy.position.distance_to(game.player.position) < 90.0,"pursuer steers around a blocking obstacle")
	enemy.queue_free()
	wall.queue_free()
	await _frames(2)

func _test_poison_death() -> void:
	var enemy := _enemy("tank",Vector2(1000,900))
	enemy.set_physics_process(true)
	game.player.position = Vector2(1400,1100)
	enemy._set_state("recover",10.0)
	var initial := enemy.hp
	var hit := DamageData.new()
	hit.amount = 1.0
	hit.team = 1
	hit.source = game.player
	hit.poison = 6.0
	enemy.receive_hit(hit)
	await _advance(3.2)
	_check(initial - enemy.hp >= 16.0 and initial - enemy.hp <= 19.1,"poison damage is finite and expires in three seconds")
	var after := enemy.hp
	await _advance(0.6)
	_check(is_equal_approx(enemy.hp,after),"expired poison stops damaging")
	var deaths: Array[int] = [0]
	enemy.defeated.connect(func(_actor: FendaEnemy): deaths[0] += 1)
	hit.poison = 0.0
	hit.amount = 10000.0
	hit.explosion_chain = 1
	enemy.receive_hit(hit)
	enemy.receive_hit(hit)
	_check(enemy.dead and deaths[0] == 1,"death emits its reward signal once")
	_check(enemy.last_hit.explosion_chain == 1,"death preserves damage chain metadata")
	await _frames(2)

func _test_boss_patterns() -> void:
	var enemy := _enemy("boss",Vector2(1000,800))
	enemy.set_physics_process(true)
	game.player.position = Vector2(1000,1070)
	game.player.invulnerability = 100.0
	var patterns: Array[String] = []
	for tick in 160:
		await _advance(0.1)
		if enemy.state == "warmup" and not patterns.has(enemy._attack):
			patterns.append(enemy._attack)
		if patterns.size() == 3: break
	_check(patterns == ["fan","eruption","charge"],"guardian cycles fan, marked eruption and charge")
	_check(enemy.telegraph.kind == "charge","guardian charge has a visible corridor")
	enemy.vitality.damage(enemy.max_hp * 0.51)
	await _advance(3.0)
	_check(enemy.phase == 2 and enemy.hp > 0.0,"living guardian enters phase two below half health")
	_clear_shots()
	enemy.queue_free()
	await _frames(2)
