# Validação — Fenda Viva: Crônicas dos Reinos

Executada em 20 de outubro de 2026 no Windows, com Godot 4.7.2.stable.official.ed1daf0bf e renderizador Compatibility. As capturas foram renderizadas na AMD Radeon RX 7600.

## Resultado desta entrega

| Suíte | Resultado | Cobertura |
|---|---|---|
| Mapas procedurais | 75.808 verificações, 400 mapas, 0 falhas | Repetibilidade por semente, diversidade da geometria real, quatro biomas, 16.200 obstáculos, piso conectado, estradas livres, início seguro e surgimentos nas bordas |
| Combate automático | 51 verificações, 0 falhas | Alvos, alcance, linha de visão, três armas simultâneas, disparos durante movimento, esquiva, pausa, colisões e projéteis |
| Sobrevivência e campanha | 54 verificações, 0 falhas | Experiência, melhorias, chefes, sequência dos quatro mundos, desbloqueios persistentes, morte, reinício e chefes derrotados durante subida de nível |
| Interface | Aprovada, 0 falhas | Mundos bloqueados, seleção de semente e reino, HUD, pausa, ajustes, melhorias, avanço, vitória, derrota e retorno ao menu |
| Hordas em execução prolongada | 0 falhas | 167,7 segundos simulados até concluir o primeiro guardião; 542 eliminações; nível 16; pico de 70 inimigos e 41 projéteis |

O comando `Jogar.ps1 -Verificar` terminou com código 0. As suítes de execução não apresentaram erros nem avisos de recursos retidos. Os dados dos testes foram isolados dos desbloqueios e preferências do jogador.

A importação inicial do editor em um perfil temporário registrou mensagens `Safe save failed`, sem impedir a importação ou os testes. Uma reimportação posterior no perfil local de trabalho concluiu com `EditorSettings: Save OK!`, sem erros. As execuções gráficas também concluíram sem erros.

## Revisão visual

Foram renderizadas 14 telas: menu, quatro reinos, escolha de melhoria, pausa, reino desbloqueado, menu em 1600×900, ajustes, guardião com três armas, derrota, vitória e uma segunda semente. Foram inspecionados os quatro estilos de cenário, textos, barras e cartões, incluindo a tela de chefe e a interface completa em 1280×800.

As capturas usam cenários controlados de desenvolvimento. Seus números de nível, tempo e eliminações não representam uma partida humana.

## Correções na retomada

- A verificação de diversidade agora compara a geometria dos mapas, sem depender de seu número de semente.
- Inimigos comuns muito distantes e fora da tela liberam espaço para novas hordas. Chefes e inimigos visíveis permanecem; a remoção não concede experiência nem eliminações.
- Os testes verificam a sequência dos quatro guardiões e a leitura dos desbloqueios salvos.
- O encerramento do teste de interface aguarda a liberação do áudio.
- O modo de verificação do iniciador usa um perfil temporário para preservar as preferências e o progresso do jogador.
- Documentação e pacote atualizados para a edição de sobrevivência medieval.

## Limites

O teste prolongado utiliza movimento sintético, escolha automática de melhorias e invulnerabilidade para avaliar estabilidade. Não mede dificuldade humana, desempenho mínimo ou equilíbrio de todas as combinações.

Esta campanha tem quatro mundos. O surgimento de inimigos é contínuo durante a sobrevivência e o confronto com cada chefe. Existem limites simultâneos de entidades para controlar o custo da simulação; isso não limita o total de inimigos que podem surgir durante a partida. Vencer o quarto guardião encerra a campanha.

O pacote contém o projeto-fonte jogável pelo Godot 4.7.2 instalado. Não inclui um executável autônomo. Não há salvamento de uma partida em andamento; mundos desbloqueados e ajustes são persistentes.
